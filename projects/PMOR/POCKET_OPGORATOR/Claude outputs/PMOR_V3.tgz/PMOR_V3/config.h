// config.h — PMOR v3: every constant in one place.
#pragma once
#include <stdint.h>

// ---------------------------------------------------------------- audio
#define SR              48000.0f
#define BLOCK           64
#define BLOCK_HZ        (SR / BLOCK)          // 750 Hz control rate inside the ISR

// ---------------------------------------------------------------- pins (locked, see WIRING-v2.md)
#define PIN_ENC_A       0
#define PIN_ENC_B       1
#define PIN_ENC_SW      2
#define PIN_OLED_DC     3
#define PIN_OLED_RST    4
#define PIN_OLED_CS     7
#define PIN_OLED_SCK    8
#define PIN_OLED_MOSI   10
#define PIN_TBUS_SCL    11
#define PIN_TBUS_SDA    12
#define PIN_SBUS_SCL    13
#define PIN_SBUS_SDA    14
#define PIN_FSR         15   // adc ch0
#define PIN_JOY_X       16   // adc ch1
#define PIN_JOY_Y       17   // adc ch2
#define PIN_JOY_SW      24
#define PIN_SD_MISO     25
#define PIN_SD_CLK      26
#define PIN_SD_MOSI     27
#define PIN_SD_CS       28

// ---------------------------------------------------------------- calibration
#define FSR_IDLE_RAW    1600      // 12-bit-equivalent idle; FsrScale auto-learns from here
#define JOY_MAX_RAW     950       // usable deflection from centre (raw 0..1023 scale); edge catch beyond is fine
#define JOY_DEADZONE    0.06f     // normalised
// Joystick orientation. Logical axes everywhere in the firmware: +X = RIGHT, +Y = UP.
// Measured 2026-09-14: the module is mounted rotated — the wiring's "X" channel (adc1)
// is the physical vertical axis and "Y" (adc2) is horizontal. Flip a flag if a direction
// is backwards; nothing else in the code needs to change.
#define JOY_SWAP_XY     1         // 1: physical horizontal = adc2, physical vertical = adc1
#define JOY_INVERT_X    1         // logical +X must be physical RIGHT   (flipped 2026-09-14 after test 2)
#define ACCEL_INVERT_X  1         // tilt direction for every accel-X mapping (env macro shorter/longer, LFO speeds): flipped 2026-09-14 per EMGOR
#define JOY_INVERT_Y    1         // logical +Y must be physical UP      (flipped 2026-09-14 after test 2)

// ---------------------------------------------------------------- nav feel
#define NAV_REPEAT_DELAY_MS  350
#define NAV_REPEAT_HZ        8
#define EDIT_STICK_FULL      0.55f   // stick deflection that already means "max" in the editors (the last 20 % is hard to hold)
#define DIVE_MS              540     // menu-switch tunnel/name duration
#define NAV_HOLD_DELETE_MS   5000
#define NAV_DOUBLE_WINDOW_MS 40      // both buttons within this = volume shortcut
#define TAP_MAX_N            5
#define TAP_EXPIRE_MS        2000
#define SAVER_IDLE_MS        25000
#define AUTOSAVE_DEBOUNCE_MS 2000

// ---------------------------------------------------------------- sequencer
#define MAX_BARS        16
#define MAX_STEPS_BAR   16
#define MAXSTEPS        (MAX_BARS * MAX_STEPS_BAR)   // 256
#define N_PADS          16
#define N_LANES         16

// ---------------------------------------------------------------- engines
#define SYN_VOICES      12
#define SYN_MAX_POLY    8
#define SYN_OCTAVES     5
#define DRUM_SOUNDS     16        // per pad
#define DRUM_VOICES     16
#define SMP_SLOTS       16
#define SMP_LEN         96000u    // 2 s mono per slot
#define ENGINE_VOL_MAX  1.25f

// ---------------------------------------------------------------- FX space
#define FX_HOME         16
#define FX_PER_DIR      12
#define FX_TOTAL        (FX_HOME + 4 * FX_PER_DIR)   // 64
#define FX_FADE_MS      6         // anti-click on every engage/release
#define DIST_XFADE_MS   5

// ---------------------------------------------------------------- output
#define MASTER_UNITY    0.2848f   // old pad 9 (75 %) — the new 100 %
#define CLIP_THRESH_DB  -4.4f     // Fruity-style knee default

// ---------------------------------------------------------------- patches
#define PATCH_PAGES     4
#define PATCH_SLOTS     (PATCH_PAGES * 16)   // 64
#define PATCH_MAGIC     0x4F504735u          // 'OPG5'

// ---------------------------------------------------------------- SDRAM placement
#define SDRAM_BSS __attribute__((section(".sdram_bss")))
