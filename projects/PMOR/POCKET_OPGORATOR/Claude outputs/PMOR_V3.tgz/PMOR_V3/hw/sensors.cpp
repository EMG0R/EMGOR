// sensors.cpp — IMU (MPU6050) + lidar (VL53L1X) + FSR → SharedState g.
// VERBATIM from PMOR_V2.cpp:
//   sensor bus init            L4102–4104
//   MPU6050 init               L4106–4115   (magnetometer probe L4118–4135 DROPPED: no mag on the 6050)
//   lidar register shims       L290–291, init L4143–4145
//   50 ms sensor read          L4919–4938   (gyro reads L4926–4928 DROPPED — unused in v3)
//   sensor watchdog            L4945–4984   (mag watchdog L4961–4968 DROPPED)
//   FSR 8-sample median        L5021–5045   (FsrScale from _fsr_scale.h)
#include "hw.h"
#include "hw_priv.h"
#include "bbus.h"
#include "../config.h"
#include "../engine/shared_state.h"
#include "VL53L1X_mini.h"
#include "_fsr_scale.h"
#include "daisy_seed.h"
using namespace daisy;

static VL53L1X_Mini lidar;
static FsrScale     g_fsr;          // 330R + cubed + full-span ceiling

// ---- IMU
static bool imu_ok = false;
// ---- lidar
static bool     lidar_ok   = false;
static uint16_t dist       = 0;
static uint32_t lidar_seen = 0;
// ---- FSR
static uint16_t fsr = 0;

bool     imuOk()       { return imu_ok; }
bool     lidarOk()     { return lidar_ok; }
uint16_t lidarMm()     { return dist; }
uint8_t  lidarStatus() { return lidar.lastStatus(); }

// Pump the USB plane around every lidar register op. If the sensor is
// unresponsive, each bit-banged transaction burns ~100ms in bus timeouts;
// a full re-init is ~40 ops ≈ 4-5 SECONDS — measured as 4.8s MIDI-clock
// holes every watchdog retry (2026-08-16). With the pump, even that
// pathological path can't gap the clock or starve USB audio.
void vl53_write_reg(uint16_t reg, uint8_t* d, uint8_t n) { pmor_usb_service(); sbus.w16a(0x29,reg,d,n); }
void vl53_read_reg (uint16_t reg, uint8_t* d, uint8_t n) { pmor_usb_service(); sbus.r16a(0x29,reg,d,n); }

// ============================================================
// boot
// ============================================================
void sensorsBusInit() {
    sbus.init(hw.GetPin(PIN_SBUS_SCL), hw.GetPin(PIN_SBUS_SDA));   // D13 / D14
    sbus.us = 3;   // sensor bus ~160kHz — IMU/mag/lidar all handle it
    tbus.init(hw.GetPin(PIN_TBUS_SCL), hw.GetPin(PIN_TBUS_SDA));   // D11 / D12
}

static inline bool imuIdOk(uint8_t id) {
    // v2: accept the MPU6050 (returns 0x68) as well as the MPU9250 family
    // (0x71/0x73/0x70) and common clones (0x69/0x98). Before this, a 6050 was
    // rejected outright -- imu_ok never went true and the watchdog below
    // reinit-stormed it once a second.
    return (id==0x71||id==0x73||id==0x70||id==0x68||id==0x69||id==0x98);
}

void imuInit() {
    // IMU at 0x68 -- MPU6050 (6-axis) on v2, MPU9250 also accepted
    sbus.w8(0x68,0x6B,0x80); System::Delay(100); // DEVICE_RESET
    sbus.w8(0x68,0x6B,0x01); System::Delay(50);  // wake + PLL clock
    uint8_t imu_id = sbus.r8(0x68,0x75);
    imu_ok = imuIdOk(imu_id);
    // v3: the IMU is an MPU6050 (6-axis). It has NO magnetometer, so the
    // AK8963 bypass probe at 0x0C (v2 L4118–4135) is gone entirely — it only
    // ever cost failed transactions and 5 ms waitScl timeouts on this board.
}

void lidarInit() {
    // VL53L1X lidar (0x29)
    g_t_sens = System::GetNow();
    lidar_ok = lidar.init();
    if(lidar_ok) lidar.startContinuous(40);
    lidar_seen = System::GetNow();
}

// ============================================================
// main-loop tick
// ============================================================
void sensorsTick(uint32_t now) {
    // ── Sensors — 50ms rate limit to reduce I2C noise on audio path ────
    {
        static uint32_t next_sensor = 0;
        if(now >= next_sensor) {
            next_sensor = now + 50;
            if(imu_ok) {
                float ax=sbus.r16be(0x68,0x3B)/16384.f;
                float ay=sbus.r16be(0x68,0x3D)/16384.f;
                float az=sbus.r16be(0x68,0x3F)/16384.f;
                // (gyro 0x43/0x45/0x47 reads dropped in v3 — nothing consumes them;
                //  saves ~1 ms of bus time per 50 ms)
#if ACCEL_INVERT_X
                ax = -ax;
#endif
                g.accel_x = ax; g.accel_y = ay; g.accel_z = az;
            }
            if(lidar_ok && lidar.dataReady()) { dist = lidar.read(); lidar_seen = now; }
            {
                // 0..1 with 1 = touching, 0 = far / no reading (dist 0 = invalid)
                float L = (dist == 0) ? 0.f : 1.f - (float)dist / 600.f;
                if(L > 1.f) L = 1.f;
                if(L < 0.f) L = 0.f;
                // the sensor updates ~25x/s; smooth here so nothing downstream steps.
                // (effects add their own per-sample glide on top — see SIREN)
                static float lsm = 0.f;
                lsm += (L - lsm) * 0.35f;
                g.lidar = lsm;
            }

            // ── sensor watchdog — PROBE-ONLY in normal operation (2 cheap
            // reads per second). Reinit fires only after a sensor has been
            // LOST >1s (two consecutive failed probes). Lidar reinit (a
            // long blocking call) only if it was up, silent >5s, and at
            // least 10s since the last attempt — never an init storm.
            {
                static uint32_t next_schk = 0;
                static uint8_t  imu_bad = 0;
                static uint32_t lidar_retry = 0;
                if(now >= next_schk) {
                    next_schk = now + 1000;
                    uint8_t id = sbus.r8(0x68, 0x75);
                    if(imuIdOk(id)) { imu_bad = 0; imu_ok = true; }
                    else if(++imu_bad >= 2) {
                        sbus.w8(0x68, 0x6B, 0x01);
                        // (v2 also re-armed the mag bypass 0x37 / AK8963 0x0C here — dropped, no mag)
                        id = sbus.r8(0x68, 0x75);
                        imu_ok = imuIdOk(id);
                        if(imu_ok) imu_bad = 0;
                    }
                    // ONE re-init attempt, ever. Against an unresponsive
                    // sensor a full init is seconds of I2C timeouts; the
                    // old every-10s retry put a multi-second hole in the
                    // main loop forever (13s MIDI-clock gap measured
                    // 2026-08-16). A sensor that failed twice isn't
                    // coming back without a power cycle anyway.
                    static uint8_t lidar_reinits = 0;
                    if(lidar_ok && now - lidar_seen > 5000 && now >= lidar_retry) {
                        lidar_retry = now + 10000;
                        if(lidar_reinits++ >= 1) { lidar_ok = false; }
                        else {
                            lidar_ok = lidar.init();
                            if(lidar_ok) { lidar.startContinuous(40); lidar_seen = now; }
                        }
                    }
                }
            }
        }
    }
    // FSR: 8-sample circular median, sampled at 10ms intervals.
    // Gating prevents all 8 samples from landing in the same glitch window,
    // and median-of-8 requires 4+ simultaneous spikes to corrupt the output.
    {
        static uint16_t fsrbuf[8]={}; static uint8_t fsridx=0;
        static uint32_t fsr_next=0;
        if(System::GetNow() >= fsr_next) {
            fsr_next = System::GetNow() + 10;
            fsrbuf[fsridx]=(uint16_t)(hw.adc.GetFloat(0)*4095.f);
            fsridx=(fsridx+1)%8;
        }
        // Median of 8: copy, insertion-sort, take middle two average
        uint16_t s[8]; for(int i=0;i<8;i++) s[i]=fsrbuf[i];
        for(int i=1;i<8;i++){uint16_t k=s[i];int j=i-1;while(j>=0&&s[j]>k){s[j+1]=s[j];j--;}s[j+1]=k;}
        fsr=(uint16_t)(((uint32_t)s[3]+s[4])>>1);
        // v2: the old fixed 400..2600 linear window was tuned for the v1
        // 10k pulldown. With the 330R pulldown + big panel FSR the raw
        // values sit compressed outside that range, so it snapped
        // low-to-high with nothing usable in between.
        //
        // FsrScale auto-calibrates to whatever this sensor actually
        // produces and applies the cubed curve (an FSR is ~1/force, so
        // linear always feels like a hair trigger). See _fsr_scale.h.
        g.fsr = g_fsr.Process(fsr);
    }
}
