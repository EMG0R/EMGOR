// hw.h — façade over the verbatim hardware ports. CONTROL plane unless stated.
// Implementations are lifted line-for-line from PMOR_V2 (see research/v2-audit.md §2).
#pragma once
#include <stdint.h>
#include <stddef.h>
#include "daisy_seed.h"

extern daisy::DaisySeed hw;

// ---- USB service pump (the one symbol every blocking driver needs)
extern "C" void pmor_usb_service(void);
void usbDelay(uint32_t ms);          // Delay that keeps USB alive

// ---- boot (order locked, see audit §2.12). Returns after audio is started and the trellis is up.
typedef void (*AudioCb)(float** in, float** out, size_t n);
void hwBoot(AudioCb cb);

// ---- trellis
bool trellisOk();
void trellisTick(uint32_t now_ms);                          // recovery/watchdog + LED push (80 ms cadence, frame-diff)
void trellisSetFrame(const uint8_t grb[48]);                // next frame to push
typedef void (*PadCb)(uint8_t pad, bool pressed);
void trellisPollKeys(uint32_t now_ms, PadCb cb);           // 20 ms cadence; applies rotation remap
void trellisSetRotation(uint8_t quarter_turns);            // 0..3, single remap table for LEDs and keys

// ---- OLED
namespace daisy { template<typename D> class OledDisplay; }
void oledInit();
void oledFlush();                                          // display.Update() (dirty pages, pumps USB)
void oledSetContrast(uint8_t level);                       // GLOBAL setting; 1 = locked-safe minimum, clamps 1..32
// drawing primitives used by ui/render.cpp
void oledClear();
void oledPixel(int x, int y, bool on);
void oledLine(int x0, int y0, int x1, int y1, bool on);
void oledRect(int x0, int y0, int x1, int y1, bool on, bool fill);
void oledRoundRect(int x0, int y0, int x1, int y1, int r, bool on, bool fill);
void oledText(int x, int y, const char* s, bool on);       // Font_6x8
void oledTextBig(int x, int y, const char* s, bool on);    // Font_7x10

// ---- sensors
void  sensorsTick(uint32_t now_ms);                        // IMU 50 ms + watchdog, lidar, FSR median → SharedState g
bool  imuOk();
bool  lidarOk();
uint16_t lidarMm();
uint8_t  lidarStatus();

// ---- encoder + joystick (joystick ADC is polled from the AUDIO plane at 750 Hz)
int   encoderDelta();                                      // detents since last call (±)
bool  encoderPressed();                                    // raw level
bool  joyPressed();
void  joyPollFromIsr();                                    // AUDIO plane; writes g.joy_*

// ---- SD
bool  sdOk();
void  sdSetFast(bool fast);   // drop to the slow SPI clock after a failed write verify
bool  sdIsFast();
extern char sd_path[];                                     // FatFS logical drive path

// ---- DFU
void  dfuCheck();                                          // CDC "dfu" line → bootloader
