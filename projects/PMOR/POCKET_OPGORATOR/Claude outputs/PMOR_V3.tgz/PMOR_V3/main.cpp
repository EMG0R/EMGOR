// main.cpp — PMOR v3: boot (hw/boot.cpp) + the control-plane scheduler.
// Loop head (USB / CDC / DFU / BPM handover) is PMOR_V2.cpp L4329–4374.
#include <stdio.h>
#include <string.h>
#include "config.h"
#include "hw/hw.h"
#include "hw/hw_priv.h"
#include "engine/shared_state.h"
#include "engine/clock.h"
#include "ui/input.h"
#include "ui/nav.h"
#include "ui/render.h"
#include "store/patch.h"
#include "daisy_seed.h"
extern "C" {
#include "tusb.h"
#include "usb/clock_engine.h"
#include "usb/usb_audio_stream.h"
}
using namespace daisy;

void AudioCallback(float** in, float** out, size_t n);   // engine/audio_callback.cpp

// trellis key events → input ring + the pads_held mirror the audio plane reads
static void onPad(uint8_t pad, bool pressed) {
    if(pressed) g.pads_held |=  (uint16_t)(1u << pad);
    else        g.pads_held &= (uint16_t)~(1u << pad);
    // pad events are derived from g.pads_held inside inputPoll() (single source, no duplicates)
}

// Boot-time marks — printed once, the first time a CDC terminal is attached.
static void printBootMarksOnce() {
    static bool done = false;
    if(done || !tud_cdc_connected()) return;
    done = true;
    char b[128];
    int n = snprintf(b, sizeof b,
        "PMOR v3 boot ms: usb=%lu oled=%lu sens=%lu sd=%lu patch=%lu trellis=%d imu=%d lidar=%d sdok=%d\r\n",
        (unsigned long)g_t_usb, (unsigned long)g_t_oled, (unsigned long)g_t_sens,
        (unsigned long)g_t_sd, (unsigned long)g_t_boot,
        trellisOk()?1:0, imuOk()?1:0, lidarOk()?1:0, sdOk()?1:0);
    if(n > 0) { tud_cdc_write(b, (uint32_t)n); tud_cdc_write_flush(); }
}

int main(void)
{
    hwBoot(AudioCallback);
    oledIntro();
    navInit();

    uint32_t next_oled = 0;
    uint8_t  grb[48];

    while(1)
    {
        uint32_t now = System::GetNow();

        // ── USB tasks + MIDI-clock/role engine — control plane only, every
        // iteration, unconditionally (tud_task() must never be rate-limited).
        // The audio-plane clock (engine/clock.cpp) remains the ONE tempo
        // authority; this is the sole place clk.bpm and clock_engine's g_bpm
        // are reconciled — see usb/clock_engine.h "Host-instrument tempo
        // integration".
        tud_task();
        usb_audio_stream_task();   // drain the audio ISR's ring into TinyUSB
                                   // (the ONLY writer of the UAC2 FIFO now)
        PollCdc();        // MUST run before anything that can stall, or CDC
                          // commands (including `dfu`) are never parsed
                          // while the loop is busy — exactly when we need them.
        // Buttonless DFU — checked at the head of the loop so the device can
        // always be reflashed over CDC.
        dfuCheck();
        printBootMarksOnce();
        if(clock_engine_get_role() == CLOCK_ROLE_OPG_MASTER) {
            // We're master (the default): derive BPM from the grid's own
            // tempo and hand it to clock_engine every pass; master_tick_poll()
            // emits 24 PPQN 0xF8 / Start / Stop / CC116 / CC119 FROM that
            // value alone — clock_engine never runs a second, independent tempo.
            clock_engine_set_local_bpm(clk.bpm);
        } else {
            // CC116=2 received: Demiurge is master. clock_engine's follower
            // PLL (unchanged, clock_engine.c) derives BPM from the incoming
            // 0xF8 stream; feed THAT back into the clock so the grid follows
            // the bus. Still exactly one clock — only who steers it changes.
            float bus_bpm = clock_engine_get_bpm();
            if(bus_bpm > 1.f) {
                if(bus_bpm < 30.f)  bus_bpm = 30.f;    // same clamp v2 used (60..500 ms/16th)
                if(bus_bpm > 250.f) bus_bpm = 250.f;
                if(bus_bpm != clk.bpm) clockSetBpm(bus_bpm);
            }
        }
        clock_engine_poll();
        PollCdc();
        // Buttonless DFU (MUST PRESERVE — enclosed device, no physical
        // access to BOOT/RESET without disassembly). Checked every loop
        // iteration, same as the source project's own main().
        dfuCheck();

        // ── pads (20 ms FIFO poll) → input events ─────────────────────────
        trellisPollKeys(now, onPad);
        g.trellis_ok = trellisOk();

        // ── encoder / joystick / pad-hold → input events → nav ────────────
        inputPoll(now, encoderDelta(), encoderPressed(), joyPressed(), g.joy_x, g.joy_y, g.pads_held);
        InputEvent ev;
        while(inputPop(ev)) navHandle(ev, now);
        navTick(now);

        // ── sensors (IMU 50 ms + watchdog, lidar, FSR median) → g ─────────
        sensorsTick(now);

        // ── patch autosave debounce + chunked audio save ──────────────────
        patchTick(now);

        // ── OLED @ ~30 fps ────────────────────────────────────────────────
        if(now >= next_oled) {
            next_oled = now + 33;
            oledRenderFrame(now);
            oledFlush();
        }

        // ── NeoTrellis: render → frame → recovery/watchdog + 80 ms push ───
        trellisRenderFrame(now, grb);
        trellisSetFrame(grb);
        trellisTick(now);
    }
}
