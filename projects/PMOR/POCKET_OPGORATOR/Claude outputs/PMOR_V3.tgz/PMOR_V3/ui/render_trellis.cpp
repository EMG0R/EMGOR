// render_trellis.cpp — trellisRenderFrame(): lava base + page overlay + brightness.
// CONTROL plane only. Pad index 0 = top-left, row-major (row*4+col); hw/trellis.cpp
// applies the physical rotation remap after this. Output is GRB per pad (48 bytes).
#include "render.h"
#include "palette.h"
#include "nav.h"
#include "../config.h"
#include "../engine/shared_state.h"
#include "../engine/drums.h"
#include "../engine/synth.h"
#include "../engine/sampler.h"
#include "../engine/fx.h"
#include "../engine/sequencer.h"
#include "../engine/output.h"
#include "../store/patch.h"

// g_trellis_brightness is defined in hw/trellis.cpp (declared in render.h).

// ---------------------------------------------------------------------------
// Optional NavState fields: nav.cpp (written concurrently) may add hold_ms,
// hold_pad, page at the end of NavState. Detect at compile time (SFINAE tag
// dispatch) so this file builds whether or not they exist yet, and falls back
// to sensible defaults when absent (no hold-to-delete visual, page 0).
namespace navopt {
template<typename T> static auto holdMs(const T& n, int) -> decltype((uint32_t)n.hold_ms)  { return (uint32_t)n.hold_ms; }
template<typename T> static uint32_t holdMs(const T&, long) { return 0u; }

template<typename T> static auto holdPad(const T& n, int) -> decltype((int16_t)n.hold_pad) { return (int16_t)n.hold_pad; }
template<typename T> static int16_t holdPad(const T&, long) { return -1; }

template<typename T> static auto page(const T& n, int) -> decltype((uint8_t)n.page) { return (uint8_t)n.page; }
template<typename T> static uint8_t page(const T&, long) { return 0u; }
} // namespace navopt

// ---------------------------------------------------------------------------
// lava base: slow per-pad drifting blend of LAVA A/B/C, ~6% brightness, no pad
// ever fully off. Per-pad speed varies (ported drift idea from V2 pphase/DRIFT).
static const uint8_t LAVA_DRIFT[16] = {1,2,1,2, 2,1,2,1, 1,2,2,1, 2,1,1,2};

static Rgb lavaBase(uint8_t phase) {
    // 3 equal segments across the 0..255 wheel: A->B->C->A
    uint8_t seg = (uint8_t)(phase / 86); if (seg > 2) seg = 2;
    uint8_t rem = (uint8_t)(phase - seg * 86);
    float   t   = (float)rem / 85.f;
    const Rgb& a = (seg == 0) ? C_LAVA_A : (seg == 1) ? C_LAVA_B : C_LAVA_C;
    const Rgb& b = (seg == 0) ? C_LAVA_B : (seg == 1) ? C_LAVA_C : C_LAVA_A;
    return rgbLerp(a, b, t);
}

static void fillLavaBase(Rgb pad[16], uint32_t now_ms) {
    for (uint8_t i = 0; i < 16; i++) {
        uint8_t phase = (uint8_t)(((now_ms >> 5) * LAVA_DRIFT[i]) + i * 23u);
        pad[i] = rgbScale(lavaBase(phase), 0.06f);
    }
}

// ---------------------------------------------------------------------------
// helpers shared by the overlays

static inline bool padHeld(uint8_t pad) { return ((g.pads_held >> pad) & 1u) != 0; }

// current absolute step / bar-local step for one engine's loop, given the
// global transport step g.gstep (wraps at the longest loop, per engine.h).
static void engineSeqPos(Engine e, uint32_t& bar_base, uint32_t& step_in_bar) {
    const LaneSet& l = seq.lane[e];
    uint32_t spb = l.steps_per_bar ? l.steps_per_bar : 1;
    uint32_t loop_len = seqLoopLen(l);
    uint32_t local = loop_len ? (g.gstep % loop_len) : 0u;
    uint32_t bar = local / spb;
    step_in_bar = local % spb;
    bar_base = bar * spb;
}

// ---------------------------------------------------------------------------
// DRUMS

static Rgb drumGroupColor(DrumGroup grp) {
    switch (grp) {
        case DG_KICK:  return C_KICKS;
        case DG_SNARE: return C_SNARES;
        case DG_HAT:   return C_HATS;
        default:       return C_PERC;
    }
}

static void overlayDrums(Rgb pad[16]) {
    if (nav.card == C_SEQ) {
        int lane = (nav.focus_pad >= 0 && nav.focus_pad < 16) ? nav.focus_pad : 0;
        uint32_t bar_base, step_in_bar;
        engineSeqPos(ENG_DRUMS, bar_base, step_in_bar);
        const LaneSet& l = seq.lane[ENG_DRUMS];
        uint8_t spb = l.steps_per_bar; if (spb > 16) spb = 16;
        Rgb tint = drumGroupColor(drumPadGroup((uint8_t)lane));
        for (uint8_t p = 0; p < spb; p++) {
            bool lit = (l.step[bar_base + p] & (uint16_t)(1u << lane)) != 0;
            Rgb c = rgbScale(tint, lit ? 0.9f : 0.15f);
            if (p == step_in_bar) c = rgbLerp(c, C_CURSOR, 0.65f);
            pad[p] = c;
        }
    } else {
        for (uint8_t p = 0; p < 16; p++) {
            if (nav.focus_pad == (int8_t)p) { pad[p] = C_FOCUS; continue; }
            Rgb tint = drumGroupColor(drumPadGroup(p));
            pad[p] = rgbScale(tint, padHeld(p) ? 0.95f : 0.30f);
        }
    }
}

// ---------------------------------------------------------------------------
// SYNTH

static void overlaySynth(Rgb pad[16]) {
    if (nav.card == C_SEQ) {
        int lane = (nav.focus_pad >= 0 && nav.focus_pad < 16) ? nav.focus_pad : 0;
        uint32_t bar_base, step_in_bar;
        engineSeqPos(ENG_SYNTH, bar_base, step_in_bar);
        const LaneSet& l = seq.lane[ENG_SYNTH];
        uint8_t spb = l.steps_per_bar; if (spb > 16) spb = 16;
        for (uint8_t p = 0; p < spb; p++) {
            bool lit = (l.step[bar_base + p] & (uint16_t)(1u << lane)) != 0;
            Rgb c = rgbScale(C_SYNTH, lit ? 0.9f : 0.15f);
            if (p == step_in_bar) c = rgbLerp(c, C_CURSOR, 0.65f);
            pad[p] = c;
        }
    } else {
        for (uint8_t p = 0; p < 16; p++)
            pad[p] = rgbScale(C_SYNTH, padHeld(p) ? 0.95f : 0.25f);
    }
}

// ---------------------------------------------------------------------------
// SAMPLER

static void overlaySampler(Rgb pad[16], uint32_t now_ms) {
    for (uint8_t p = 0; p < 16; p++) {
        bool filled = smp.len[p] > 0;
        pad[p] = rgbScale(C_FILLED, filled ? 0.95f : 0.18f);
        if (!filled) pad[p] = rgbScale(C_SAMPLER, 0.18f);
    }
    if (smp.rec_slot >= 0 && smp.rec_slot < 16) {
        // pulse red: triangle wave 0..1 over ~600 ms
        uint32_t ph = now_ms % 600u;
        float t = (ph < 300u) ? (float)ph / 300.f : 1.f - (float)(ph - 300u) / 300.f;
        pad[smp.rec_slot] = rgbLerp(C_DEL1, C_FOCUS, t);
    }
    int16_t hold_pad = navopt::holdPad(nav, 0);
    if (hold_pad >= 0 && hold_pad < 16) {
        uint32_t hold_ms = navopt::holdMs(nav, 0);
        float t = (float)hold_ms / (float)NAV_HOLD_DELETE_MS;
        pad[hold_pad] = rgbDeleteRamp(t);
    }
}

// ---------------------------------------------------------------------------
// FX

static float clamp01(float v) { return v < 0.f ? 0.f : (v > 1.f ? 1.f : v); }

static void overlayFxHome(Rgb pad[16]) {
    for (uint8_t p = 0; p < 16; p++) {
        int r = p / 4, c = p % 4;
        // weighted blend of the 4 directional colours by position (weights sum to 2)
        float up_w    = (3 - r) / 3.f;
        float down_w  = r / 3.f;
        float left_w  = (3 - c) / 3.f;
        float right_w = c / 3.f;
        float sumw = up_w + down_w + left_w + right_w;   // == 2
        Rgb blend;
        blend.r = (uint8_t)((up_w * C_UP.r + down_w * C_DOWN.r + left_w * C_LEFT.r + right_w * C_RIGHT.r) / sumw + 0.5f);
        blend.g = (uint8_t)((up_w * C_UP.g + down_w * C_DOWN.g + left_w * C_LEFT.g + right_w * C_RIGHT.g) / sumw + 0.5f);
        blend.b = (uint8_t)((up_w * C_UP.b + down_w * C_DOWN.b + left_w * C_LEFT.b + right_w * C_RIGHT.b) / sumw + 0.5f);

        // centredness -> pull toward the HOME orchid blend
        float dr = r - 1.5f, dc = c - 1.5f;
        float dist = (dr < 0 ? -dr : dr); float dc2 = (dc < 0 ? -dc : dc);
        if (dc2 > dist) dist = dc2;                 // Chebyshev distance from centre
        float centred = 1.f - clamp01(dist / 1.5f);
        Rgb base = rgbLerp(blend, C_HOME, centred * 0.8f);

        uint8_t id = fxId(FXD_HOME, p);
        bool held = (fx.held >> id) & 1u;
        pad[p] = rgbScale(base, held ? 1.0f : 0.40f);
    }
}

static void overlayFxDir(Rgb pad[16], FxDir view) {
    Rgb family = (view == FXD_UP) ? C_UP : (view == FXD_RIGHT) ? C_RIGHT : (view == FXD_DOWN) ? C_DOWN : C_LEFT;
    // 12 directional effect pads (top 3 rows)
    for (uint8_t p = 0; p < 12; p++) {
        uint8_t id = fxId(view, p);
        bool held = (fx.held >> id) & 1u;
        pad[p] = rgbScale(family, held ? 1.0f : 0.35f);
    }
    // bottom row (pads 12..15): the home-page pads that belong to this family
    uint8_t j = 0;
    for (uint8_t hp = 0; hp < 16 && j < 4; hp++) {
        if (FX_INFO[hp].family == view) {
            bool held = (fx.held >> hp) & 1u;
            pad[12 + j] = rgbScale(family, held ? 1.0f : 0.45f);
            j++;
        }
    }
    for (; j < 4; j++) pad[12 + j] = rgbScale(family, 0.20f);
}

// ONE continuous colour space. The joystick position (fx.push_x/push_y, +Y = UP)
// tilts the whole grid toward that family's colour and, past the half-way point,
// crossfades the pad LAYOUT to that family's 12 pads. No page flip, no latch: the
// blend follows the stick both ways, so the space "moves" as you push.
static void overlayFx(Rgb pad[16]) {
    Rgb home[16], dir[16];
    overlayFxHome(home);

    float px = fx.push_x, py = fx.push_y;
    float ax = px < 0.f ? -px : px, ay = py < 0.f ? -py : py;
    float mag = ax > ay ? ax : ay;                       // how far we've pushed
    FxDir d = (ax >= ay) ? (px > 0.f ? FXD_RIGHT : FXD_LEFT) : (py > 0.f ? FXD_UP : FXD_DOWN);
    Rgb family = (d == FXD_UP) ? C_UP : (d == FXD_RIGHT) ? C_RIGHT : (d == FXD_DOWN) ? C_DOWN : C_LEFT;

    if (mag < 0.05f) { for (int i = 0; i < 16; i++) pad[i] = home[i]; return; }

    // layout crossfade: 0 below 0.35 deflection, 1 above 0.65 (matches nav's 0.5 switch)
    float lay = clamp01((mag - 0.35f) / 0.30f);
    lay = lay * lay * (3.f - 2.f * lay);                  // smoothstep
    // colour tilt: the whole grid leans toward the family colour from the first millimetre
    float tilt = clamp01(mag * 1.2f) * 0.6f;

    overlayFxDir(dir, d);
    for (int i = 0; i < 16; i++) {
        Rgb h = rgbLerp(home[i], family, tilt);
        pad[i] = rgbLerp(h, dir[i], lay);
    }
}

// ---------------------------------------------------------------------------
// PATCHES

static void overlayPatches(Rgb pad[16]) {
    uint8_t base = (uint8_t)(nav.patch_page * 16);
    uint8_t cur = patchCurrent();
    for (uint8_t p = 0; p < 16; p++) {
        uint8_t slot = (uint8_t)(base + p);
        bool exists = patchExists(slot);
        Rgb c = exists ? rgbScale(C_PATCHES, 0.85f) : rgbScale(C_PATCHES, 0.12f);
        if (slot == cur) c = C_FOCUS;
        if (nav.cursor == p) c = rgbLerp(c, C_CURSOR, 0.6f);
        pad[p] = c;
    }
    int16_t hold_pad = navopt::holdPad(nav, 0);
    if (hold_pad >= 0 && hold_pad < 16) {
        uint32_t hold_ms = navopt::holdMs(nav, 0);
        float t = (float)hold_ms / (float)NAV_HOLD_DELETE_MS;
        pad[hold_pad] = rgbDeleteRamp(t);
    }
}

// ---------------------------------------------------------------------------
// L_VOLUME overlay: green -> amber -> red bar up to the fader level

static void overlayVolume(Rgb pad[16]) {
    float frac = outp.fader / 1.3333f;
    if (frac < 0.f) frac = 0.f;
    if (frac > 1.f) frac = 1.f;
    int pidx = (int)(frac * 16.f); if (pidx > 15) pidx = 15;
    // fader: cyan up to 100 %, yellow past it (the clipper zone), pink at the top — no red
    for (int p = 0; p <= pidx; p++) {
        Rgb c = (p <= 10) ? C_UP : (p <= 13) ? C_DOWN : C_RIGHT;
        if (p == pidx) c = rgbLerp(c, C_FOCUS, 0.35f);
        pad[p] = c;
    }
}

// ---------------------------------------------------------------------------
// L_PADCOUNT overlay: pads 0..(n-1) lit in engine colour

static void overlayPadCount(Rgb pad[16]) {
    Engine e = (nav.menu == M_SYNTH) ? ENG_SYNTH : (nav.menu == M_SMP) ? ENG_SMP : ENG_DRUMS;
    Rgb col = (e == ENG_SYNTH) ? C_SYNTH : (e == ENG_SMP) ? C_SAMPLER : C_DRUMS;
    uint8_t n = seq.lane[e].steps_per_bar;
    if (n > 16) n = 16;
    for (uint8_t p = 0; p < n; p++) pad[p] = rgbScale(col, 0.9f);
}

// ---------------------------------------------------------------------------

// g_trellis_brightness itself is DEFINED in hw/trellis.cpp (declared extern in
// render.h) — we only read it here, per spec step 3.

void trellisRenderFrame(uint32_t now_ms, uint8_t grb_out[48]) {
    Rgb pad[16];
    fillLavaBase(pad, now_ms);

    if (nav.level == L_VOLUME) {
        overlayVolume(pad);
    } else if (nav.level == L_HANDSEQ) {
        Engine e = (nav.menu == M_SYNTH) ? ENG_SYNTH : (nav.menu == M_SMP) ? ENG_SMP : ENG_DRUMS;
        const LaneSet& l = seq.lane[e];
        uint8_t spb = l.steps_per_bar ? l.steps_per_bar : 16;
        Rgb eng = (e == ENG_SYNTH) ? C_SYNTH : (e == ENG_SMP) ? C_SAMPLER : C_DRUMS;
        for (int st = 0; st < 16; st++) {
            if (st >= spb) { pad[st] = rgbScale(pad[st], 0.3f); continue; }
            uint32_t idx = (uint32_t)nav.hand_bar * spb + st;
            bool on = idx < MAXSTEPS && ((l.step[idx] >> nav.hand_target) & 1u);
            pad[st] = on ? eng : rgbScale(eng, 0.12f);
            if (idx == g.gstep) pad[st] = rgbLerp(pad[st], C_CURSOR, 0.6f);
        }
    } else if (nav.level == L_PADCOUNT) {
        overlayPadCount(pad);
    } else {
        switch (nav.menu) {
            case M_DRUMS:   overlayDrums(pad); break;
            case M_SYNTH:   overlaySynth(pad); break;
            case M_SMP:     overlaySampler(pad, now_ms); break;
            case M_FX:      overlayFx(pad); break;
            case M_PATCHES: overlayPatches(pad); break;
            case M_GLOBALS:
            case M_DASH:
            default: break; // dim lava only
        }
    }

    // g_trellis_brightness (0..1, from GLOBALS) is NOT applied here: hw/trellis.cpp's
    // trellisSetFrame() is the one and only place that scales by it before the I2C
    // push (checked: applied exactly once, in hw/).
    for (uint8_t i = 0; i < 16; i++) {
        Rgb c = pad[i];
        grb_out[i * 3 + 0] = c.g;
        grb_out[i * 3 + 1] = c.r;
        grb_out[i * 3 + 2] = c.b;
    }
}
