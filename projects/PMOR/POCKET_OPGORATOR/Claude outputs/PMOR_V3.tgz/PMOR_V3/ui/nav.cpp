// nav.cpp — the interface state machine. See nav.h for the one-rule-set summary
// and PMOR-V3-SPEC.md §1-§8 for the full behaviour this implements.
#include "nav.h"
#include "daisy_seed.h"
extern "C" {
#include "../usb/clock_engine.h"
}
#include "input.h"
#include "render.h"                 // g_trellis_brightness
#include "../config.h"
#include "../engine/shared_state.h"
#include "../engine/clock.h"
#include "../engine/scale.h"
#include "../engine/synth.h"
#include "../engine/drums.h"
#include "../engine/sampler.h"
#include "../engine/fx.h"
#include "../engine/output.h"
#include "../store/patch.h"
#include "../hw/hw.h"                // trellisSetRotation
#include "../engine/engine_util.h"   // clampf
#include <string.h>

NavState nav;
const char* const MENU_NAMES[M_COUNT] = { "DRUMS","SYNTH","SAMPLER","FX","PATCHES","GLOBALS","DASH" };
const char* const CARD_NAMES[C_COUNT] = { "TIMBRE","SEQ","PERFORM" };

// weak: store/patch.cpp may not exist yet, or may never provide one — guarded call
extern void patchFactoryReset() __attribute__((weak));

// ==================================================================== helpers
static inline bool   isEngineMenu(Menu m) { return m == M_DRUMS || m == M_SYNTH || m == M_SMP; }
static inline Engine engineOf(Menu m)     { return m == M_DRUMS ? ENG_DRUMS : (m == M_SYNTH ? ENG_SYNTH : ENG_SMP); }
static inline bool   isHandSeqItem(const Param& p) { return p.name && strcmp(p.name, "HANDSEQ") == 0; }
static inline bool   isPadCountItem(const Param& p) {
    return p.name && (strcmp(p.name, "BARS") == 0 || strcmp(p.name, "STEPS") == 0);
}
// true when items[idx] is the Y half of a PF_PAIR_X pair (not independently selectable)
static inline bool isPairY(const ParamPage& pg, uint8_t idx) {
    return idx > 0 && idx < pg.count && (pg.items[idx - 1].flags & PF_PAIR_X);
}
// moves nav.cursor by `dir` (±1), hard-stopped, skipping the Y half of a pair
static void moveCursor(const ParamPage& pg, int8_t dir) {
    if(pg.count == 0 || dir == 0) return;
    int c = (int)nav.cursor + dir;
    if(c < 0) c = 0;
    if(c > pg.count - 1) c = pg.count - 1;
    if(isPairY(pg, (uint8_t)c)) {
        int c2 = c + dir;
        if(c2 >= 0 && c2 <= pg.count - 1) c = c2;
    }
    nav.cursor = (uint8_t)c;
}

// ==================================================================== GLOBALS shadow params
// Param.value must be a float*; several Globals fields aren't float (or aren't
// stored anywhere at all, e.g. ROTATE), so every GLOBALS item edits a local
// shadow float here and navTick() diffs shadow-vs-applied to push it live.
static float s_g_key, s_g_scale, s_g_bpm, s_g_ingain, s_g_bright, s_g_oled, s_g_clock, s_g_rotate, s_g_swing, s_g_factory;
static float s_ga_key, s_ga_scale, s_ga_bpm, s_ga_ingain, s_ga_bright, s_ga_oled, s_ga_clock, s_ga_rotate, s_ga_swing, s_ga_factory;

static const char* const CLOCK_MODE_NAMES[6] = { "SY0","SY1","SY2","SY3","SY4","SY5" };
static const char* const ROTATE_NAMES[4]     = { "0","90","180","270" };
static const char* const YESNO_NAMES[2]      = { "NO","YES" };

static const Param GLOBAL_PARAMS[] = {
    { "KEY",     &s_g_key,     -12.f, 12.f, 0.01f, (uint8_t)PF_BIPOLAR,             nullptr },
    { "SCALE",   &s_g_scale,     0.f, (float)(SCALE_MODES - 1), 1.f, (uint8_t)(PF_QUANT | PF_ENUM), SCALE_MODE_NAMES },
    { "BPM",     &s_g_bpm,      30.f, 300.f, 1.f, (uint8_t)PF_QUANT,                nullptr },
    { "INGAIN",  &s_g_ingain,    0.f, 2.f,  0.01f, (uint8_t)PF_PERCENT,             nullptr },
    { "BRIGHT",  &s_g_bright,    0.f, 1.f,  0.01f, (uint8_t)PF_PERCENT,             nullptr },
    { "OLEDBRT", &s_g_oled,      1.f, 32.f,  1.f, (uint8_t)PF_QUANT,                nullptr },
    { "CLOCK",   &s_g_clock,     0.f, 5.f,   1.f, (uint8_t)(PF_QUANT | PF_ENUM),    CLOCK_MODE_NAMES },
    { "ROTATE",  &s_g_rotate,    0.f, 3.f,   1.f, (uint8_t)(PF_QUANT | PF_ENUM),    ROTATE_NAMES },
    { "SWING",   &s_g_swing,     0.f, 1.f,  0.01f, (uint8_t)PF_PERCENT,             nullptr },
    { "FACTORY", &s_g_factory,   0.f, 1.f,   1.f, (uint8_t)(PF_QUANT | PF_ENUM),    YESNO_NAMES },
};
static const ParamPage GLOBAL_PAGE = { "GLOBALS", GLOBAL_PARAMS, sizeof(GLOBAL_PARAMS) / sizeof(GLOBAL_PARAMS[0]) };

static void globalsRefreshShadow() {
    s_g_key    = s_ga_key    = scale.key_semis;
    s_g_scale  = s_ga_scale  = (float)scale.mode;
    s_g_bpm    = s_ga_bpm    = clk.bpm;
    s_g_ingain = s_ga_ingain = outp.input_gain;
    s_g_bright = s_ga_bright = g_trellis_brightness;
    s_g_oled   = s_ga_oled   = glob.oled_contrast;
    s_g_clock  = s_ga_clock  = (float)glob.clock_mode;
    s_g_swing  = s_ga_swing  = clk.swing;
    s_g_factory = s_ga_factory = 0.f;            // momentary confirm, never reflects stored state
    // ROTATE has no backing store to read from; keep whatever was last applied (default 0)
    s_g_rotate = s_ga_rotate;
}

// diff shadow-vs-last-applied and push each change into the real engines, live
static void globalsApply() {
    if(s_g_key != s_ga_key)       { scale.key_semis = s_g_key; scaleRebuild(); s_ga_key = s_g_key; }
    if(s_g_scale != s_ga_scale)   { scale.mode = (uint8_t)s_g_scale; scaleRebuild(); s_ga_scale = s_g_scale; }
    if(s_g_bpm != s_ga_bpm)       { clockSetBpm(s_g_bpm); s_ga_bpm = s_g_bpm; }
    if(s_g_ingain != s_ga_ingain) { outp.input_gain = s_g_ingain; s_ga_ingain = s_g_ingain; }
    if(s_g_bright != s_ga_bright) { g_trellis_brightness = s_g_bright; s_ga_bright = s_g_bright; }
    if(s_g_oled != s_ga_oled)     { glob.oled_contrast = s_g_oled; oledSetContrast((uint8_t)(s_g_oled + 0.5f)); globalsSave(); s_ga_oled = s_g_oled; }
    if(s_g_clock != s_ga_clock)   { glob.clock_mode = (uint8_t)s_g_clock; clock_engine_set_sync_mode((sync_mode_t)glob.clock_mode); globalsSave(); s_ga_clock = s_g_clock; }
    if(s_g_rotate != s_ga_rotate) { trellisSetRotation((uint8_t)s_g_rotate); s_ga_rotate = s_g_rotate; }
    if(s_g_swing != s_ga_swing)   { clk.swing = s_g_swing; s_ga_swing = s_g_swing; }
    if(s_g_factory != s_ga_factory) {
        if(s_g_factory > 0.5f && patchFactoryReset) patchFactoryReset();
        s_ga_factory = s_g_factory;
    }
}

// ==================================================================== SYNTH timbre pages
static const ParamPage EMPTY_PAGE = { "", nullptr, 0 };
static inline const ParamPage& safePage(const ParamPage* p) { return p ? *p : EMPTY_PAGE; }

static float    s_syn_algo_shadow = 0.f, s_syn_algo_applied = 0.f;
static Param    s_syn_algo_items[1];
static Param    s_syn_mix_items[1];
static ParamPage s_synth_pages[7];

static float    s_drum_mix_dummy;   // unused placeholder, keeps array declarations symmetric
static ParamPage s_single_page_buf;
static ParamPage s_single_page_arr[1];

const ParamPage* navTimbrePages(Engine e, uint8_t& count) {
    if(e == ENG_SYNTH) {
        // don't clobber the shadow while it is the live edit target (see navTick)
        if(!(nav.level == L_EDIT1 && nav.edit == &s_syn_algo_items[0]))
            s_syn_algo_shadow = (float)syn.algo;
        s_syn_algo_items[0] = { "ALGO", &s_syn_algo_shadow, 0.f, (float)(ALG_COUNT - 1), 1.f,
                                 (uint8_t)(PF_QUANT | PF_ENUM), SYN_ALGO_NAMES };
        s_synth_pages[0] = { "ALGO", s_syn_algo_items, 1 };
        s_synth_pages[1] = safePage(synAlgoParamPage(syn.algo));
        s_synth_pages[2] = safePage(synEnvPage());
        s_synth_pages[3] = safePage(synFilterPage());
        s_synth_pages[4] = safePage(synPitchPage());
        s_synth_pages[5] = safePage(synWidthPage());
        s_syn_mix_items[0] = { "VOL", &syn.volume, 0.f, ENGINE_VOL_MAX, 0.01f, (uint8_t)PF_PERCENT, nullptr };
        s_synth_pages[6] = { "MIX", s_syn_mix_items, 1 };
        count = 7;
        return s_synth_pages;
    }
    if(e == ENG_DRUMS) {
        s_single_page_buf = (nav.focus_pad >= 0) ? safePage(drumsPadPage((uint8_t)nav.focus_pad))
                                                  : safePage(drumsMixPage());
        s_single_page_arr[0] = s_single_page_buf;
        count = 1;
        (void)s_drum_mix_dummy;
        return s_single_page_arr;
    }
    if(e == ENG_SMP) {
        s_single_page_buf = (nav.focus_pad >= 0) ? safePage(samplerSlotPage((uint8_t)nav.focus_pad))
                                                  : safePage(samplerMixPage());
        s_single_page_arr[0] = s_single_page_buf;
        count = 1;
        return s_single_page_arr;
    }
    count = 0;
    return nullptr;
}

// ==================================================================== SEQ card page
// seqParamPage(e) (engine/sequencer.cpp) already includes exactly one BARS and one
// STEPS item per engine (pointing at LaneSet::bars_f/steps_f, kept in sync by
// seqSetBars/seqSetStepsPerBar). Cross-module fix: this used to ALSO append its own
// shadow BARS/STEPS pair on top of that, showing each twice in the SEQ list — just
// pass the page straight through.
static inline const ParamPage* buildSeqPage(Engine e) { return seqParamPage(e); }

// ==================================================================== navCurrentPage
const ParamPage* navCurrentPage() {
    switch(nav.menu) {
        case M_DRUMS: case M_SYNTH: case M_SMP: {
            Engine e = engineOf(nav.menu);
            if(nav.card == C_TIMBRE) {
                uint8_t cnt = 0;
                const ParamPage* pages = navTimbrePages(e, cnt);
                if(!pages || cnt == 0) return nullptr;
                uint8_t pg = (nav.page < cnt) ? nav.page : (uint8_t)(cnt - 1);
                return &pages[pg];
            }
            if(nav.card == C_SEQ) return buildSeqPage(e);
            return nullptr;   // PERF: no list, joystick is performance
        }
        case M_GLOBALS: return &GLOBAL_PAGE;
        case M_FX: case M_PATCHES: case M_DASH: default: return nullptr;
    }
}

// ==================================================================== both-press undo bookkeeping
static NavLevel s_pre_joy_level;
static Menu     s_pre_joy_menu;
static Card     s_pre_joy_card;
static uint8_t  s_pre_joy_cursor;
static int8_t   s_pre_joy_focus;
static NavLevel s_return_level = L_RING;   // where L_VOLUME closes back to
// FX: which effect id each physical pad pressed, so the RELEASE frees that exact id even
// if the stick (and therefore fx.view) moved in between. Without this the effect latched.
static uint8_t  s_pad_fx_id[16] = {0};
static bool     s_pad_fx_down[16] = {false};

static void closeVolume() {
    nav.level = s_return_level;
    nav.vol_overlay = false;
}

// ==================================================================== padcount (BARS/STEPS chooser)
static void padCountApply(uint8_t pad) {
    const ParamPage* pg = navCurrentPage();
    if(!pg || nav.cursor >= pg->count) { nav.level = L_CARD; return; }
    const Param& p = pg->items[nav.cursor];
    Engine e = engineOf(nav.menu);
    uint8_t val = (uint8_t)(pad + 1);
    if(strcmp(p.name, "BARS") == 0)       seqSetBars(e, val);
    else if(strcmp(p.name, "STEPS") == 0) seqSetStepsPerBar(e, val);
    nav.level = L_CARD;
}

// ==================================================================== encoder turn
static void handleEncTurn(int8_t dir, uint32_t /*now_ms*/) {
    // THE RULE: the encoder only ever changes the main menu. Anywhere below the root
    // ring a turn is the BACK button (one level per detent); at the root it moves the ring.
    switch(nav.level) {
        case L_RING: {
            Menu old = nav.menu;
            int m = (int)nav.menu + dir;
            if(m < 0) m = 0;
            if(m > M_COUNT - 1) m = M_COUNT - 1;
            nav.menu = (Menu)m;
            if(nav.menu != old) {
                fxReleaseAll();
                nav.focus_pad = -1;
                syn.perf_active = false;
                fx.perf_engine = 0xFF;
                nav.card = C_TIMBRE; nav.cursor = 0; nav.page = 0;
                nav.dive_ms = daisy::System::GetNow();          // page-switch animation
            }
            break;
        }
        case L_VOLUME:   closeVolume(); break;
        case L_EDIT1: case L_EDIT2:
            nav.level = L_CARD; nav.edit = nullptr; break;
        case L_PADCOUNT: nav.level = L_CARD; break;
        case L_HANDSEQ:  nav.level = L_CARD; break;
        case L_CARD:
            if(nav.focus_pad >= 0) { nav.focus_pad = -1; break; }   // first back = un-focus
            nav.level = L_RING; nav.cursor = 0; break;
        default: nav.level = L_RING; break;
    }
}

// ==================================================================== joystick press
static void handleJoyPress(uint32_t /*now_ms*/) {
    if(nav.level == L_VOLUME) { closeVolume(); return; }

    s_pre_joy_level  = nav.level;
    s_pre_joy_menu   = nav.menu;
    s_pre_joy_card   = nav.card;
    s_pre_joy_cursor = nav.cursor;
    s_pre_joy_focus  = nav.focus_pad;

    switch(nav.level) {
        case L_RING:
            if(isEngineMenu(nav.menu)) {
                nav.level = L_CARD; nav.cursor = 0; nav.page = 0;
            } else if(nav.menu == M_FX) {
                // nothing on click: automation records while the button is HELD (see navTick)
            } else if(nav.menu == M_PATCHES) {
                {   // click: existing slot = load it; empty slot = start a fresh patch there (v2 sessionNew)
                    uint8_t slot = (uint8_t)(nav.patch_page * 16 + nav.cursor);
                    if(patchExists(slot)) patchLoad(slot); else patchNew(slot);   // stays at L_RING
                }
            } else if(nav.menu == M_GLOBALS) {
                globalsRefreshShadow();
                nav.level = L_CARD; nav.cursor = 0; nav.page = 0;
            } else if(nav.menu == M_DASH) {
                nav.level = L_CARD; nav.cursor = 0; nav.page = 0;
            }
            break;
        case L_CARD: {
            if(nav.focus_pad >= 0) { nav.focus_pad = -1; break; }    // un-focus only
            const ParamPage* pg = navCurrentPage();
            if(!pg || pg->count == 0) { nav.level = L_RING; break; }
            uint8_t idx = (nav.cursor < pg->count) ? nav.cursor : 0;
            const Param& p = pg->items[idx];
            if(isHandSeqItem(p)) {
                nav.level = L_HANDSEQ; nav.hand_bar = 0;
            } else if(isPadCountItem(p)) {
                nav.level = L_PADCOUNT;
            } else if(p.value != nullptr) {
                nav.edit = &p;
                nav.level = (p.flags & PF_PAIR_X) ? L_EDIT2 : L_EDIT1;
            } else {
                nav.level = L_RING;
            }
            break;
        }
        case L_EDIT1: case L_EDIT2:
            nav.level = L_CARD;
            nav.edit = nullptr;
            break;
        case L_PADCOUNT:
            nav.level = L_CARD;
            break;
        case L_HANDSEQ:
            nav.level = L_CARD;
            break;
        default: break;
    }
}

// ==================================================================== both-press (volume shortcut)
// first_btn: which button was pressed FIRST (0 = encoder, 1 = joystick), carried in
// IN_BOTH_PRESS.a by input.cpp. Cross-module fix: nav.last_single is not reliable here —
// by the time this event is processed it may have been overwritten by the second
// button's own event (see input.cpp's handleButton for the full rationale).
static void handleBothPress(int8_t first_btn, uint32_t /*now_ms*/) {
    if(first_btn == 0) {
        clockUntap();
    } else if(first_btn == 1) {
        nav.level  = s_pre_joy_level;
        nav.menu   = s_pre_joy_menu;
        nav.card   = s_pre_joy_card;
        nav.cursor = s_pre_joy_cursor;
        nav.focus_pad = s_pre_joy_focus;
    }
    s_return_level = nav.level;
    nav.level = L_VOLUME;
    nav.vol_overlay = true;
}

// ==================================================================== joystick nav (flick)
static void handleJoyNav(int8_t dx, int8_t dy, uint32_t /*now_ms*/) {
    // focused drum pad: dx swipes its 16 sounds, hard stops (takes priority over list nav)
    if(nav.focus_pad >= 0 && nav.menu == M_DRUMS && nav.card == C_TIMBRE) {
        if(dx != 0) {
            int s = (int)drums.pad[nav.focus_pad].sound + dx;
            if(s < 0) s = 0;
            if(s > DRUM_SOUNDS - 1) s = DRUM_SOUNDS - 1;
            drums.pad[nav.focus_pad].sound = (uint8_t)s;
        }
        return;
    }

    if(nav.level == L_HANDSEQ) {
        Engine e = engineOf(nav.menu);
        if(dx != 0) nav.hand_target = (uint8_t)((nav.hand_target + 16 + dx) % 16);
        if(dy != 0) {
            int b = (int)nav.hand_bar + dy;                     // +Y = UP = next bar
            int maxb = (int)seq.lane[e].bars - 1; if(maxb < 0) maxb = 0;
            if(b < 0) b = 0; if(b > maxb) b = maxb;
            nav.hand_bar = (uint8_t)b;
        }
        return;
    }
    switch(nav.level) {
        case L_RING:
            if(isEngineMenu(nav.menu)) {
                if(dx != 0) {
                    int c = (int)nav.card + dx;
                    if(c < 0) c = 0;
                    if(c > C_COUNT - 1) c = C_COUNT - 1;
                    if((Card)c != nav.card) { nav.card = (Card)c; nav.page = 0; nav.cursor = 0; }
                }
            } else if(nav.menu == M_PATCHES) {
                if(dx != 0) {
                    int p = (int)nav.patch_page + dx;
                    if(p < 0) p = 0;
                    if(p > PATCH_PAGES - 1) p = PATCH_PAGES - 1;
                    nav.patch_page = (uint8_t)p;
                }
                if(dy != 0) {
                    int c = (int)nav.cursor - dy * 4;                   // +Y = UP = one row up on the 4x4
                    if(c < 0) c = 0;
                    if(c > 15) c = 15;
                    nav.cursor = (uint8_t)c;
                }
            }
            // FX: view is set continuously in navTick from g.joy_x/joy_y, not from this event
            break;
        case L_CARD: {
            if(nav.card == C_PERF) break;   // no list; joystick is live performance
            const ParamPage* pg = navCurrentPage();
            if(dy != 0 && pg) moveCursor(*pg, (int8_t)-dy);   // +Y = UP = previous item
            if(dx != 0 && isEngineMenu(nav.menu) && nav.card == C_TIMBRE) {
                uint8_t cnt = 0;
                navTimbrePages(engineOf(nav.menu), cnt);
                int pg2 = (int)nav.page + dx;
                if(pg2 < 0) pg2 = 0;
                if(cnt > 0 && pg2 > cnt - 1) pg2 = cnt - 1;
                if((uint8_t)pg2 != nav.page) { nav.page = (uint8_t)pg2; nav.cursor = 0; }
            }
            break;
        }
        default: break;   // editors read joy_x/joy_y continuously in navTick
    }
}

// ==================================================================== joystick gesture (focused pad reverse)
static void handleGesture(int8_t a) {
    if(nav.focus_pad < 0) return;
    if(nav.menu == M_DRUMS && nav.card == C_TIMBRE) {
        drums.pad[nav.focus_pad].reverse = (a < 0);     // -1 CCW = reverse, +1 CW = forward
    } else if(nav.menu == M_SMP && nav.card == C_TIMBRE) {
        smp.slot[nav.focus_pad].reverse = (a < 0);
    }
}

// ==================================================================== pads
static void handlePadPress(uint8_t pad, uint32_t /*now_ms*/) {
    if(nav.level == L_VOLUME) {
        outp.fader = clampf((float)pad / 11.25f, 0.f, 1.333f);
        return;
    }
    if(nav.level == L_PADCOUNT) { padCountApply(pad); return; }
    if(nav.level == L_HANDSEQ) {                      // pads = the 16 steps of hand_bar for hand_target
        Engine e = engineOf(nav.menu);
        uint8_t spb = seq.lane[e].steps_per_bar; if(spb == 0) spb = 16;
        if(pad < spb) seqToggle(e, (uint32_t)nav.hand_bar * spb + pad, nav.hand_target);
        return;
    }

    switch(nav.menu) {
        case M_FX: {
            uint8_t id = fxId(fx.view, pad);
            s_pad_fx_id[pad] = id; s_pad_fx_down[pad] = true;
            fxPress(id);
            return;
        }
        case M_PATCHES: nav.cursor = pad; return;
        case M_GLOBALS: case M_DASH: return;
        default: break;
    }
    if(!isEngineMenu(nav.menu)) return;

    switch(nav.card) {
        case C_TIMBRE:
            if(nav.menu == M_DRUMS) {
                if(nav.focus_pad >= 0 && nav.focus_pad != (int8_t)pad) nav.focus_pad = (int8_t)pad;
                drumsPreview(pad);
            } else if(nav.menu == M_SYNTH) {
                synthNoteOn(pad, 1.f);
            } else if(nav.menu == M_SMP) {
                if(nav.focus_pad >= 0 && nav.focus_pad != (int8_t)pad) nav.focus_pad = (int8_t)pad;
                if(smp.len[pad] > 0) samplerPlay(pad, 1.f);
                else                 samplerRecordStart(pad);
            }
            break;
        case C_SEQ:
            if(nav.menu == M_DRUMS) {
                drumsPreview(pad);
                if(seq.lane[ENG_DRUMS].mode == SEQ_PLAY && seq.lane[ENG_DRUMS].rec_on > 0.5f) seqRecordHit(ENG_DRUMS, pad, clockSampleNow());
            } else if(nav.menu == M_SYNTH) {
                synthNoteOn(pad, 1.f);
                if(seq.lane[ENG_SYNTH].mode == SEQ_PLAY && seq.lane[ENG_SYNTH].rec_on > 0.5f) seqRecordHit(ENG_SYNTH, pad, clockSampleNow());
            } else if(nav.menu == M_SMP) {
                if(smp.len[pad] > 0) samplerPlay(pad, 1.f);
                if(seq.lane[ENG_SMP].mode == SEQ_PLAY && seq.lane[ENG_SMP].rec_on > 0.5f) seqRecordHit(ENG_SMP, pad, clockSampleNow());
            }
            break;
        case C_PERF:
            if(nav.menu == M_DRUMS) {
                drumsPreview(pad);
                fx.perf_engine = ENG_DRUMS;
            } else if(nav.menu == M_SYNTH) {
                synthNoteOn(pad, 1.f);
            } else if(nav.menu == M_SMP) {
                if(smp.len[pad] > 0) samplerPlay(pad, 1.f);
                fx.perf_engine = ENG_SMP;
            }
            break;
        default: break;
    }
}

static void handlePadRelease(uint8_t pad, uint32_t /*now_ms*/) {
    if(nav.level == L_VOLUME || nav.level == L_PADCOUNT) return;
    switch(nav.menu) {
        case M_FX:
            if(s_pad_fx_down[pad]) { fxRelease(s_pad_fx_id[pad]); s_pad_fx_down[pad] = false; }
            return;
        case M_PATCHES: case M_GLOBALS: case M_DASH: return;
        default: break;
    }
    if(!isEngineMenu(nav.menu)) return;
    if(nav.menu == M_SMP && nav.card == C_TIMBRE) {
        if(smp.rec_slot == (int8_t)pad) samplerRecordStop();
    } else if(nav.menu == M_SYNTH) {
        synthNoteOff(pad);
    }
    // drums: one-shot triggers, no release behaviour
}

static void handlePadHold(uint8_t pad, uint32_t held_ms, uint32_t /*now_ms*/) {
    nav.hold_pad = (int8_t)pad;
    nav.hold_ms  = held_ms;

    if(nav.menu == M_PATCHES && nav.level == L_RING) {
        if(held_ms >= NAV_HOLD_DELETE_MS) {
            patchDelete((uint8_t)(nav.patch_page * 16 + pad));
            nav.hold_ms = 0; nav.hold_pad = -1;
        }
        return;
    }
    if((nav.menu == M_DRUMS || nav.menu == M_SMP) && nav.card == C_SEQ && nav.level == L_CARD) {
        if(held_ms >= 1500 && held_ms < 1600) seqClearLane(engineOf(nav.menu), pad);   // once, at 1.5 s
        return;
    }
    if(nav.menu == M_DRUMS && nav.card == C_TIMBRE) {
        if(held_ms >= 500) nav.focus_pad = (int8_t)pad;
        return;
    }
    if(nav.menu == M_SMP && nav.card == C_TIMBRE) {
        if(smp.len[pad] == 0) return;   // only filled slots focus or delete
        if(held_ms >= 500) nav.focus_pad = (int8_t)pad;
        if(held_ms >= NAV_HOLD_DELETE_MS) {
            samplerDelete(pad);
            if(nav.focus_pad == (int8_t)pad) nav.focus_pad = -1;
            nav.hold_ms = 0; nav.hold_pad = -1;
        }
        return;
    }
}

// ==================================================================== navHandle
void navHandle(const InputEvent& e, uint32_t now_ms) {
    if(e.type != IN_PAD_PRESS && e.type != IN_PAD_RELEASE && e.type != IN_PAD_HOLD) {
        nav.saver = false;
        nav.last_nav_ms = now_ms;
    }
    switch(e.type) {
        case IN_ENC_PRESS:
            clockTap(now_ms);                 // ALWAYS. Nothing else, except closing an open volume overlay.
            if(nav.level == L_VOLUME) closeVolume();
            nav.last_single = e;
            break;
        case IN_ENC_TURN:    handleEncTurn((int8_t)e.a, now_ms); break;
        case IN_JOY_PRESS:   handleJoyPress(now_ms); nav.last_single = e; break;
        case IN_BOTH_PRESS:  handleBothPress((int8_t)e.a, now_ms); break;
        case IN_JOY_NAV:     handleJoyNav((int8_t)e.a, (int8_t)e.b, now_ms); break;
        case IN_JOY_GESTURE: handleGesture((int8_t)e.a); break;
        case IN_PAD_PRESS:   handlePadPress((uint8_t)e.a, now_ms); break;
        case IN_PAD_RELEASE: handlePadRelease((uint8_t)e.a, now_ms); break;
        case IN_PAD_HOLD:    handlePadHold((uint8_t)e.a, (uint32_t)e.b, now_ms); break;
        default: break;
    }
}

// ==================================================================== navTick
void navTick(uint32_t now_ms) {
    auto stickNorm = [](float j) { float t = 0.5f + 0.5f * (j / EDIT_STICK_FULL); return t < 0.f ? 0.f : (t > 1.f ? 1.f : t); };
    if(!nav.saver && (now_ms - nav.last_nav_ms) > SAVER_IDLE_MS) nav.saver = true;

    syn.perf_active = (nav.level == L_CARD && nav.card == C_PERF && nav.menu == M_SYNTH);

    // ---- FX view: continuous, no latch, snaps home under 0.35 deflection
    if(nav.menu != M_FX) { fx.push_x = 0.f; fx.push_y = 0.f; fx.auto_rec = false; }
    else fx.auto_rec = g.joy_sw;   // v2 rule: hold the joystick button = record automation this step; empty hands scrub it clean
    if(nav.menu == M_FX) {
        float jx = g.joy_x, jy = g.joy_y;
        float ax = jx < 0.f ? -jx : jx, ay = jy < 0.f ? -jy : jy;
        if(ax > 0.5f || ay > 0.5f) {
            if(ax >= ay) fxSetView(jx > 0.f ? FXD_RIGHT : FXD_LEFT);
            else         fxSetView(jy > 0.f ? FXD_UP    : FXD_DOWN);   // +Y = UP
        } else if(ax < 0.35f && ay < 0.35f) {
            fxSetView(FXD_HOME);
        }
        fx.push_x = jx; fx.push_y = jy;                                // continuous colour-space position
        // HOME FILTER pad: joystick L/R sweeps the filter while it's held (nav write,
        // per fx.h's contract for fx.filter_pos); left as-is on release.
        if(fx.held & (1ULL << fxId(FXD_HOME, 12))) {
            fx.filter_pos = 0.5f + 0.5f * jx;
        }
    }

    // ---- volume overlay: joystick X also drives the fader
    if(nav.level == L_VOLUME) {
        outp.fader = clampf(stickNorm(g.joy_x) * 1.333f, 0.f, 1.333f);
    }

    // ---- universal editors: value jumps to the stick immediately
    // editors: +-EDIT_STICK_FULL of stick = full range, so you never have to pin it to the edge
    if(nav.level == L_EDIT1 && nav.edit) {
        float nv = paramDenorm(*nav.edit, stickNorm(g.joy_x));
        if(nv != *nav.edit->value) { *nav.edit->value = nv; patchMarkDirty(); }
        if(nav.edit->value == &s_syn_algo_shadow) {
            uint8_t a = (uint8_t)clampf(s_syn_algo_shadow, 0.f, (float)(ALG_COUNT - 1));
            if(a != syn.algo) syn.algo = a;
            s_syn_algo_applied = s_syn_algo_shadow;
        }
    } else if(nav.level == L_EDIT2 && nav.edit) {
        const Param& px = *nav.edit;
        const Param& py = *(nav.edit + 1);
        float nvx = paramDenorm(px, stickNorm(g.joy_x));
        float nvy = paramDenorm(py, stickNorm(g.joy_y));
        bool changed = (nvx != *px.value) || (nvy != *py.value);
        *px.value = nvx;
        *py.value = nvy;
        if(changed) patchMarkDirty();
    }

    // ---- sampler focused-pad live control
    if(nav.menu == M_SMP && nav.card == C_TIMBRE && nav.focus_pad >= 0) {
        smp.slot[nav.focus_pad].formant = clampf(g.joy_x, -1.f, 1.f);
        smp.slot[nav.focus_pad].pitch   = clampf(g.joy_y, -1.f, 1.f);
    }

    // ---- performance cards: continuous joystick / accel mappings
    if(nav.level == L_CARD && nav.card == C_PERF) {
        const float dz = 0.15f;
        float jx = g.joy_x, jy = g.joy_y;
        if(nav.menu == M_SYNTH) {
            if(jy > 0.6f)       syn.perf_octave =  1.f;
            else if(jy < -0.6f) syn.perf_octave = -1.f;
            else                syn.perf_octave =  0.f;
            syn.master_prob = 0.5f + 0.5f * jx;
            seq.lane[ENG_SYNTH].probability = syn.master_prob;
            syn.perf_env_macro = 0.5f + 0.5f * g.accel_x;
        } else if(nav.menu == M_DRUMS || nav.menu == M_SMP) {
            fx.perf_engine = (nav.menu == M_DRUMS) ? ENG_DRUMS : ENG_SMP;
            fx.perf_up    = (jy >  dz) ? clampf(( jy - dz) / (1.f - dz), 0.f, 1.f) : 0.f;   // +Y = UP
            fx.perf_down  = (jy < -dz) ? clampf((-jy - dz) / (1.f - dz), 0.f, 1.f) : 0.f;
            fx.perf_right = (jx >  dz) ? clampf(( jx - dz) / (1.f - dz), 0.f, 1.f) : 0.f;
            fx.perf_left  = (jx < -dz) ? clampf((-jx - dz) / (1.f - dz), 0.f, 1.f) : 0.f;
        }
    } else if(fx.perf_engine != 0xFF) {
        // cross-module fix: leaving the drums/sampler PERF card used to leave
        // fx.perf_engine and perf_up/right/down/left exactly where the joystick
        // last put them — the throw kept applying (and audio_callback kept
        // routing that engine through its own perf bus) until an unrelated 3 s
        // tail timer in audio_callback.cpp happened to expire. Clear here,
        // immediately, per spec. audio_callback.cpp latches the engine
        // separately so effect tails (spring reverb etc.) still ring out
        // naturally instead of being cut off by this clear.
        fx.perf_engine = 0xFF;
        fx.perf_up = fx.perf_right = fx.perf_down = fx.perf_left = 0.f;
    }

    globalsApply();
}

// ==================================================================== navInit
void navInit() {
    nav.menu = M_DRUMS;
    nav.card = C_TIMBRE;
    nav.level = L_RING;
    nav.cursor = 0;
    nav.page = 0;
    nav.edit = nullptr;
    nav.focus_pad = -1;
    nav.perf_active = false;
    nav.last_nav_ms = 0;
    nav.saver = false;
    nav.vol_overlay = false;
    nav.patch_page = 0;
    nav.hold_ms = 0;
    nav.hold_pad = -1;
    nav.dive_ms = 0;
    nav.hand_target = 0; nav.hand_bar = 0;
    nav.last_single.type = IN_NONE;
    nav.last_single.a = nav.last_single.b = 0;
    nav.last_single.t_ms = 0;
    s_return_level = L_RING;
    s_syn_algo_applied = -1.f;   // force a first sync on the next navTick/navTimbrePages call
    globalsRefreshShadow();
}
