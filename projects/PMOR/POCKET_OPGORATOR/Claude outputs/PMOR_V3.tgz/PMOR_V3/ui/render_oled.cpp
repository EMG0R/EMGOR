// render_oled.cpp — oledRenderFrame() + widgets. CONTROL plane only, 128x64 landscape.
#include "render.h"
#include "nav.h"
#include "../config.h"
#include "../hw/hw.h"
#include "../engine/shared_state.h"
#include "../engine/param.h"
#include "../engine/fx.h"
#include "../engine/sequencer.h"
#include "../engine/output.h"
#include "../store/patch.h"
#include "../store/files.h"
#include <stdio.h>
#include <string.h>

// tinyusb symbol, forward-declared rather than pulling in the full stack (owned by usb/).
#include "tusb.h"

// ---------------------------------------------------------------------------
// value formatting shared by wList / wSlider

static void fmtParamValue(char* out, size_t n, const Param& p, float v) {
    if (p.flags & PF_ENUM) {
        int idx = (int)v;
        if (idx < 0) idx = 0;
        snprintf(out, n, "%s", p.names ? p.names[idx] : "?");
    } else if (p.flags & PF_PERCENT) {
        snprintf(out, n, "%3d%%", (int)(paramNorm(p, v) * 100.f + 0.5f));
    } else if (p.flags & PF_BIPOLAR) {
        snprintf(out, n, "%+.2f", (double)v);
    } else {
        snprintf(out, n, "%.2f", (double)v);
    }
}

// ---------------------------------------------------------------------------
// widgets

void wTitle(const char* s) {
    oledText(2, 0, s, true);
}

void wCards(const char* const* names, int n, int sel) {
    // three big rounded cards, left -> right, filling the 128x64 area below the title
    int cardW = 38, cardH = 40, gap = 4;
    int totalW = n * cardW + (n - 1) * gap;
    int x0 = (128 - totalW) / 2; if (x0 < 1) x0 = 1;
    int y0 = 16;
    for (int i = 0; i < n; i++) {
        int x = x0 + i * (cardW + gap);
        bool selected = (i == sel);
        oledRoundRect(x, y0, x + cardW, y0 + cardH, 6, true, selected);
        int tw = (int)strlen(names[i]) * 6;
        int tx = x + (cardW - tw) / 2; if (tx < x + 1) tx = x + 1;
        int ty = y0 + cardH / 2 - 4;
        oledText(tx, ty, names[i], !selected);
    }
}

void wList(const ParamPage* page, int cursor, int top) {
    if (!page || page->count == 0) return;
    const int rowH = 8, y0 = 10, rowsVisible = 6;
    for (int r = 0; r < rowsVisible; r++) {
        int idx = top + r;
        if (idx >= page->count) break;
        const Param& p = page->items[idx];
        int y = y0 + r * rowH;
        bool sel = (idx == cursor);
        if (sel) oledRect(0, y - 1, 127, y + 7, true, true);
        char line[24];
        char val[12];
        fmtParamValue(val, sizeof val, p, *p.value);
        snprintf(line, sizeof line, " %-8s %6s", p.name, val);
        oledText(0, y, line, !sel);
    }
}

void wSlider(const Param& p, float value) {
    wTitle(p.name);
    char val[16];
    fmtParamValue(val, sizeof val, p, value);
    oledTextBig(2, 12, val, true);
    int x0 = 4, x1 = 124, y0 = 40, y1 = 54;
    oledRect(x0, y0, x1, y1, true, false);
    float n = paramNorm(p, value);
    if (n < 0.f) n = 0.f;
    if (n > 1.f) n = 1.f;
    int fillW = (int)((x1 - x0 - 2) * n + 0.5f);
    if (fillW > 0) oledRect(x0 + 1, y0 + 1, x0 + 1 + fillW, y1 - 1, true, true);
}

void wXY(const Param& px, const Param& py, float vx, float vy) {
    int x0 = 4, y0 = 8, side = 56;
    oledRect(x0, y0, x0 + side, y0 + side, true, false);
    float nx = paramNorm(px, vx); if (nx < 0.f) nx = 0.f; if (nx > 1.f) nx = 1.f;
    float ny = paramNorm(py, vy); if (ny < 0.f) ny = 0.f; if (ny > 1.f) ny = 1.f;
    int dx = x0 + 1 + (int)((side - 2) * nx);
    int dy = y0 + 1 + (int)((side - 2) * (1.f - ny));   // Y up = higher value
    oledRect(dx - 1, dy - 1, dx + 1, dy + 1, true, true);

    int tx = x0 + side + 8;
    char val[12];
    oledText(tx, 8, px.name, true);
    fmtParamValue(val, sizeof val, px, vx);
    oledText(tx, 18, val, true);
    oledText(tx, 34, py.name, true);
    fmtParamValue(val, sizeof val, py, vy);
    oledText(tx, 44, val, true);
}

// VERBATIM port of PMOR_V2 L5446-5465 — spinner while busy, 5-point star once saved/synced.
void wSavingStar(bool busy, bool show) {
    if (!show) return;
    if (busy) {
        static int sp = 0; sp = (sp + 1) & 7;
        int cx = 124, cy = 4;
        int dx = (sp < 2) ? 2 : (sp < 4) ? 0 : (sp < 6) ? -2 : 0;
        int dy = (sp < 2) ? 0 : (sp < 4) ? 2 : (sp < 6) ? 0 : -2;
        oledPixel(cx + dx, cy + dy, true);
        oledPixel(cx, cy, true);
    } else {
        int cx = 123, cy = 4;
        oledPixel(cx,     cy - 3, true);
        oledPixel(cx,     cy - 2, true);
        oledLine(cx - 3, cy + 3, cx + 3, cy - 1, true);
        oledLine(cx + 3, cy + 3, cx - 3, cy - 1, true);
        oledLine(cx - 3, cy - 1, cx + 3, cy - 1, true);
    }
}

// ---------------------------------------------------------------------------
// SCREENSAVER — the v2 harmonograph figure (two counter-rotating Lissajous loops,
// shaped by the accelerometer) rendered as PARTICLES travelling along the outline
// instead of a drawn line. Size is amplitude-NORMALISED (a slow envelope of the
// output level divides the instantaneous level) so quiet and loud both fill the
// panel; the loud/quiet difference shows as spin speed and particle spread.
// Pixel budget: <= 96 lit pixels, far under the OLED-boost load that killed USB.
// Never drawn in play mode — only when nav.saver is set.
#include <math.h>
void wParticles(float amp, uint32_t now_ms, bool saver) {
    (void)now_ms;
    if (!saver) return;                                   // play mode: nothing (per EMGOR)
    static float env = 0.05f, ph = 0.f, sx = 0.f, sy = 0.f, sz = 0.f, spin = 0.f;
    static float u[96];
    static bool  init = false;
    static uint8_t parity = 0;
    if (!init) { for (int i = 0; i < 96; i++) u[i] = (float)i / 96.f; init = true; }

    if (amp > env) env += (amp - env) * 0.08f; else env += (amp - env) * 0.004f;
    if (env < 0.02f) env = 0.02f;
    float norm = amp / env; if (norm > 1.5f) norm = 1.5f;   // ~1 when steady, spikes on hits
    sx += (g.accel_x - sx) * 0.05f;
    sy += (g.accel_y - sy) * 0.05f;
    sz += (g.accel_z - sz) * 0.05f;
    spin += ((0.6f + norm) * 0.6f - spin) * 0.1f;

    parity ^= 1u;
    if (parity) {                                          // advance every other frame
        ph += 0.010f + spin * 0.012f;
        if (ph > 6.2831853f) ph -= 6.2831853f;
        for (int i = 0; i < 96; i++) {
            u[i] += 0.0025f + 0.004f * norm + 0.0008f * (float)(i & 7);
            if (u[i] >= 1.f) u[i] -= 1.f;
        }
    }
    float fa = 2.0f + sx * 1.6f, fb = 3.0f + sy * 1.6f, fc = 4.0f + sz * 1.6f, fd = 5.0f - sx * 1.4f;
    float R  = 14.f + 14.f * (norm > 1.f ? 1.f : norm);     // fills the panel; cap 28 (pixel budget)
    for (int i = 0; i < 96; i++) {
        int  pass = i & 1;
        float dir = pass ? -1.f : 1.f;
        float rr  = pass ? R * 0.62f : R;
        float t   = u[i] * 6.2831853f;
        float fx = 64.f + rr * ( sinf(fa * t + ph * dir) + 0.5f * sinf(fc * t - ph * 0.7f) );
        float fy = 32.f + rr * 0.55f * ( sinf(fb * t + ph * 1.1f * dir) + 0.5f * sinf(fd * t) );
        int xi = (int)fx, yi = (int)fy;
        if (xi < 0) xi = 0; else if (xi > 127) xi = 127;
        if (yi < 0) yi = 0; else if (yi > 63)  yi = 63;
        oledPixel(xi, yi, true);
    }
}

// ---------------------------------------------------------------------------
// Tunnel of nested rectangles — the v2 intro / menu-dive figure (V2 L4255-4289, L5111-5128)
static void tunnel(float prog, bool outward) {
    for (int k = 0; k < 5; k++) {
        float s = prog * 0.99f + (float)k * 0.2f;
        s -= (int)s;
        if (outward) s = 1.f - s;
        s *= s;
        int w = 3 + (int)(s * 61.f);
        int h = 2 + (int)(s * 30.f);
        oledRect(64 - w, 32 - h, 63 + w, 31 + h, true, false);
    }
}

// Boot intro: the tunnel with "PMOR" punching in. Pumps USB every frame (see V2 notes:
// a hard spin here drops the device off the bus).
void oledIntro() {
    for (int f = 0; f < 20; f++) {
        oledClear();
        tunnel((float)f / 19.f * 2.f, false);
        if (f >= 4) oledTextBig(50, 27, "PMOR", true);
        oledFlush();
        usbDelay(30);
    }
}

// ---------------------------------------------------------------------------
// L_RING sub-pages

static void ringEngine() {
    wTitle(MENU_NAMES[nav.menu]);
    wCards(CARD_NAMES, C_COUNT, nav.card);
}

static void ringFx() {
    // ONE continuous space. The map is a compass: centre = home, the four family
    // directions at the ends. The dot is the joystick. Only the effects currently
    // HELD are named (small, bottom row) — never the whole catalogue.
    const int cx = 64, cy = 30;
    // rhombus outline of the space
    oledLine(cx, cy - 22, cx + 44, cy, true); oledLine(cx + 44, cy, cx, cy + 22, true);
    oledLine(cx, cy + 22, cx - 44, cy, true); oledLine(cx - 44, cy, cx, cy - 22, true);
    // inner home diamond
    oledLine(cx, cy - 7, cx + 14, cy, true); oledLine(cx + 14, cy, cx, cy + 7, true);
    oledLine(cx, cy + 7, cx - 14, cy, true); oledLine(cx - 14, cy, cx, cy - 7, true);
    // family words at the four ends
    oledText(cx - 21, 0,      "STUTTER", true);
    oledText(cx + 46, cy - 4, "MOD",     true);
    oledText(cx - 12, 56,     "DIST",    true);
    oledText(cx - 66 + 4, cy - 4, "REV", true);
    // the joystick dot (+Y = UP on the panel = smaller y)
    int dx = (int)(fx.push_x * 44.f), dy = -(int)(fx.push_y * 22.f);
    oledRect(cx + dx - 2, cy + dy - 2, cx + dx + 2, cy + dy + 2, true, true);
    // held effects only
    int x = 0, y = 48;
    for (uint8_t id = 0; id < FX_TOTAL && x < 110; id++) {
        if ((fx.held >> id) & 1ULL) {
            oledRect(x, y - 1, x + 33, y + 8, true, true);
            oledText(x + 2, y, FX_INFO[id].name, false);
            x += 36;
        }
    }
    // FSR bar along the very bottom
    int fw = (int)(g.fsr * 126.f);
    if (fw > 0) oledRect(1, 62, 1 + fw, 63, true, true);
    if (fx.auto_rec) { oledRect(0, 0, 22, 8, true, true); oledText(2, 0, "REC", false); }
}

static void ringPatches() {
    wTitle("PATCHES");
    uint8_t base = (uint8_t)(nav.patch_page * 16);
    for (int i = 0; i < 16; i++) {
        int x0 = 2 + (i % 4) * 14, y0 = 12 + (i / 4) * 10;
        bool ex = patchExists((uint8_t)(base + i));
        oledRect(x0, y0, x0 + 11, y0 + 8, true, ex);
        if (i == nav.cursor)
            oledRect(x0 - 1, y0 - 1, x0 + 12, y0 + 9, true, false);
    }
    char pl[2] = { (char)('A' + nav.patch_page), 0 };
    oledText(118, 12, pl, true);
}

static void dashPage() {
    char row[24];
    int y = 10, ln = 8;
    snprintf(row, sizeof row, "A%+5d%+5d%+5d", (int)(g.accel_x * 1000.f), (int)(g.accel_y * 1000.f), (int)(g.accel_z * 1000.f));
    oledText(0, y, row, true); y += ln;
    snprintf(row, sizeof row, "J%+5d%+5d %s", g.joy_raw_x, g.joy_raw_y, g.joy_calibrated ? "CAL" : "---");
    oledText(0, y, row, true); y += ln;
    snprintf(row, sizeof row, "D:%4dmm S:%02X", (int)lidarMm(), lidarStatus());
    oledText(0, y, row, true); y += ln;
    snprintf(row, sizeof row, "F:%3d%%", (int)(g.fsr * 100.f));
    oledText(0, y, row, true); y += ln;
    snprintf(row, sizeof row, "CPU:%3d%% BPM:%3d", (int)(g.cpu_load * 100.f), (int)(g.bpm + 0.5f));
    oledText(0, y, row, true); y += ln;
    snprintf(row, sizeof row, "SD:%-2s USB:%-2s", sdOk() ? "OK" : "--", tud_cdc_connected() ? "OK" : "--");
    oledText(0, y, row, true); y += ln;
    {   // SD save health: saves ok/failed, boot load result, last failing step + FRESULT
        const PatchDiag& d = patchDiag();
        snprintf(row, sizeof row, "SV:%u/%u LD:%u %c%u %s", (unsigned)d.saves_ok, (unsigned)d.saves_fail,
                 (unsigned)d.boot_load, file_diag.op ? file_diag.op : '-', (unsigned)file_diag.fr,
                 sdIsFast() ? "F" : "S");
        oledText(0, y, row, true);
    }
}

static void ringGlobalsDash() {
    wTitle(MENU_NAMES[nav.menu]);
    if (nav.menu == M_DASH) dashPage();
    else wList(navCurrentPage(), nav.cursor, nav.cursor >= 6 ? nav.cursor - 5 : 0);
}

static void renderRing(uint32_t now_ms) {
    (void)now_ms;
    switch (nav.menu) {
        case M_DRUMS: case M_SYNTH: case M_SMP: ringEngine(); break;
        case M_FX:      ringFx();      break;
        case M_PATCHES: ringPatches(); break;
        case M_GLOBALS: case M_DASH: default: ringGlobalsDash(); break;
    }
}

// ---------------------------------------------------------------------------
// L_PADCOUNT / L_VOLUME

static void renderPadCount() {
    Engine e = (nav.menu == M_SYNTH) ? ENG_SYNTH : (nav.menu == M_SMP) ? ENG_SMP : ENG_DRUMS;
    char row[16];
    snprintf(row, sizeof row, "BARS: %d", seq.lane[e].bars);
    oledTextBig(6, 16, row, true);
    snprintf(row, sizeof row, "STEPS: %d", seq.lane[e].steps_per_bar);
    oledTextBig(6, 36, row, true);
}

static void renderHandSeq() {
    Engine e = (nav.menu == M_SYNTH) ? ENG_SYNTH : (nav.menu == M_SMP) ? ENG_SMP : ENG_DRUMS;
    const LaneSet& l = seq.lane[e];
    uint8_t spb = l.steps_per_bar ? l.steps_per_bar : 16;
    char row[24];
    snprintf(row, sizeof row, "HANDSEQ PAD %2d", nav.hand_target + 1);
    wTitle(row);
    snprintf(row, sizeof row, "BAR %d/%d", nav.hand_bar + 1, l.bars);
    oledText(0, 12, row, true);
    // 16 step boxes, lit where this lane has a hit; playhead underlined
    uint32_t cur = g.gstep;
    for (int st = 0; st < 16; st++) {
        int x0 = 2 + st * 8, y0 = 30, y1 = 46;
        bool inbar = st < spb;
        uint32_t idx = (uint32_t)nav.hand_bar * spb + st;
        bool on = inbar && idx < MAXSTEPS && ((l.step[idx] >> nav.hand_target) & 1u);
        if (inbar) oledRect(x0, y0, x0 + 6, y1, true, on);
        if (inbar && idx == cur) oledLine(x0, y1 + 3, x0 + 6, y1 + 3, true);
    }
    oledText(0, 54, "L/R PAD  U/D BAR", true);
}

static void renderVolume() {
    wTitle("VOLUME");
    float frac = outp.fader / 1.3333f;
    if (frac < 0.f) frac = 0.f;
    if (frac > 1.f) frac = 1.f;
    int x0 = 4, x1 = 124, y0 = 26, y1 = 46;
    oledRect(x0, y0, x1, y1, true, false);
    int fillW = (int)((x1 - x0 - 2) * frac + 0.5f);
    if (fillW > 0) oledRect(x0 + 1, y0 + 1, x0 + 1 + fillW, y1 - 1, true, true);
    char pct[8]; snprintf(pct, sizeof pct, "%3d%%", (int)(frac * 100.f + 0.5f));
    oledTextBig(48, 50, pct, true);
}

// ---------------------------------------------------------------------------

void oledRenderFrame(uint32_t now_ms) {
    oledClear();

    if (nav.saver) {
        wParticles(g.out_amp, now_ms, true);
        return;
    }
    // menu-dive transition (~180 ms, 6 frames at 30 fps): tunnel + the new menu's name
    if (nav.dive_ms && (now_ms - nav.dive_ms) < (uint32_t)DIVE_MS) {
        float prog = (float)(now_ms - nav.dive_ms) / (float)DIVE_MS;
        tunnel(prog, false);
        const char* nm = MENU_NAMES[nav.menu];
        int len = 0; while (nm[len]) len++;
        oledText(64 - len * 3, 29, nm, true);
        return;
    }

    switch (nav.level) {
        case L_RING:
            renderRing(now_ms);
            break;
        case L_CARD: {
            const ParamPage* page = navCurrentPage();
            wTitle(page ? page->title : CARD_NAMES[nav.card]);
            int top = (nav.cursor >= 6) ? (nav.cursor - 5) : 0;
            wList(page, nav.cursor, top);
            break;
        }
        case L_EDIT1:
            if (nav.edit) wSlider(*nav.edit, *nav.edit->value);
            break;
        case L_EDIT2:
            if (nav.edit) {
                const Param& px = *nav.edit;
                const ParamPage* page = navCurrentPage();
                // Y is the next Param in the owning page (PF_PAIR_X convention).
                const Param* py = &px;
                if (page) {
                    for (uint8_t i = 0; i + 1 < page->count; i++) {
                        if (&page->items[i] == &px) { py = &page->items[i + 1]; break; }
                    }
                }
                wXY(px, *py, *px.value, *py->value);
            }
            break;
        case L_PADCOUNT:
            renderPadCount();
            break;
        case L_HANDSEQ:
            renderHandSeq();
            break;
        case L_VOLUME:
            renderVolume();
            break;
    }

    wSavingStar(patchSaving(), !nav.saver && nav.level != L_VOLUME);
}
