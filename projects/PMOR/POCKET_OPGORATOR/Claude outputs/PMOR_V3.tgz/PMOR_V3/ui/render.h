// render.h — OLED and trellis rendering (CONTROL plane). Draws from nav + engine state.
#pragma once
#include <stdint.h>
#include "nav.h"

// ---- OLED (128×64 landscape)
void oledRenderFrame(uint32_t now_ms);
void oledIntro();                          // boot tunnel with PMOR (called once from main after hwBoot)     // dispatch by nav.level / nav.menu; ends with saving-star + particles
// widgets (used by pages)
void wCards(const char* const* names, int n, int sel);                       // three rounded cards L→R
void wList(const ParamPage* page, int cursor, int top);                     // scrolling param list
void wSlider(const Param& p, float value);                                  // full-screen 1-D editor
void wXY(const Param& px, const Param& py, float vx, float vy);             // full-screen 2-D editor
void wTitle(const char* s);                                                 // top row title
void wSavingStar(bool busy, bool show);                                     // VERBATIM from V2 L5446-5465
void wParticles(float amp, uint32_t now_ms, bool saver);                    // outline particles / screensaver

// ---- Trellis
struct Rgb { uint8_t r, g, b; };
void trellisRenderFrame(uint32_t now_ms, uint8_t grb_out[48]);   // lava base + page overlay + brightness + rotation
extern float g_trellis_brightness;                                // 0..1 from GLOBALS (default lower than v2)
