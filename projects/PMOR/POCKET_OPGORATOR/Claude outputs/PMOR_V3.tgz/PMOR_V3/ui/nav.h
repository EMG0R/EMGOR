// nav.h — the whole interface state machine. One rule set everywhere:
//   encoder turn = move through the current ring (hard stops)
//   encoder press = TAP TEMPO, always
//   joystick click = push into / set / back out / un-focus, by context
//   both = volume shortcut (undoes the first single press)
//   joystick move = nav (flick+repeat) or param edit or performance, by context
#pragma once
#include <stdint.h>
#include "input.h"
#include "../engine/param.h"
#include "../engine/sequencer.h"

enum Menu : uint8_t { M_DRUMS = 0, M_SYNTH, M_SMP, M_FX, M_PATCHES, M_GLOBALS, M_DASH, M_COUNT };
extern const char* const MENU_NAMES[M_COUNT];

enum Card : uint8_t { C_TIMBRE = 0, C_SEQ, C_PERF, C_COUNT };
extern const char* const CARD_NAMES[C_COUNT];

enum NavLevel : uint8_t {
    L_RING = 0,     // top: menu name + three cards (engines) or the page itself
    L_CARD,         // inside a card: list of params / sub-items
    L_EDIT1,        // full-screen 1-D slider
    L_EDIT2,        // full-screen XY pad
    L_PADCOUNT,     // bars / steps chooser on the pads
    L_HANDSEQ,      // PO-style step editor: pads = 16 steps of hand_bar for lane hand_target
    L_VOLUME,       // both-button overlay
};

struct NavState {
    Menu     menu;
    Card     card;            // engines only
    NavLevel level;
    uint8_t  cursor;          // item index inside the card list
    // editors
    const Param* edit;        // current 1-D param (or X of a pair)
    // focus (drums/sampler timbre): pad focused for swiping sounds / pitch-formant
    int8_t   focus_pad;       // -1 none
    // performance
    bool     perf_active;     // engine performance card is open
    // screensaver
    uint32_t last_nav_ms;
    bool     saver;
    // volume overlay
    bool     vol_overlay;
    // patches
    uint8_t  patch_page;      // 0..3
    // undo of the first press when a chord arrives
    InputEvent last_single;   // what the last single press did (for IN_BOTH_PRESS reversal)
    // additive (ui/input.cpp + ui/nav.cpp), report per AGENT_RULES:
    uint32_t hold_ms;         // current pad-hold duration, for delete-countdown rendering (PATCHES/SAMPLER)
    int8_t   hold_pad;        // which pad is being held for that countdown, -1 = none
    uint8_t  page;            // page index inside the current card (e.g. synth TIMBRE sub-pages)
    uint32_t dive_ms;         // ms timestamp of the last main-menu change (page-switch animation)
    uint8_t  hand_target;     // HANDSEQ: lane/pad being written
    uint8_t  hand_bar;        // HANDSEQ: bar being shown
};
extern NavState nav;

void navInit();
void navHandle(const InputEvent& e, uint32_t now_ms);   // consumes one event
void navTick(uint32_t now_ms);                          // timeouts: screensaver, overlays
// pages ask nav what to draw
const ParamPage* navCurrentPage();
// engines expose their card pages
const ParamPage* navTimbrePages(Engine e, uint8_t& count);   // list of pages in TIMBRE card
