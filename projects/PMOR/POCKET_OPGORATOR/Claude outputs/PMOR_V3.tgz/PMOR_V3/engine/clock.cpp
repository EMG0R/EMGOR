// clock.cpp — sample-accurate master 16th clock. See engine/clock.h for the
// AUDIO/CONTROL plane split. Everything that decides *when* a step lands is
// float samples; only clockTap()'s bookkeeping (and its snap conversion) uses
// wall-clock ms, per the ms_at_block/sample_at_block correspondence.
#include <string.h>
#include <math.h>
#include "daisy_seed.h"
#include "clock.h"
#include "shared_state.h"
#include "engine_util.h"

ClockState clk;

// STOP (varispeed_target ~= 0.06, the tape-stop floor) gets a slower ~250 ms
// fall so it reads as a real tape grinding to a halt; every other varispeed
// move (HALF/DBL/normal) slews at ~40 ms.
static const float VARISPEED_STOP_TARGET = 0.06f;
static const float VARISPEED_NORMAL_MS   = 40.f;
static const float VARISPEED_STOP_MS     = 250.f;

void clockInit(float bpm) {
    memset(&clk, 0, sizeof(clk));
    clk.bpm = bpm > 1.f ? bpm : 120.f;           // the BPM handover in main() must never see 0
    clk.step_samples = SR * 15.f / clk.bpm;
    clk.next_step = clk.step_samples;
    clk.loop_len = MAX_STEPS_BAR;
    clk.varispeed = clk.varispeed_target = 1.f;
    g.bpm = clk.bpm;
}

int clockTick(uint32_t sample_now) {
    clk.sample_now      = sample_now;
    clk.sample_at_block = sample_now;
    clk.ms_at_block      = daisy::System::GetNow();

    // ---- varispeed slew: one-pole toward varispeed_target. STOP falls slower.
    bool  stopping = clk.varispeed_target <= (VARISPEED_STOP_TARGET + 0.005f) &&
                      clk.varispeed > clk.varispeed_target;
    float ms  = stopping ? VARISPEED_STOP_MS : VARISPEED_NORMAL_MS;
    float n   = ms * 0.001f * BLOCK_HZ;
    float a   = (n > 0.5f) ? (1.f - expf(-1.f / n)) : 1.f;
    clk.varispeed += (clk.varispeed_target - clk.varispeed) * a;
    clk.varispeed  = flushDenorm(clk.varispeed);

    // (shadow_phase kept for reference only; step_phase is derived from the MASTER
    //  grid below, so gates/stutters are always exactly where the sequencer is.
    //  HALF/DBL/STOP are handled by re-mapping which step fires, not by bending phase.)

    // ---- tap snap: realign next_step to the tap instant, converting the
    // tap's ms timestamp to an absolute sample time via the correspondence
    // just captured above.
    if (clk.snap_pending) {
        int32_t dms = (int32_t)(clk.snap_ms - clk.ms_at_block);
        float   dsamples = (float)dms * (SR * 0.001f);
        clk.next_step = (float)clk.sample_at_block + dsamples;
        clk.snap_pending = false;
    }

    // ---- master step: catch-up guard — fire at most one boundary per block;
    // if we are behind by more than one step, resync to now instead of
    // firing a burst.
    int   fired = 0;
    float now_f = (float)sample_now;
    if (now_f >= clk.next_step) {
        float sw  = clk.swing * 0.34f;                 // up to ~1/3 swing, spec V2 L2020-2025
        float lng = clk.step_samples * (1.f + sw);
        float sht = clk.step_samples * 2.f - lng;       // average preserved: (lng+sht)/2 = step_samples
        bool  next_is_odd = ((clk.gstep + 1) & 1u) != 0;
        float step_len = next_is_odd ? lng : sht;        // odd steps lengthened
        clk.next_step += step_len;

        clk.gstep++;
        if (clk.gstep >= clk.loop_len) clk.gstep = 0;
        fired = 1;

        // still more than one step behind after firing this one? resync
        // rather than let the ISR spiral trying to catch up.
        if (now_f - clk.next_step > clk.step_samples) {
            clk.next_step = now_f + clk.step_samples;
        }
    }
    // master step phase 0..1 at the START of this block (effects add i/step_samples per sample)
    if (clk.step_samples > 0.f) {
        float ph = 1.f - (clk.next_step - now_f) / clk.step_samples;
        if (ph < 0.f) ph = 0.f; if (ph > 0.9999f) ph = 0.9999f;
        clk.step_phase = ph;
        clk.shadow_phase = ph;
    }
    return fired;
}

void clockSetBpm(float bpm) {
    if (bpm < 1.f) return;
    float old_ss = clk.step_samples;
    float new_ss = SR * 15.f / bpm;
    // keep phase: rescale the remaining time to next_step by the tempo ratio
    // instead of resetting it, so a live BPM nudge never clicks/jumps a step.
    if (old_ss > 0.f) {
        float remaining = clk.next_step - (float)clk.sample_now;
        remaining *= (new_ss / old_ss);
        clk.next_step = (float)clk.sample_now + remaining;
    }
    clk.bpm = bpm;
    clk.step_samples = new_ss;
    g.bpm = bpm;
}

void clockSetLoopLen(uint32_t sixteenths) {
    clk.loop_len = sixteenths ? sixteenths : 1;
    if (clk.gstep >= clk.loop_len) clk.gstep = 0;
}

// ---------------------------------------------------------------- tap tempo
// Live from tap 2: bpm = 60000/interval immediately on the 2nd tap, then a
// rolling average of the latest up to TAP_MAX_N intervals (naturally the same
// formula — averaging one interval on the 2nd tap IS the immediate value).
// A gap > TAP_EXPIRE_MS since the previous tap resets the window.
static void clockRecomputeFromTaps() {
    if (clk.tap_n < 2) return;
    uint32_t sum = 0;
    int      cnt = (int)clk.tap_n - 1;
    for (int i = 1; i < (int)clk.tap_n; i++) sum += clk.tap_ms[i] - clk.tap_ms[i - 1];
    uint32_t interval = sum / (uint32_t)cnt;
    if (interval == 0) return;
    float bpm = 60000.f / (float)interval;
    bpm = clampf(bpm, 30.f, 300.f);                 // unquantized, clamped
    clockSetBpm(bpm);
}

void clockTap(uint32_t now_ms) {
    if (clk.tap_n > 0) {
        uint32_t last = clk.tap_ms[clk.tap_n - 1];
        uint32_t gap  = now_ms - last;
        if (gap > TAP_EXPIRE_MS) clk.tap_n = 0;      // stale window, start over
    }
    if (clk.tap_n < TAP_MAX_N) {
        clk.tap_ms[clk.tap_n++] = now_ms;
    } else {
        for (uint8_t i = 1; i < TAP_MAX_N; i++) clk.tap_ms[i - 1] = clk.tap_ms[i];
        clk.tap_ms[TAP_MAX_N - 1] = now_ms;
    }
    if (clk.tap_n >= 2) {
        clockRecomputeFromTaps();
        // ISR realigns next_step to this tap instant on the next block.
        clk.snap_pending = true;
        clk.snap_ms      = now_ms;
    }
}

void clockUntap() {
    if (clk.tap_n == 0) return;
    clk.tap_n--;
    clockRecomputeFromTaps();          // no-op (leaves bpm/snap alone) if < 2 taps remain
}

uint32_t clockSampleNow() { return clk.sample_now; }
