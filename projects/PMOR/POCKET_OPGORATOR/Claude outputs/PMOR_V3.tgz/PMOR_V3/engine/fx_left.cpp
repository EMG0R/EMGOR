// fx_left.cpp — FXD_LEFT family: reverse / time (12 pads).
// Ported from PMOR_V2.cpp per research/v2-audit.md §3 (line refs in each class).
// Most effects read the shared 2 s dry capture ring (FxCtx::ringL/ringR) instead
// of keeping a private copy; the four that need real feedback (own wet content
// folded back into a delay line) get their own SDRAM buffer.
#include <string.h>
#include "fx_internal.h"
#include "engine_util.h"

static const float kTwoPi = 6.283185307f;

// 0 REV2 — reverse the last 2 beats from the ring, edges faded. V2 L2526-2539.
class FxLeftRev2 : public Effect {
    uint32_t anchor_ = 0;
    float    pos_ = 0.f;
    void onEngage(const FxCtx& c) override { anchor_ = c.step_ring_w; pos_ = 0.f; }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        uint32_t len = (uint32_t)(c.step_samples * 8.f);               // 2 beats = 8 sixteenths
        if (len > c.ring_n - 64u) len = c.ring_n - 64u;
        if (len < 64u) len = 64u;
        for (size_t i = 0; i < n; i++) {
            pos_ += 1.f; while (pos_ >= (float)len) pos_ -= (float)len;
            uint32_t ri = (uint32_t)pos_;
            uint32_t rp = (anchor_ + c.ring_n - 1u - ri) % c.ring_n;
            float g = 1.f;
            if (ri < 480u)               g = (float)ri / 480.f;
            else if (len - ri < 480u)    g = (float)(len - ri) / 480.f;
            L[i] = fxLerp(L[i], c.ringL[rp] * g, amt);
            R[i] = fxLerp(R[i], c.ringR[rp] * g, amt);
        }
    }
};

// 1 REVBR — reverse the last bar (up to MAX_BARS-agnostic: one 16-step bar). V2 L2526-2539 pattern.
class FxLeftRevBar : public Effect {
    uint32_t anchor_ = 0;
    float    pos_ = 0.f;
    void onEngage(const FxCtx& c) override { anchor_ = c.step_ring_w; pos_ = 0.f; }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        uint32_t len = (uint32_t)(c.step_samples * (float)MAX_STEPS_BAR);
        if (len > c.ring_n - 64u) len = c.ring_n - 64u;
        if (len < 64u) len = 64u;
        for (size_t i = 0; i < n; i++) {
            pos_ += 1.f; while (pos_ >= (float)len) pos_ -= (float)len;
            uint32_t ri = (uint32_t)pos_;
            uint32_t rp = (anchor_ + c.ring_n - 1u - ri) % c.ring_n;
            float g = 1.f;
            if (ri < 480u)               g = (float)ri / 480.f;
            else if (len - ri < 480u)    g = (float)(len - ri) / 480.f;
            L[i] = fxLerp(L[i], c.ringL[rp] * g, amt);
            R[i] = fxLerp(R[i], c.ringR[rp] * g, amt);
        }
    }
};

// 2 REVSCR — reverse read, speed FSR 0.25->2x, lidar scrubs the read point.
class FxLeftRevScrub : public Effect {
    uint32_t anchor_ = 0;
    float    pos_ = 0.f;
    OnePole  scrub_;
    void onEngage(const FxCtx& c) override {
        anchor_ = c.ring_w; pos_ = 0.f;
        scrub_.setMs(30.f, BLOCK_HZ); scrub_.set(0.f);
    }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        float speed = 0.25f + c.fsr * 1.75f;
        float scrub = scrub_.process((c.lidar - 0.5f) * 4000.f);
        uint32_t len = c.ring_n;
        for (size_t i = 0; i < n; i++) {
            pos_ += speed; while (pos_ >= (float)len) pos_ -= (float)len;
            float rr = pos_ + scrub; while (rr < 0.f) rr += (float)len; while (rr >= (float)len) rr -= (float)len;
            uint32_t ri = (uint32_t)rr;
            uint32_t rp = (anchor_ + c.ring_n - 1u - ri) % c.ring_n;
            L[i] = fxLerp(L[i], c.ringL[rp], amt);
            R[i] = fxLerp(R[i], c.ringR[rp], amt);
        }
    }
};

// 3 VSTOP — tape-stop: read head falls behind the write point. V2 L2986-2993.
class FxLeftVstop : public Effect {
    float back_ = 0.f;
    void onEngage(const FxCtx&) override { back_ = 0.f; }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        float spd = 0.4f + c.fsr * 2.5f;
        float damp = 1.f - c.fsr * 0.5f;
        for (size_t i = 0; i < n; i++) {
            back_ += spd; if (back_ > (float)c.ring_n - 2.f) back_ = (float)c.ring_n - 2.f;
            uint32_t rp = (c.ring_w + c.ring_n - (uint32_t)back_) % c.ring_n;
            L[i] = fxLerp(L[i], c.ringL[rp] * damp, amt);
            R[i] = fxLerp(R[i], c.ringR[rp] * damp, amt);
        }
    }
};

// 4 BND+ — read speed glides up while held. V2 L3168-3172.
class FxLeftBendUp : public Effect {
    float spd_ = 1.f, rp_ = 0.f;
    void onEngage(const FxCtx&) override { spd_ = 1.f; rp_ = 0.f; }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        float target = 1.f + c.fsr * 3.f;
        const float win = 4000.f;
        for (size_t i = 0; i < n; i++) {
            spd_ += (target - spd_) * 0.0006f;
            rp_ += spd_; if (rp_ >= win) rp_ -= win;
            uint32_t rp = (c.ring_w + c.ring_n - (uint32_t)rp_) % c.ring_n;
            L[i] = fxLerp(L[i], c.ringL[rp], amt);
            R[i] = fxLerp(R[i], c.ringR[rp], amt);
        }
    }
};

// 5 BND- — read speed glides down (dive). V2 L3173-3177.
class FxLeftBendDown : public Effect {
    float spd_ = 1.f, rp_ = 0.f;
    void onEngage(const FxCtx&) override { spd_ = 1.f; rp_ = 0.f; }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        float target = 1.f - 0.6f * c.fsr; if (target < 0.05f) target = 0.05f;
        const float win = 4000.f;
        for (size_t i = 0; i < n; i++) {
            spd_ += (target - spd_) * 0.0006f;
            rp_ += spd_; if (rp_ < 0.f) rp_ += win; if (rp_ >= win) rp_ -= win;
            uint32_t rp = (c.ring_w + c.ring_n - (uint32_t)rp_) % c.ring_n;
            L[i] = fxLerp(L[i], c.ringL[rp], amt);
            R[i] = fxLerp(R[i], c.ringR[rp], amt);
        }
    }
};

// 6 SCRTC — stereo vinyl jog. V2 L3077-3082 (mono there; stereo here).
class FxLeftScratch : public Effect {
    float ph_ = 0.f, rp_ = 0.f;
    void onEngage(const FxCtx&) override { ph_ = 0.f; rp_ = 0.f; }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        float rate = 2.f + c.fsr * 4.f;
        for (size_t i = 0; i < n; i++) {
            ph_ += rate / 480.f; if (ph_ >= 1.f) ph_ -= 1.f;
            rp_ += sinf(ph_ * kTwoPi) * 60.f * (0.5f + c.fsr);
            float rr = (float)c.ring_w - rp_;
            while (rr < 0.f) rr += (float)c.ring_n;
            while (rr >= (float)c.ring_n) rr -= (float)c.ring_n;
            uint32_t ri = (uint32_t)rr;
            L[i] = fxLerp(L[i], c.ringL[ri], amt);
            R[i] = fxLerp(R[i], c.ringR[ri], amt);
        }
    }
};

// 7 WARBL — 7->19Hz flutter, accel X = speed, FSR = depth. V2 L3178-3183.
class FxLeftWarble : public Effect {
    float ph_ = 0.f;
    void onEngage(const FxCtx&) override { ph_ = 0.f; }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        float rateHz = fxLfoHz(c.accel_x, 7.f, 19.f);
        float depth = 700.f * c.fsr;
        for (size_t i = 0; i < n; i++) {
            ph_ += rateHz / SR; if (ph_ >= 1.f) ph_ -= 1.f;
            float back = 800.f + depth * sinf(ph_ * kTwoPi);
            float wL = fxRingRead(c.ringL, c.ring_n, c.ring_w, back);
            float wR = fxRingRead(c.ringR, c.ring_n, c.ring_w, back);
            L[i] = fxLerp(L[i], wL, amt);
            R[i] = fxLerp(R[i], wR, amt);
        }
    }
};

// -------- effects that need their own feedback buffer (SDRAM) --------

static const uint32_t kDelayBufN = 48000;                              // 1 s
static float SDRAM_BSS s_delayL[kDelayBufN];
static float SDRAM_BSS s_delayR[kDelayBufN];
static float SDRAM_BSS s_pngL[kDelayBufN];
static float SDRAM_BSS s_pngR[kDelayBufN];
static const uint32_t kFadeBufN = 24000;                               // 0.5 s
static float SDRAM_BSS s_fadeBuf[kFadeBufN];
static const uint32_t kLoopBufN = 96000;                               // 2 s
static float SDRAM_BSS s_loopL[kLoopBufN];
static float SDRAM_BSS s_loopR[kLoopBufN];

// 8 DELAY — tempo 1/8 stereo delay. V2 L3112-3116. FSR fb 0.2->0.75.
class FxLeftDelay : public Effect {
    uint32_t wp_ = 0;
    void init() override { memset(s_delayL, 0, sizeof(s_delayL)); memset(s_delayR, 0, sizeof(s_delayR)); wp_ = 0; }
    void onEngage(const FxCtx&) override { /* keep tail across re-engage, like V2 */ }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        uint32_t dt = (uint32_t)(c.step_samples * 2.f);
        if (dt < 1u) dt = 1u;
        if (dt > kDelayBufN - 1u) dt = kDelayBufN - 1u;
        float fb = 0.2f + 0.55f * c.fsr;
        for (size_t i = 0; i < n; i++) {
            uint32_t rp = (wp_ + kDelayBufN - dt) % kDelayBufN;
            float dl = s_delayL[rp], dr = s_delayR[rp];
            s_delayL[wp_] = fxTanh(L[i] + dl * fb);
            s_delayR[wp_] = fxTanh(R[i] + dr * fb);
            float wL = L[i] + dl * 0.6f, wR = R[i] + dr * 0.6f;
            L[i] = fxLerp(L[i], wL, amt);
            R[i] = fxLerp(R[i], wR, amt);
            wp_ = (wp_ + 1u) % kDelayBufN;
        }
    }
};

// 9 PNGPG — cross-fed ping-pong at 1/8. V2 L3117-3121.
class FxLeftPingPong : public Effect {
    uint32_t wp_ = 0;
    void init() override { memset(s_pngL, 0, sizeof(s_pngL)); memset(s_pngR, 0, sizeof(s_pngR)); wp_ = 0; }
    void onEngage(const FxCtx&) override {}
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        uint32_t dt = (uint32_t)(c.step_samples * 2.f);
        if (dt < 1u) dt = 1u;
        if (dt > kDelayBufN - 1u) dt = kDelayBufN - 1u;
        float fb = 0.3f + 0.55f * c.fsr;
        for (size_t i = 0; i < n; i++) {
            uint32_t rp = (wp_ + kDelayBufN - dt) % kDelayBufN;
            float dl = s_pngL[rp], dr = s_pngR[rp];
            s_pngL[wp_] = fxTanh(L[i] + dr * fb);
            s_pngR[wp_] = fxTanh(R[i] + dl * fb);
            float wL = L[i] + dl * 0.6f, wR = R[i] + dr * 0.6f;
            L[i] = fxLerp(L[i], wL, amt);
            R[i] = fxLerp(R[i], wR, amt);
            wp_ = (wp_ + 1u) % kDelayBufN;
        }
    }
};

// 10 FADE — echo whose feedback rises to 0.85 while held. V2 L3122-3127. FSR time 1->3 steps.
class FxLeftFade : public Effect {
    uint32_t wp_ = 0;
    float    fb_ = 0.f;
    void init() override { memset(s_fadeBuf, 0, sizeof(s_fadeBuf)); wp_ = 0; }
    void onEngage(const FxCtx&) override { fb_ = 0.f; }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        uint32_t dt = (uint32_t)(c.step_samples * (1.f + c.fsr * 2.f));
        if (dt < 1u) dt = 1u;
        if (dt > kFadeBufN - 1u) dt = kFadeBufN - 1u;
        for (size_t i = 0; i < n; i++) {
            fb_ += (0.85f - fb_) * 0.0008f;
            uint32_t rp = (wp_ + kFadeBufN - dt) % kFadeBufN;
            float d = s_fadeBuf[rp];
            s_fadeBuf[wp_] = fxTanh((L[i] + R[i]) * 0.5f + d * fb_);
            float wL = L[i] + d * 0.6f, wR = R[i] + d * 0.6f;
            L[i] = fxLerp(L[i], wL, amt);
            R[i] = fxLerp(R[i], wR, amt);
            wp_ = (wp_ + 1u) % kFadeBufN;
        }
    }
};

// 11 LOOP — capture and loop up to 16 steps; re-captures on every onEngage. V2 L3194-3198.
class FxLeftLoop : public Effect {
    uint32_t pp_ = 0, len_ = kLoopBufN;
    bool     capturing_ = true;
    void init() override { memset(s_loopL, 0, sizeof(s_loopL)); memset(s_loopR, 0, sizeof(s_loopR)); pp_ = 0; }
    void onEngage(const FxCtx& c) override {
        float lenF = c.step_samples * 16.f * (0.25f + 0.75f * c.fsr);
        uint32_t len = (uint32_t)lenF;
        if (len > kLoopBufN) len = kLoopBufN;
        if (len < 2400u) len = 2400u;
        len_ = len; pp_ = 0; capturing_ = true;
    }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        (void)c;
        for (size_t i = 0; i < n; i++) {
            float wL, wR;
            if (capturing_) {
                s_loopL[pp_] = L[i]; s_loopR[pp_] = R[i];
                wL = L[i]; wR = R[i];
                if (++pp_ >= len_) { pp_ = 0; capturing_ = false; }
            } else {
                wL = s_loopL[pp_]; wR = s_loopR[pp_];
                if (++pp_ >= len_) pp_ = 0;
            }
            L[i] = fxLerp(L[i], wL, amt);
            R[i] = fxLerp(R[i], wR, amt);
        }
    }
};

// ============================================================================
// tables
// ============================================================================
static FxLeftRev2      s_rev2;
static FxLeftRevBar    s_revbr;
static FxLeftRevScrub  s_revsc;
static FxLeftVstop     s_vstop;
static FxLeftBendUp    s_bndup;
static FxLeftBendDown  s_bnddn;
static FxLeftScratch   s_scrtc;
static FxLeftWarble    s_warbl;
static FxLeftDelay     s_delay;
static FxLeftPingPong  s_pngpg;
static FxLeftFade      s_fade;
static FxLeftLoop      s_loop;

Effect* const FX_LEFT_TABLE[FX_PER_DIR] = {
    &s_rev2, &s_revbr, &s_revsc, &s_vstop, &s_bndup, &s_bnddn,
    &s_scrtc, &s_warbl, &s_delay, &s_pngpg, &s_fade, &s_loop,
};

const FxInfo FX_LEFT_INFO[FX_PER_DIR] = {
    { "REV2",  FXD_LEFT, true,  false },
    { "REVBR", FXD_LEFT, true,  false },
    { "REVSC", FXD_LEFT, false, false },
    { "VSTOP", FXD_LEFT, false, false },
    { "BND+",  FXD_LEFT, false, false },
    { "BND-",  FXD_LEFT, false, false },
    { "SCRTC", FXD_LEFT, false, false },
    { "WARBL", FXD_LEFT, false, true  },
    { "DELAY", FXD_LEFT, true,  false },
    { "PNGPG", FXD_LEFT, true,  false },
    { "FADE",  FXD_LEFT, true,  false },
    { "LOOP",  FXD_LEFT, true,  false },
};
