// clock.h — master step clock. AUDIO plane owns it; CONTROL only calls clockTap()/clockSetBpm().
// Sample-accurate: everything is in float samples, never integer ms.
#pragma once
#include <stdint.h>
#include "../config.h"

struct ClockState {
    float    bpm;              // unquantized allowed (tap)
    float    step_samples;     // samples per 16th = SR * 15 / bpm
    float    next_step;        // absolute sample time of the next 16th
    uint32_t gstep;            // 0 .. loop_len-1 (longest loop across engines)
    uint32_t loop_len;         // in 16ths; max of all engine loops
    float    step_phase;       // 0..1 inside the current 16th (for gates)
    float    swing;            // 0..1
    // shadow clock for HALF/DBL/STOP (FX) — multiplies the *effective* playback rate
    float    varispeed;        // 1.0 normal; slews
    float    varispeed_target;
    // tap
    uint32_t tap_ms[TAP_MAX_N];
    uint8_t  tap_n;
    bool     snap_pending;     // set by tap; ISR realigns next_step on the next block
    uint32_t snap_ms;
    // additive (clock.cpp): absolute sample counter + the wall-clock/sample
    // correspondence needed to convert clockTap()'s ms timestamps into a
    // sample-accurate `next_step` snap from the ISR.
    uint32_t sample_now;         // last sample_now seen by clockTick(), control-plane readable via clockSampleNow()
    uint32_t ms_at_block;        // daisy::System::GetNow() at the start of the current block
    uint32_t sample_at_block;    // sample_now at that same instant
    float    shadow_phase;       // 0..1, varispeed-scaled accumulator behind step_phase
};

extern ClockState clk;

void  clockInit(float bpm);
// AUDIO plane: advance by one block; returns the number of 16th boundaries crossed (0 or 1; catch-up guard).
int   clockTick(uint32_t sample_now);
// CONTROL plane
void  clockTap(uint32_t now_ms);            // encoder click; rolling 2..5 taps, phase snap, 2 s expiry
void  clockSetBpm(float bpm);               // from the parameter editor (caller quantizes)
void  clockSetLoopLen(uint32_t sixteenths); // sequencer recomputes when bars/steps change
// additive (clock.cpp), report per AGENT_RULES:
void      clockUntap();                     // removes the last tap and recomputes bpm/snap from what remains
uint32_t  clockSampleNow();                 // absolute sample counter, control-plane readable
// helpers
static inline float clockStepMs() { return 15000.f / clk.bpm; }
