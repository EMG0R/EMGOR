// fx.h — the FX space: 64 pads = 16 home + 12 per push direction. Every effect is
// FSR-modulated; LFO-type effects use accel X for speed. Anti-click fades on every
// engage/release. Automation spans the LONGEST engine loop.
#pragma once
#include <stdint.h>
#include "../config.h"

enum FxDir : uint8_t { FXD_HOME = 0, FXD_UP, FXD_RIGHT, FXD_DOWN, FXD_LEFT, FXD_COUNT };
// UP = stutter/glitch/stabs + spatial, RIGHT = modulation, DOWN = distortion/ringmod, LEFT = reverse/time

// Effect ids are dense 0..FX_TOTAL-1: home 0..15, then UP 16..27, RIGHT 28..39, DOWN 40..51, LEFT 52..63
static inline uint8_t fxId(FxDir d, uint8_t pad12) { return d == FXD_HOME ? pad12 : (uint8_t)(16 + (d - 1) * FX_PER_DIR + pad12); }

struct FxInfo {
    const char* name;      // ≤5 chars for the trellis-side OLED list
    FxDir       family;    // colour family
    bool        clocked;   // uses the grid
    bool        lfo;       // FSR = amount, accel X = speed
    uint8_t     quant16;   // engage quantisation in 16ths (0 = immediate, 1 = next 16th, 2 = next 8th, 4 = next beat)
};
extern const FxInfo* FX_INFO;   // filled at fxInit() from the five family INFO arrays

struct FxState {
    // CONTROL writes
    volatile uint64_t held;                 // bit = effect id currently pressed (physical)
    volatile FxDir    view;                 // which page is showing (snaps home on release)
    // automation (patch-serialised)
    uint64_t auto_mask[MAXSTEPS];           // recorded held set per 16th
    uint8_t  auto_fsr[MAXSTEPS];            // 0..255
    bool     auto_rec;                      // recording gesture active
    bool     auto_enabled;
    // stutter shadow-clock shared with the sequencer
    float    varispeed_req;                 // 1, 0.5, 2, 0.06 (STOP) — clock.cpp slews to it
    // performance-page directional throws for drums/sampler (separate from the FX page)
    volatile float perf_up, perf_right, perf_down, perf_left;   // 0..1 amounts from the joystick
    volatile uint8_t perf_engine;           // Engine currently in performance, or 0xFF
    // store/patch.cpp addition: current distortion algorithm (DOWN family +
    // drum perf DOWN), patch-serialised. Value is a DistAlgo (declared below
    // this struct, hence uint8_t here rather than the enum type).
    uint8_t dist_algo;
    // HOME FILTER pad hold position: CONTROL (nav, joystick L/R) writes while held; AUDIO reads.
    // Left as-is on release.
    volatile float filter_pos;
    // continuous joystick position on the FX page (nav writes, render reads): the colour space
    volatile float push_x, push_y;          // -1..1, +Y = UP; 0,0 off the FX page
};
extern FxState fx;

void fxInit();
// AUDIO plane
void fxOnStep(uint32_t gstep, uint16_t* fire_masks /*[ENG_COUNT], may be modified for stutters*/);
void fxProcess(float* L, float* R, size_t n, float fsr, float lidar, float accel_x);
// performance-page directional throws (spec §4.4), applied to the drum/sampler perf bus
void fxProcessPerf(float* L, float* R, size_t n);
// stutter/BZZ retrigger notifications: fired at the chosen subdivision with the last
// captured per-engine fire masks, so the caller (audio plane) can re-trigger voices/hits.
typedef void (*FxRetrigCb)(const uint16_t* masks /*[ENG_COUNT]*/);
void fxSetRetrigCallback(FxRetrigCb cb);
// CONTROL plane
void fxPress(uint8_t id);
void fxRelease(uint8_t id);
void fxReleaseAll();
void fxSetView(FxDir d);
// distortion algorithm set (DOWN family + drum perf DOWN); switching crossfades 5 ms
enum DistAlgo : uint8_t { DIST_TANH_ASYM = 0, DIST_FOLD, DIST_FUZZ, DIST_WARM, DIST_FL, DIST_CRUSH, DIST_COUNT };
extern const char* const DIST_NAMES[DIST_COUNT];
