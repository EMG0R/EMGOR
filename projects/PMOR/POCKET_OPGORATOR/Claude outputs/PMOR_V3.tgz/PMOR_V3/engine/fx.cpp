// fx.cpp — the FX HOST: capture ring, per-effect anti-click fade envelopes, grid-locked
// stutter/BZZ retrigger scheduling, HALF/DBL/STOP shadow-clock arbitration, automation
// record/playback, the distortion crossfade utility, and the performance-page throws.
// The five family files (fx_home.cpp mine, fx_up/right/down/left.cpp others') only supply
// tables of Effect objects + FxInfo rows — all the engagement/timing/automation logic lives
// here.
#include <string.h>
#include <math.h>
#include "fx.h"
#include "fx_internal.h"
#include "fx_host.h"
#include "sequencer.h"
#include "shared_state.h"
#include "clock.h"
#include "engine_util.h"

FxState fx;

FxHostStut fx_host_stut;
FxHostVs   fx_host_vs;

// ---------------------------------------------------------------- capture ring (2 s stereo)
#define RING_N 96000u
static float SDRAM_BSS ringL[RING_N];
static float SDRAM_BSS ringR[RING_N];
static uint32_t ring_w      = 0;
static uint32_t s_step_ring_w = 0;   // ring_w latched at the last 16th boundary

// ---------------------------------------------------------------- FX_INFO storage
static FxInfo fx_info_storage[FX_TOTAL];
const FxInfo* FX_INFO = fx_info_storage;   // strong definition (header: extern const FxInfo*)

static Effect* effectFor(uint8_t id) {
    if (id < FX_HOME) return FX_HOME_TABLE[id];
    id = (uint8_t)(id - FX_HOME);
    if (id < FX_PER_DIR) return FX_UP_TABLE[id];
    id = (uint8_t)(id - FX_PER_DIR);
    if (id < FX_PER_DIR) return FX_RIGHT_TABLE[id];
    id = (uint8_t)(id - FX_PER_DIR);
    if (id < FX_PER_DIR) return FX_DOWN_TABLE[id];
    id = (uint8_t)(id - FX_PER_DIR);
    return FX_LEFT_TABLE[id];
}

// ---------------------------------------------------------------- per-effect fade envelopes
static float s_fade[FX_TOTAL];
static bool  s_active[FX_TOTAL];
// deferred engage: clocked effects wait for the next boundary of their subdivision
// (FX_INFO[id].quant16), unless pressed within FX_LATE_TOL of a boundary that just passed.
static bool     s_pending[FX_TOTAL];
static uint32_t s_wait_period[FX_TOTAL];
#define FX_LATE_TOL 0.12f   // fraction of a 16th treated as "on time" after a boundary

// engage quantisation by effect name (set once at fxInit; family tables leave quant16 = 0)
static uint8_t quantForName(const char* nm) {
    struct Q { const char* n; uint8_t q; };
    static const Q T[] = {
        {"ST4",4},{"ST8",2},{"ST16",1},{"ST32",1},{"BZZ",1},{"HALF",4},{"DBL",4},
        {"REV",4},{"REV2",4},{"REVBR",4},{"PUMP",1},{"GATE8",1},{"GAT16",1},{"TGATE",1},
        {"STAB",1},{"REPT",1},{"SCAT",1},{"SRAMP",1},{"BALL",1},{"DELAY",1},{"PNGPG",1},
        {"FADE",1},{"LOOP",1},{"FREEZ",1},{"PONG",1},{"DUB",1},
    };
    for (unsigned i = 0; i < sizeof(T)/sizeof(T[0]); i++) {
        const char* a = T[i].n; const char* b = nm;
        while (*a && *b && *a == *b) { a++; b++; }
        if (!*a && !*b) return T[i].q;
    }
    return 0;
}

// ---------------------------------------------------------------- stutter/BZZ retrigger
static uint16_t   last_masks[ENG_COUNT];
static FxRetrigCb s_retrig_cb = nullptr;
static uint32_t   s_abs_sample = 0;   // fx.cpp's own free-running sample counter (relative timing only)

static void fxRetrigTick(const FxCtx& ctx, size_t n) {
    static uint32_t s_period     = 0;
    static uint32_t s_next       = 0;
    static uint32_t s_last_gstep = 0xFFFFFFFFu;
    static uint32_t s_bzz_rng    = 0xC0FFEEu;

    bool active = (fx_host_stut.rate != STUT_NONE) || fx_host_stut.bzz;
    if (!active) { s_period = 0; s_last_gstep = 0xFFFFFFFFu; return; }

    if (s_last_gstep != ctx.gstep) {
        s_last_gstep = ctx.gstep;
        uint32_t period;
        if (fx_host_stut.bzz) {
            static const uint8_t DIVS[5] = {2, 3, 4, 6, 8};
            uint32_t r  = lcg(s_bzz_rng);
            int      di = (int)(r % 3u) + (int)(ctx.fsr * 2.49f);
            if (di > 4) di = 4;
            if (di < 0) di = 0;
            period = (uint32_t)(ctx.step_samples / (float)DIVS[di]);
        } else {
            float mul = (fx_host_stut.rate == STUT_4)  ? 4.f
                      : (fx_host_stut.rate == STUT_8)  ? 2.f
                      : (fx_host_stut.rate == STUT_16) ? 1.f : 0.5f;
            period = (uint32_t)(ctx.step_samples * mul);
        }
        if (period < 128u) period = 128u;   // ~2.7 ms floor — keeps retrig CPU bounded
        s_period = period;
        s_next   = s_abs_sample;            // fire right at this new grid boundary (arm-and-fire)
    }

    int guard = 8;   // bound the catch-up loop; a runaway period would otherwise spin here
    while (s_period && s_next < s_abs_sample + n && guard-- > 0) {
        if (s_retrig_cb) s_retrig_cb(last_masks);
        s_next += s_period;
    }
}

// ---------------------------------------------------------------- distortion crossfade
static uint8_t s_dist_prev       = DIST_TANH_ASYM;
static uint8_t s_dist_cur        = DIST_TANH_ASYM;
static float   s_dist_xfade      = 1.f;   // 1 = fully switched to cur
static float   s_dist_xfade_step = 0.f;

float fxDistXfade(float x, float drive) {
    if (fx.dist_algo != s_dist_cur) {
        s_dist_prev       = s_dist_cur;
        s_dist_cur        = fx.dist_algo;
        s_dist_xfade       = 0.f;
        s_dist_xfade_step = 1.f / (DIST_XFADE_MS * 0.001f * SR);
    }
    float outp = fxDistSample((DistAlgo)s_dist_cur, x, drive);
    if (s_dist_xfade < 1.f) {
        float outo = fxDistSample((DistAlgo)s_dist_prev, x, drive);
        outp = outo + (outp - outo) * s_dist_xfade;
        s_dist_xfade += s_dist_xfade_step;
        if (s_dist_xfade > 1.f) s_dist_xfade = 1.f;
    }
    return outp;
}

// ---------------------------------------------------------------- init
void fxInit() {
    memset(&fx, 0, sizeof(fx));
    fx.varispeed_req = 1.f;
    fx.perf_engine    = 0xFF;
    fx.filter_pos     = 0.5f;
    fx.dist_algo      = DIST_TANH_ASYM;

    memset(ringL, 0, sizeof(ringL));
    memset(ringR, 0, sizeof(ringR));
    ring_w = 0; s_step_ring_w = 0; s_abs_sample = 0;

    memset(s_fade, 0, sizeof(s_fade));
    memset(s_active, 0, sizeof(s_active));
    memset(last_masks, 0, sizeof(last_masks));
    s_retrig_cb = nullptr;

    fx_host_stut.rate = STUT_NONE; fx_host_stut.bzz = false;
    fx_host_vs.half = fx_host_vs.dbl = fx_host_vs.stop = false;

    s_dist_prev = s_dist_cur = fx.dist_algo;
    s_dist_xfade = 1.f; s_dist_xfade_step = 0.f;

    for (int i = 0; i < FX_HOME; i++)    fx_info_storage[i] = FX_HOME_INFO[i];
    for (int i = 0; i < FX_PER_DIR; i++) fx_info_storage[FX_HOME + i] = FX_UP_INFO[i];
    for (int i = 0; i < FX_PER_DIR; i++) fx_info_storage[FX_HOME + FX_PER_DIR + i] = FX_RIGHT_INFO[i];
    for (int i = 0; i < FX_PER_DIR; i++) fx_info_storage[FX_HOME + 2 * FX_PER_DIR + i] = FX_DOWN_INFO[i];
    for (int i = 0; i < FX_PER_DIR; i++) fx_info_storage[FX_HOME + 3 * FX_PER_DIR + i] = FX_LEFT_INFO[i];
    FX_INFO = fx_info_storage;
    for (int i = 0; i < FX_TOTAL; i++) fx_info_storage[i].quant16 = quantForName(fx_info_storage[i].name);
    memset(s_pending, 0, sizeof(s_pending));

    for (int i = 0; i < FX_HOME; i++)    FX_HOME_TABLE[i]->init();
    for (int i = 0; i < FX_PER_DIR; i++) FX_UP_TABLE[i]->init();
    for (int i = 0; i < FX_PER_DIR; i++) FX_RIGHT_TABLE[i]->init();
    for (int i = 0; i < FX_PER_DIR; i++) FX_DOWN_TABLE[i]->init();
    for (int i = 0; i < FX_PER_DIR; i++) FX_LEFT_TABLE[i]->init();
}

// ---------------------------------------------------------------- AUDIO plane: per 16th
void fxOnStep(uint32_t gstep, uint16_t* fire_masks) {
    bool stut_held = (fx_host_stut.rate != STUT_NONE) || fx_host_stut.bzz;
    bool any_new = false;
    for (int e = 0; e < ENG_COUNT; e++) if (fire_masks[e]) any_new = true;
    // sticky content register: keep the last non-empty step's masks around for retriggering,
    // exactly like they'd otherwise be lost once fire_masks is consumed (PMOR_V2.cpp L1999-2011).
    if (any_new || !stut_held) {
        for (int e = 0; e < ENG_COUNT; e++) last_masks[e] = fire_masks[e];
    }
    // while a stutter/BZZ effect governs retriggering, the audible hits come only from the
    // sample-accurate scheduler in fxProcess — suppress the plain per-step firing.
    if (stut_held) {
        for (int e = 0; e < ENG_COUNT; e++) fire_masks[e] = 0;
    }
    // automation recording: snapshot the physically-held set + FSR into this step's slot
    {
        uint32_t loop_len = clk.loop_len ? clk.loop_len : 1u;
        uint32_t idx = gstep % loop_len;
        if (fx.auto_rec && idx < MAXSTEPS) {
            fx.auto_mask[idx] = fx.held;                        // empty hands = scrub this step clean
            fx.auto_fsr[idx]  = (uint8_t)(clampf(g.fsr, 0.f, 1.f) * 255.f);
            if (fx.held) fx.auto_enabled = true;                // playback is on as soon as anything is recorded
        }
    }
    s_step_ring_w = ring_w;
}

// ---------------------------------------------------------------- AUDIO plane: per block
void fxProcess(float* L, float* R, size_t n, float fsr, float lidar, float accel_x) {
    // capture ring: DRY mix, written before any effect runs
    for (size_t i = 0; i < n; i++) {
        ringL[ring_w] = L[i]; ringR[ring_w] = R[i];
        ring_w++; if (ring_w >= RING_N) ring_w = 0;
    }

    // effective held set = physically held | automation playback for the current step
    uint32_t loop_len   = clk.loop_len ? clk.loop_len : 1u;
    uint32_t idx         = clk.gstep % loop_len;
    uint64_t auto_bits   = fx.auto_enabled ? fx.auto_mask[idx] : 0ULL;
    uint64_t eff_held    = fx.held | auto_bits;
    float    eff_fsr     = clampf(fsr, 0.f, 1.f);
    if (fx.auto_enabled && auto_bits) {
        float af = fx.auto_fsr[idx] * (1.f / 255.f);
        if (af > eff_fsr) eff_fsr = af;
    }

    FxCtx ctx;
    ctx.fsr          = eff_fsr;
    ctx.lidar        = clampf(lidar, 0.f, 1.f);
    ctx.accel_x      = clampf(accel_x, -1.f, 1.f);
    ctx.step_phase   = clk.step_phase;
    ctx.step_samples = clk.step_samples;
    ctx.gstep        = clk.gstep;
    ctx.sample_now   = s_abs_sample;
    ctx.varispeed    = clk.varispeed;
    ctx.ringL = ringL; ctx.ringR = ringR; ctx.ring_w = ring_w; ctx.ring_n = RING_N;
    ctx.step_ring_w  = s_step_ring_w;

    // anti-click engage/release fade + process, in order HOME, UP, RIGHT, DOWN, LEFT
    // (that's exactly ascending id order thanks to fxId()'s layout).
    float fade_inc = (float)n / (FX_FADE_MS * 0.001f * SR);
    for (uint16_t id = 0; id < FX_TOTAL; id++) {
        bool    want = (eff_held >> id) & 1ULL;
        Effect* e    = effectFor((uint8_t)id);
        if (want && !s_active[id]) {
            uint8_t q = fx_info_storage[id].quant16;
            bool go = true;
            if (q > 0 && clk.step_samples > 0.f) {
                uint32_t period = ctx.gstep / q;                       // index of the current subdivision period
                float    pos    = (float)(ctx.gstep % q) + ctx.step_phase;   // position inside it, in 16ths
                if (!s_pending[id]) {
                    if (pos <= FX_LATE_TOL) { go = true; }            // just after a boundary: treat as on time
                    else { s_pending[id] = true; s_wait_period[id] = period; go = false; }
                } else {
                    go = (period != s_wait_period[id]);                // next boundary reached (loop wrap included)
                }
            }
            if (go) {
                s_pending[id] = false;
                e->onEngage(ctx);
                s_active[id] = true;
            }
        }
        if (!want) s_pending[id] = false;                             // released before it engaged: cancel
        if (want && s_active[id]) {
            s_fade[id] += fade_inc; if (s_fade[id] > 1.f) s_fade[id] = 1.f;
        } else if (s_active[id]) {
            s_fade[id] -= fade_inc;
            if (s_fade[id] <= 0.f) {
                s_fade[id] = 0.f;
                e->onRelease(ctx);
                s_active[id] = false;
            }
        }
        if (s_fade[id] > 0.f) e->process(L, R, n, ctx, s_fade[id]);
    }

    fxRetrigTick(ctx, n);

    // shadow-clock request: most dramatic wins when more than one is held, 1.0 when none are
    if (fx_host_vs.stop)      fx.varispeed_req = 0.06f;
    else if (fx_host_vs.dbl)  fx.varispeed_req = 2.f;
    else if (fx_host_vs.half) fx.varispeed_req = 0.5f;
    else                      fx.varispeed_req = 1.f;

    s_abs_sample += (uint32_t)n;
}

// ---------------------------------------------------------------- performance throws (§4.4)
// Applied to the drum/sampler perf bus in place. UP/RIGHT are additive sends (their own input
// stage is gated by a 5 ms envelope of the amount, so releasing cuts new material in while any
// existing tail keeps ringing on its own feedback); DOWN/LEFT are inserts crossfaded dry->wet
// by the same 5 ms envelope.
#define SPRING_AP_N 3
static const uint16_t SPRING_AP_LEN[SPRING_AP_N] = {225, 341, 441};
static float    spring_apL[SPRING_AP_N][512];
static float    spring_apR[SPRING_AP_N][512];
static uint16_t spring_ap_w[SPRING_AP_N];

#define SPRING_DISP_N 1536u
static float    spring_dispL[SPRING_DISP_N];
static float    spring_dispR[SPRING_DISP_N];
static uint16_t spring_disp_w = 0;
static float    spring_disp_lfo = 0.f;
static float    spring_disp_lpL = 0.f, spring_disp_lpR = 0.f;

#define SPRING_COMB_NL 4800u
#define SPRING_COMB_NR 5300u
static float SDRAM_BSS spring_combL[SPRING_COMB_NL];
static float SDRAM_BSS spring_combR[SPRING_COMB_NR];
static uint16_t spring_comb_wL = 0, spring_comb_wR = 0;

#define PERF_DLY_N 48000u   // 1 s safety cap
static float SDRAM_BSS perf_dlyL[PERF_DLY_N];
static float SDRAM_BSS perf_dlyR[PERF_DLY_N];
static uint32_t perf_dly_w = 0;

static bool    s_perf_init = false;
static OnePole s_gUp, s_gRight, s_gDown, s_gLeft;
static uint32_t s_bc_cnt   = 0;
static float    s_bc_holdL = 0.f, s_bc_holdR = 0.f;

void fxProcessPerf(float* L, float* R, size_t n) {
    if (!s_perf_init) {
        s_perf_init = true;
        memset(spring_apL, 0, sizeof(spring_apL));
        memset(spring_apR, 0, sizeof(spring_apR));
        memset(spring_ap_w, 0, sizeof(spring_ap_w));
        memset(spring_dispL, 0, sizeof(spring_dispL));
        memset(spring_dispR, 0, sizeof(spring_dispR));
        memset(spring_combL, 0, sizeof(spring_combL));
        memset(spring_combR, 0, sizeof(spring_combR));
        memset(perf_dlyL, 0, sizeof(perf_dlyL));
        memset(perf_dlyR, 0, sizeof(perf_dlyR));
        s_gUp.setMs(5.f, BLOCK_HZ); s_gRight.setMs(5.f, BLOCK_HZ);
        s_gDown.setMs(5.f, BLOCK_HZ); s_gLeft.setMs(5.f, BLOCK_HZ);
    }

    float upAmt    = s_gUp.process(clampf(fx.perf_up, 0.f, 1.f));
    float rightAmt = s_gRight.process(clampf(fx.perf_right, 0.f, 1.f));
    float downAmt  = s_gDown.process(clampf(fx.perf_down, 0.f, 1.f));
    float leftAmt  = s_gLeft.process(clampf(fx.perf_left, 0.f, 1.f));

    float delaySamp = clk.step_samples * 2.f;   // 1/8-note (2 sixteenths)
    if (delaySamp < 4.f) delaySamp = 4.f;
    if (delaySamp > (float)(PERF_DLY_N - 4u)) delaySamp = (float)(PERF_DLY_N - 4u);

    uint32_t bc_hold    = 1u + (uint32_t)(leftAmt * 30.f);
    float    bc_bits    = 16.f - leftAmt * 12.f;              // 16 (clean) .. 4 (crushed)
    float    bc_q       = fastPow2(bc_bits - 1.f);
    float    bc_invq    = 1.f / bc_q;
    float    dist_drive = 1.f + downAmt * 3.f;                // 1..4

    for (size_t i = 0; i < n; i++) {
        float inL = L[i], inR = R[i];
        float outL = inL, outR = inR;

        // ---- UP: spring reverb — 3 short allpass chains -> modulated ~30 ms dispersive
        // delay feeding back through a low-pass -> ~1.2 s comb tail
        {
            float apL = inL * upAmt, apR = inR * upAmt;
            for (int s = 0; s < SPRING_AP_N; s++) {
                uint16_t wi  = spring_ap_w[s];
                uint16_t len = SPRING_AP_LEN[s];
                float    dL  = spring_apL[s][wi];
                float    dR  = spring_apR[s][wi];
                const float ag = 0.5f;
                float yL = -ag * apL + dL; spring_apL[s][wi] = apL + ag * yL;
                float yR = -ag * apR + dR; spring_apR[s][wi] = apR + ag * yR;
                wi++; if (wi >= len) wi = 0;
                spring_ap_w[s] = wi;
                apL = yL; apR = yR;
            }
            spring_disp_lfo += 1.4f * (1.f / SR); if (spring_disp_lfo >= 1.f) spring_disp_lfo -= 1.f;
            float mod   = 6.f * sinf(spring_disp_lfo * 6.2831853f);
            float dtime = 1200.f + mod; if (dtime < 4.f) dtime = 4.f;
            float rdL = fxRingRead(spring_dispL, SPRING_DISP_N, spring_disp_w, dtime);
            float rdR = fxRingRead(spring_dispR, SPRING_DISP_N, spring_disp_w, dtime);
            spring_disp_lpL += 0.35f * (rdL - spring_disp_lpL);
            spring_disp_lpR += 0.35f * (rdR - spring_disp_lpR);
            spring_dispL[spring_disp_w] = flushDenorm(apL + spring_disp_lpL * 0.55f);
            spring_dispR[spring_disp_w] = flushDenorm(apR + spring_disp_lpR * 0.55f);
            spring_disp_w++; if (spring_disp_w >= SPRING_DISP_N) spring_disp_w = 0;

            float cbL = spring_combL[spring_comb_wL];
            float cbR = spring_combR[spring_comb_wR];
            spring_combL[spring_comb_wL] = flushDenorm(spring_disp_lpL + cbL * 0.5624f);
            spring_combR[spring_comb_wR] = flushDenorm(spring_disp_lpR + cbR * 0.5624f);
            spring_comb_wL++; if (spring_comb_wL >= SPRING_COMB_NL) spring_comb_wL = 0;
            spring_comb_wR++; if (spring_comb_wR >= SPRING_COMB_NR) spring_comb_wR = 0;

            outL += (spring_disp_lpL * 0.6f + cbL * 0.8f) * upAmt;
            outR += (spring_disp_lpR * 0.6f + cbR * 0.8f) * upAmt;
        }

        // ---- RIGHT: 1/8-note stereo delay throw, feedback 0.45 (tanh-saturated), 50/50 mix
        {
            float rdL = fxRingRead(perf_dlyL, PERF_DLY_N, perf_dly_w, delaySamp);
            float rdR = fxRingRead(perf_dlyR, PERF_DLY_N, perf_dly_w, delaySamp);
            perf_dlyL[perf_dly_w] = flushDenorm(inL * rightAmt + fxTanh(rdL * 0.45f));
            perf_dlyR[perf_dly_w] = flushDenorm(inR * rightAmt + fxTanh(rdR * 0.45f));
            perf_dly_w++; if (perf_dly_w >= PERF_DLY_N) perf_dly_w = 0;
            outL += rdL * 0.5f; outR += rdR * 0.5f;
        }

        // ---- DOWN: distortion (insert, dry/wet crossfade by amount)
        {
            float dL = fxDistXfade(inL, dist_drive);
            float dR = fxDistXfade(inR, dist_drive);
            outL += (dL - inL) * downAmt;
            outR += (dR - inR) * downAmt;
        }

        // ---- LEFT: bitcrush, rate + bits from the amount (insert, dry/wet crossfade)
        {
            if (s_bc_cnt == 0) { s_bc_holdL = inL; s_bc_holdR = inR; }
            s_bc_cnt++; if (s_bc_cnt >= bc_hold) s_bc_cnt = 0;
            float bcL = floorf(s_bc_holdL * bc_q) * bc_invq;
            float bcR = floorf(s_bc_holdR * bc_q) * bc_invq;
            outL += (bcL - inL) * leftAmt;
            outR += (bcR - inR) * leftAmt;
        }

        L[i] = flushBad(outL);
        R[i] = flushBad(outR);
    }
}

void fxSetRetrigCallback(FxRetrigCb cb) { s_retrig_cb = cb; }

// ---------------------------------------------------------------- CONTROL plane
void fxPress(uint8_t id)   { if (id < FX_TOTAL) fx.held |= (1ULL << id); }
void fxRelease(uint8_t id) { if (id < FX_TOTAL) fx.held &= ~(1ULL << id); }
void fxReleaseAll()        { fx.held = 0; }
void fxSetView(FxDir d)    { fx.view = d; }
