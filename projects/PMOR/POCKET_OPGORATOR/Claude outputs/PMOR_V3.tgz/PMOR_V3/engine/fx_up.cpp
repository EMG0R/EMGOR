// fx_up.cpp — FXD_UP family: stutter/glitch/stabs + spatial (12 pads).
// Ported from PMOR_V2.cpp per research/v2-audit.md §3 (line refs in each class).
// Most effects read straight from the shared 2 s dry capture ring (FxCtx::ringL/ringR)
// instead of keeping a private copy of the same audio; only the effects that fold their
// own WET output back into a delay line (feedback) or that must stay genuinely frozen
// past the ring's 2 s horizon get an owned SDRAM buffer.
#include <string.h>
#include "fx_internal.h"
#include "engine_util.h"

static const float kTwoPi = 6.283185307f;

// 0 SCAT — random 16th-slice scatter read from the ring. V2 L2726-2737.
class FxUpScat : public Effect {
    uint32_t rng_ = 0xA51C9E3u;
    uint32_t lastGstep_ = 0xFFFFFFFFu;
    uint32_t base_ = 0, since_ = 0;
    void onEngage(const FxCtx&) override { lastGstep_ = 0xFFFFFFFFu; base_ = 0; since_ = 0; }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        uint32_t half = c.ring_n / 2u;
        uint32_t slice = (uint32_t)c.step_samples;
        if (slice < 480u) slice = 480u;
        if (slice > half) slice = half;
        if (lastGstep_ != c.gstep) {
            lastGstep_ = c.gstep;
            if (lcg01(rng_) * 100.f < (20.f + 70.f * c.fsr))
                base_ = (lcg(rng_) % 8u) * slice;
        }
        float gate = (c.fsr > 0.03f) ? 1.f : 0.f;
        float mix = amt * gate;
        for (size_t i = 0; i < n; i++) {
            uint32_t off = (base_ + (since_ % slice)) % c.ring_n;
            uint32_t idx = (c.step_ring_w + c.ring_n - off) % c.ring_n;
            L[i] = fxLerp(L[i], c.ringL[idx], mix);
            R[i] = fxLerp(R[i], c.ringR[idx], mix);
            since_++;
        }
    }
};

// 1 REPT — beat-repeat half-step slices read from the ring. V2 L2914-2924.
class FxUpRept : public Effect {
    uint32_t rng_ = 0xBEEF1234u;
    uint32_t lastGstep_ = 0xFFFFFFFFu;
    uint32_t base_ = 0, since_ = 0;
    void onEngage(const FxCtx&) override { lastGstep_ = 0xFFFFFFFFu; base_ = 0; since_ = 0; }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        uint32_t quarter = c.ring_n / 4u;
        uint32_t slice = (uint32_t)(c.step_samples * 0.5f);
        if (slice < 240u) slice = 240u;
        if (slice > quarter) slice = quarter;
        if (lastGstep_ != c.gstep) {
            lastGstep_ = c.gstep;
            if (lcg01(rng_) * 255.f < (40.f + 200.f * c.fsr))
                base_ = (lcg(rng_) % 4u) * slice;
        }
        for (size_t i = 0; i < n; i++) {
            uint32_t off = (base_ + (since_ % slice)) % c.ring_n;
            uint32_t idx = (c.step_ring_w + c.ring_n - off) % c.ring_n;
            L[i] = fxLerp(L[i], c.ringL[idx], amt);
            R[i] = fxLerp(R[i], c.ringR[idx], amt);
            since_++;
        }
    }
};

// 2 BALL — bouncing-ball accelerating decaying retrigger, read from the ring.
// V2 L3063-3067; period/time state fully reset in onEngage (defect: V2's `per`
// static never reset between presses).
class FxUpBall : public Effect {
    float t_ = 0.f, per_ = 4000.f;
    void onEngage(const FxCtx&) override { t_ = 0.f; per_ = 4000.f; }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        for (size_t i = 0; i < n; i++) {
            t_ += 1.f;
            if (t_ >= per_) {
                t_ = 0.f; per_ *= 0.7f;
                if (per_ < 400.f) per_ = 4000.f * (0.5f + 0.5f * c.fsr);
            }
            float dec = 1.f - (t_ / per_) * 0.8f;
            float back = t_ + (float)(n - 1u - i);
            float wl = fxRingRead(c.ringL, c.ring_n, c.ring_w, back);
            float wr = fxRingRead(c.ringR, c.ring_n, c.ring_w, back);
            float mono = (wl + wr) * 0.5f * dec;
            L[i] = fxLerp(L[i], mono, amt);
            R[i] = fxLerp(R[i], mono, amt);
        }
    }
};

// 3 GATE8 — grid-locked 50%-ish duty gate, period = 2 sixteenths. V2 L3208-3212 (GATE_N).
// FSR narrows the duty (all UP effects are FSR-modulated).
class FxUpGate8 : public Effect {
    float env_ = 1.f;
    void onEngage(const FxCtx&) override { env_ = 1.f; }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        float duty = 0.5f - 0.3f * c.fsr;                       // 50 % duty, FSR tightens it (never silent)
        for (size_t i = 0; i < n; i++) {
            float ph = ((float)(c.gstep & 1u) + c.step_phase + (float)i / c.step_samples) * 0.5f;   // 8th = two 16ths
            ph -= floorf(ph);
            float target = (ph < duty) ? 1.f : 0.f;
            env_ += (target - env_) * 0.05f;
            float g = 1.f - amt * (1.f - env_);
            L[i] *= g; R[i] *= g;
        }
    }
};

// 4 GAT16 — same as GATE8 but period = 1 sixteenth. V2 L3208-3212 (GATE_N).
class FxUpGate16 : public Effect {
    float env_ = 1.f;
    void onEngage(const FxCtx&) override { env_ = 1.f; }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        float duty = 0.5f - 0.3f * c.fsr;                       // 50 % duty, FSR tightens it (never silent)
        for (size_t i = 0; i < n; i++) {
            float ph = c.step_phase + (float)i / c.step_samples;
            ph -= floorf(ph);
            float target = (ph < duty) ? 1.f : 0.f;
            env_ += (target - env_) * 0.06f;
            float g = 1.f - amt * (1.f - env_);
            L[i] *= g; R[i] *= g;
        }
    }
};

// 5 TGATE — 16-step trance gate, double-time above FSR 0.6. V2 L2616-2623.
class FxUpTgate : public Effect {
    static const uint16_t kPat = 0xB6D6;
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        bool doubleTime = c.fsr > 0.6f;
        for (size_t i = 0; i < n; i++) {
            float ph = c.step_phase + (float)i / c.step_samples;
            int st;
            if (doubleTime) {
                float ph2 = ph * 2.f; ph2 -= floorf(ph2);
                int half = (int)((c.step_phase + (float)i / c.step_samples) * 2.f);
                st = (int)((c.gstep * 2u + (uint32_t)half) & 15u);
                (void)ph2;
            } else {
                st = (int)(c.gstep & 15u);
            }
            float on = ((kPat >> st) & 1u) ? 1.f : (0.6f - c.fsr * 0.6f);
            float g = 1.f - amt * (1.f - on);
            L[i] *= g; R[i] *= g;
        }
    }
};

// 6 STAB — new: 16th-locked gate, 5 ms attack, exponential decay whose length
// comes from FSR (short/tight at 0, long/loose at 1).
class FxUpStab : public Effect {
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        float attackSamp = 0.005f * SR;
        float decayLen = fxLerp(0.35f * c.step_samples, 0.06f * c.step_samples, c.fsr);   // audible at no FSR; FSR tightens the stab
        for (size_t i = 0; i < n; i++) {
            float t = (c.step_phase + (float)i / c.step_samples) * c.step_samples;
            float tp = fmodf(t, c.step_samples);
            float env;
            if (tp < attackSamp) env = tp / attackSamp;
            else                 env = expf(-(tp - attackSamp) / decayLen);
            float g = 1.f - amt * (1.f - env);
            L[i] *= g; R[i] *= g;
        }
    }
};

// 7 FREEZ — windowed loop of the last 12->112 ms, genuinely frozen: the window
// is snapshotted once at onEngage from the ring so the loop content does not
// drift or get overwritten by fresh audio while held. FSR reshapes the loop
// length live within the captured snapshot. V2 L2933-2940 (there it kept
// re-reading a live rolling buffer, i.e. not really frozen).
static const uint32_t kFreezeMax = 5400u;                             // 112.5 ms @ 48 kHz
static float SDRAM_BSS s_freezL[kFreezeMax];
static float SDRAM_BSS s_freezR[kFreezeMax];
class FxUpFreez : public Effect {
    float pos_ = 0.f;
    void init() override { memset(s_freezL, 0, sizeof(s_freezL)); memset(s_freezR, 0, sizeof(s_freezR)); }
    void onEngage(const FxCtx& c) override {
        pos_ = 0.f;
        for (uint32_t k = 0; k < kFreezeMax; k++) {
            float back = (float)(kFreezeMax - 1u - k);
            s_freezL[k] = fxRingRead(c.ringL, c.ring_n, c.ring_w, back);
            s_freezR[k] = fxRingRead(c.ringR, c.ring_n, c.ring_w, back);
        }
    }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        float len = fxLerp(600.f, (float)kFreezeMax, 1.f - c.fsr);
        if (len < 64.f) len = 64.f;
        if (len > (float)kFreezeMax) len = (float)kFreezeMax;
        const float fade = 32.f;
        for (size_t i = 0; i < n; i++) {
            if (pos_ >= len) pos_ -= len;
            uint32_t idx = (uint32_t)pos_;
            if (idx >= (uint32_t)len) idx = (uint32_t)len - 1u;
            uint32_t base = kFreezeMax - (uint32_t)len;
            float w = 1.f;
            if (pos_ < fade) w = pos_ / fade;
            else if (len - pos_ < fade) w = (len - pos_) / fade;
            float wl = s_freezL[base + idx] * w;
            float wr = s_freezR[base + idx] * w;
            L[i] = fxLerp(L[i], wl, amt);
            R[i] = fxLerp(R[i], wr, amt);
            pos_ += 1.f;
        }
    }
};

// 8 PONG — ping-pong at ~1.5 steps, cross-fed with tanh feedback. lidar = fb,
// FSR = mix. V2 L2765-2775 (own buffer there was shared with SHIM; here it is
// private). SDRAM: 2 s stereo so the delay stays valid across tempos.
static const uint32_t kPongN = 96000u;                                // 2 s @ 48 kHz
static float SDRAM_BSS s_pongL[kPongN];
static float SDRAM_BSS s_pongR[kPongN];
class FxUpPong : public Effect {
    uint32_t w_ = 0;
    void init() override { memset(s_pongL, 0, sizeof(s_pongL)); memset(s_pongR, 0, sizeof(s_pongR)); w_ = 0; }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        float fb = 0.35f + c.lidar * 0.6f;
        float mixAmt = 0.3f + c.fsr * 0.6f;
        uint32_t delaySamp = (uint32_t)(c.step_samples * 1.5f);
        if (delaySamp >= kPongN) delaySamp = kPongN - 1u;
        if (delaySamp < 480u) delaySamp = 480u;
        for (size_t i = 0; i < n; i++) {
            uint32_t rp = (w_ + kPongN - delaySamp) % kPongN;
            float eL = s_pongR[rp];                                    // cross-fed
            float eR = s_pongL[rp];
            s_pongL[w_] = fxTanh(L[i] + eL * fb);
            s_pongR[w_] = fxTanh(R[i] + eR * fb);
            w_ = (w_ + 1u) % kPongN;
            float outL = L[i] * (1.f - mixAmt * 0.5f) + eL * mixAmt;
            float outR = R[i] * (1.f - mixAmt * 0.5f) + eR * mixAmt;
            L[i] = fxLerp(L[i], outL, amt);
            R[i] = fxLerp(R[i], outR, amt);
        }
    }
};

// 9 HAAS — Haas widener, 8-30 sample offset read straight from the ring so
// there is no private buffer to keep warm; both channels processed
// independently (stereo-safe — V2 briefly summed to mono for the mid). V2 L2811-2817.
class FxUpHaas : public Effect {
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        float widthGain = 1.f + c.fsr * 0.6f;
        float delaySamp = 8.f + c.fsr * 22.f;
        for (size_t i = 0; i < n; i++) {
            float back = delaySamp + (float)(n - 1u - i);
            float dr = fxRingRead(c.ringR, c.ring_n, c.ring_w, back);
            float m = (L[i] + R[i]) * 0.5f;
            float outL = m + (L[i] - m) * widthGain;
            float outR = m + (dr - m) * widthGain;
            L[i] = fxLerp(L[i], outL, amt);
            R[i] = fxLerp(R[i], outR, amt);
        }
    }
};

// 10 ROOM — NEW Schroeder reverb: 4 parallel combs -> 2 series allpasses per
// channel, stereo via de-correlated delay lengths. FSR = decay (RT60
// 0.2..1.4 s, ~0.8 s at the centre). All state in SDRAM.
static const uint32_t kRoomC0 = 1557, kRoomC1 = 1617, kRoomC2 = 1491, kRoomC3 = 1422;
static const uint32_t kRoomCR0 = 1601, kRoomCR1 = 1661, kRoomCR2 = 1535, kRoomCR3 = 1466;
static const uint32_t kRoomAp1 = 556, kRoomAp2 = 441, kRoomApR1 = 579, kRoomApR2 = 463;
static float SDRAM_BSS s_roomCL0[kRoomC0], s_roomCL1[kRoomC1], s_roomCL2[kRoomC2], s_roomCL3[kRoomC3];
static float SDRAM_BSS s_roomCR0[kRoomCR0], s_roomCR1[kRoomCR1], s_roomCR2[kRoomCR2], s_roomCR3[kRoomCR3];
static float SDRAM_BSS s_roomApL1[kRoomAp1], s_roomApL2[kRoomAp2];
static float SDRAM_BSS s_roomApR1[kRoomApR1], s_roomApR2[kRoomApR2];
class FxUpRoom : public Effect {
    uint32_t wc0_ = 0, wc1_ = 0, wc2_ = 0, wc3_ = 0;
    uint32_t wcr0_ = 0, wcr1_ = 0, wcr2_ = 0, wcr3_ = 0;
    uint32_t wap1_ = 0, wap2_ = 0, wapr1_ = 0, wapr2_ = 0;
    void init() override {
        memset(s_roomCL0, 0, sizeof(s_roomCL0)); memset(s_roomCL1, 0, sizeof(s_roomCL1));
        memset(s_roomCL2, 0, sizeof(s_roomCL2)); memset(s_roomCL3, 0, sizeof(s_roomCL3));
        memset(s_roomCR0, 0, sizeof(s_roomCR0)); memset(s_roomCR1, 0, sizeof(s_roomCR1));
        memset(s_roomCR2, 0, sizeof(s_roomCR2)); memset(s_roomCR3, 0, sizeof(s_roomCR3));
        memset(s_roomApL1, 0, sizeof(s_roomApL1)); memset(s_roomApL2, 0, sizeof(s_roomApL2));
        memset(s_roomApR1, 0, sizeof(s_roomApR1)); memset(s_roomApR2, 0, sizeof(s_roomApR2));
    }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        float rt60 = fxLerp(0.2f, 1.4f, c.fsr);
        float fb0 = powf(0.001f, (float)kRoomC0 / (rt60 * SR));
        float fb1 = powf(0.001f, (float)kRoomC1 / (rt60 * SR));
        float fb2 = powf(0.001f, (float)kRoomC2 / (rt60 * SR));
        float fb3 = powf(0.001f, (float)kRoomC3 / (rt60 * SR));
        float fbr0 = powf(0.001f, (float)kRoomCR0 / (rt60 * SR));
        float fbr1 = powf(0.001f, (float)kRoomCR1 / (rt60 * SR));
        float fbr2 = powf(0.001f, (float)kRoomCR2 / (rt60 * SR));
        float fbr3 = powf(0.001f, (float)kRoomCR3 / (rt60 * SR));
        const float apG = 0.5f;
        for (size_t i = 0; i < n; i++) {
            float mono = (L[i] + R[i]) * 0.5f;

            float t0 = s_roomCL0[wc0_]; s_roomCL0[wc0_] = flushDenorm(mono + t0 * fb0); wc0_ = (wc0_ + 1u) % kRoomC0;
            float t1 = s_roomCL1[wc1_]; s_roomCL1[wc1_] = flushDenorm(mono + t1 * fb1); wc1_ = (wc1_ + 1u) % kRoomC1;
            float t2 = s_roomCL2[wc2_]; s_roomCL2[wc2_] = flushDenorm(mono + t2 * fb2); wc2_ = (wc2_ + 1u) % kRoomC2;
            float t3 = s_roomCL3[wc3_]; s_roomCL3[wc3_] = flushDenorm(mono + t3 * fb3); wc3_ = (wc3_ + 1u) % kRoomC3;
            float sumL = (t0 + t1 + t2 + t3) * 0.25f;

            float apIn1 = sumL, apOut1 = s_roomApL1[wap1_] - apG * apIn1;
            s_roomApL1[wap1_] = apIn1 + apG * apOut1; wap1_ = (wap1_ + 1u) % kRoomAp1;
            float apIn2 = apOut1, apOut2 = s_roomApL2[wap2_] - apG * apIn2;
            s_roomApL2[wap2_] = apIn2 + apG * apOut2; wap2_ = (wap2_ + 1u) % kRoomAp2;
            float wetL = apOut2;

            float d0 = s_roomCR0[wcr0_]; s_roomCR0[wcr0_] = flushDenorm(mono + d0 * fbr0); wcr0_ = (wcr0_ + 1u) % kRoomCR0;
            float d1 = s_roomCR1[wcr1_]; s_roomCR1[wcr1_] = flushDenorm(mono + d1 * fbr1); wcr1_ = (wcr1_ + 1u) % kRoomCR1;
            float d2 = s_roomCR2[wcr2_]; s_roomCR2[wcr2_] = flushDenorm(mono + d2 * fbr2); wcr2_ = (wcr2_ + 1u) % kRoomCR2;
            float d3 = s_roomCR3[wcr3_]; s_roomCR3[wcr3_] = flushDenorm(mono + d3 * fbr3); wcr3_ = (wcr3_ + 1u) % kRoomCR3;
            float sumR = (d0 + d1 + d2 + d3) * 0.25f;

            float apInR1 = sumR, apOutR1 = s_roomApR1[wapr1_] - apG * apInR1;
            s_roomApR1[wapr1_] = apInR1 + apG * apOutR1; wapr1_ = (wapr1_ + 1u) % kRoomApR1;
            float apInR2 = apOutR1, apOutR2 = s_roomApR2[wapr2_] - apG * apInR2;
            s_roomApR2[wapr2_] = apInR2 + apG * apOutR2; wapr2_ = (wapr2_ + 1u) % kRoomApR2;
            float wetR = apOutR2;

            L[i] = fxLerp(L[i], L[i] * 0.6f + wetL, amt);
            R[i] = fxLerp(R[i], R[i] * 0.6f + wetR, amt);
        }
    }
};

// 11 SRAMP — slice read speed ramps up within each step, read from the ring.
// V2 L2978-2985. FSR = accel amount.
class FxUpSramp : public Effect {
    uint32_t lastGstep_ = 0xFFFFFFFFu;
    float rd_ = 0.f;
    void onEngage(const FxCtx&) override { lastGstep_ = 0xFFFFFFFFu; rd_ = 0.f; }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        uint32_t slice = (uint32_t)(c.step_samples * 0.5f);
        if (slice < 480u) slice = 480u;
        if (lastGstep_ != c.gstep) { lastGstep_ = c.gstep; rd_ = 0.f; }
        for (size_t i = 0; i < n; i++) {
            float progress = c.step_phase + (float)i / c.step_samples;
            float spd = 1.f + c.fsr * 1.5f * progress;
            rd_ += spd; if (rd_ >= (float)slice) rd_ -= (float)slice;
            float back = (float)slice - rd_ + (float)(n - 1u - i);
            if (back < 0.f) back = 0.f;
            float wl = fxRingRead(c.ringL, c.ring_n, c.ring_w, back);
            float wr = fxRingRead(c.ringR, c.ring_n, c.ring_w, back);
            L[i] = fxLerp(L[i], wl, amt);
            R[i] = fxLerp(R[i], wr, amt);
        }
    }
};

// ============================================================================
// tables
// ============================================================================
static FxUpScat   s_scat;
static FxUpRept   s_rept;
static FxUpBall   s_ball;
static FxUpGate8  s_gate8;
static FxUpGate16 s_gate16;
static FxUpTgate  s_tgate;
static FxUpStab   s_stab;
static FxUpFreez  s_freez;
static FxUpPong   s_pong;
static FxUpHaas   s_haas;
static FxUpRoom   s_room;
static FxUpSramp  s_sramp;

Effect* const FX_UP_TABLE[FX_PER_DIR] = {
    &s_scat, &s_rept, &s_ball, &s_gate8, &s_gate16, &s_tgate,
    &s_stab, &s_freez, &s_pong, &s_haas, &s_room, &s_sramp,
};

const FxInfo FX_UP_INFO[FX_PER_DIR] = {
    { "SCAT",  FXD_UP, true,  false },
    { "REPT",  FXD_UP, true,  false },
    { "BALL",  FXD_UP, false, false },
    { "GATE8", FXD_UP, true,  false },
    { "GAT16", FXD_UP, true,  false },
    { "TGATE", FXD_UP, true,  false },
    { "STAB",  FXD_UP, true,  false },
    { "FREEZ", FXD_UP, false, false },
    { "PONG",  FXD_UP, true,  false },
    { "HAAS",  FXD_UP, false, false },
    { "ROOM",  FXD_UP, false, false },
    { "SRAMP", FXD_UP, true,  false },
};
