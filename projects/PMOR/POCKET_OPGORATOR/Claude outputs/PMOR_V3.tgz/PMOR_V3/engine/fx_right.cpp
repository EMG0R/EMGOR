// fx_right.cpp — FXD_RIGHT family: modulation (12 pads).
// Ported from PMOR_V2.cpp per research/v2-audit.md §3 (line refs in each class).
// LFO-type effects (FSR = depth/amount, accel X = speed via fxLfoHz()) keep their
// phase accumulator running continuously: onEngage restarts it (state reset lives
// in onEngage per the host contract), onRelease never touches it, so the fade-out
// tail never jumps the LFO phase.
#include <string.h>
#include "fx_internal.h"
#include "engine_util.h"

static const float kTwoPi = 6.283185307f;

// 0 CHOR — full-mix feedback chorus, +-740-sample sweep. V2 L2542-2562.
// Defect fix: V2 let feedback run to 0.97 ("scream zone", can run away) — capped
// at 0.85 here per the family brief.
static const uint32_t kChorN = 4096u;                                 // power of 2
static float SDRAM_BSS s_chorL[kChorN];
static float SDRAM_BSS s_chorR[kChorN];
class FxRChor : public Effect {
    float lfo_ = 0.f;
    uint32_t w_ = 0;
    void init() override { memset(s_chorL, 0, sizeof(s_chorL)); memset(s_chorR, 0, sizeof(s_chorR)); w_ = 0; }
    void onEngage(const FxCtx&) override { lfo_ = 0.f; }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        for (size_t i = 0; i < n; i++) {
            lfo_ += 0.35f / SR; if (lfo_ >= 1.f) lfo_ -= 1.f;
            float depth = 0.45f + 0.55f * c.fsr;
            float lfo2 = lfo_ + 0.25f; if (lfo2 >= 1.f) lfo2 -= 1.f;
            float tapL = 960.f + 740.f * depth * sinf(lfo_ * kTwoPi);
            float tapR = 960.f + 740.f * depth * sinf(lfo2 * kTwoPi);
            uint32_t tiL = (uint32_t)tapL; float frL = tapL - (float)tiL;
            uint32_t tiR = (uint32_t)tapR; float frR = tapR - (float)tiR;
            float a0 = s_chorL[(w_ - tiL) & (kChorN - 1u)], a1 = s_chorL[(w_ - tiL - 1u) & (kChorN - 1u)];
            float b0 = s_chorR[(w_ - tiR) & (kChorN - 1u)], b1 = s_chorR[(w_ - tiR - 1u) & (kChorN - 1u)];
            float wxL = a0 + (a1 - a0) * frL;
            float wxR = b0 + (b1 - b0) * frR;
            float fb = 0.55f + 0.30f * c.fsr; if (fb > 0.85f) fb = 0.85f;     // capped, no runaway
            s_chorL[w_ & (kChorN - 1u)] = L[i] + wxL * fb;
            s_chorR[w_ & (kChorN - 1u)] = R[i] + wxR * fb;
            w_++;
            float wetL = L[i] * 0.5f + wxL * 0.9f;
            float wetR = R[i] * 0.5f + wxR * 0.9f;
            L[i] = fxLerp(L[i], wetL, amt);
            R[i] = fxLerp(R[i], wetR, amt);
        }
    }
};

// 1 FLANG — jet flanger, fast/short biased by FSR. V2 L2624-2639.
static const uint32_t kFlangN = 1024u;                                 // power of 2
static float SDRAM_BSS s_flangL[kFlangN];
static float SDRAM_BSS s_flangR[kFlangN];
class FxRFlang : public Effect {
    uint16_t w_ = 0;
    float phase_ = 0.f;
    void init() override { memset(s_flangL, 0, sizeof(s_flangL)); memset(s_flangR, 0, sizeof(s_flangR)); w_ = 0; }
    void onEngage(const FxCtx&) override { phase_ = 0.f; }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        for (size_t i = 0; i < n; i++) {
            float ctr = 6.f - 5.4f * c.fsr;
            float rate = 0.15f + 6.f * (c.fsr * c.fsr);
            phase_ += rate / SR; if (phase_ >= 1.f) phase_ -= 1.f;
            float lfo = 0.5f - 0.5f * cosf(phase_ * kTwoPi);
            float dms = (ctr + (0.5f + 4.5f * c.fsr) * lfo) * 48.f;
            float inL = L[i], inR = R[i];
            float rd = (float)w_ - dms; while (rd < 0.f) rd += (float)kFlangN;
            int ri = (int)rd; float fr = rd - ri;
            float aL = s_flangL[ri & (kFlangN - 1)], bL = s_flangL[(ri + 1) & (kFlangN - 1)];
            float aR = s_flangR[ri & (kFlangN - 1)], bR = s_flangR[(ri + 1) & (kFlangN - 1)];
            float wetL = aL + (bL - aL) * fr, wetR = aR + (bR - aR) * fr;
            s_flangL[w_ & (kFlangN - 1)] = inL + wetL * 0.7f;
            s_flangR[w_ & (kFlangN - 1)] = inR + wetR * 0.7f;
            w_ = (w_ + 1u) & (kFlangN - 1u);
            float outL = inL * 0.5f + wetL, outR = inR * 0.5f + wetR;
            L[i] = fxLerp(inL, outL, amt);
            R[i] = fxLerp(inR, outR, amt);
        }
    }
};

// 2 PHASE — 4-stage first-order allpass phaser. V2 L2783-2791. LFO rule:
// FSR = depth, accel X = speed via fxLfoHz().
class FxRPhase : public Effect {
    float apL_[4] = {}, apR_[4] = {};
    float phase_ = 0.f;
    void onEngage(const FxCtx&) override { phase_ = 0.f; apL_[0] = apL_[1] = apL_[2] = apL_[3] = 0.f; apR_[0] = apR_[1] = apR_[2] = apR_[3] = 0.f; }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        float hz = fxLfoHz(c.accel_x, 0.05f, 2.f);
        float depth = 0.15f + 0.55f * c.fsr;
        for (size_t i = 0; i < n; i++) {
            phase_ += hz / SR; if (phase_ >= 1.f) phase_ -= 1.f;
            float g = 0.1f + depth * (0.5f - 0.5f * cosf(phase_ * kTwoPi));
            float xL = L[i], xR = R[i];
            for (int k = 0; k < 4; k++) {
                float yL = -g * xL + apL_[k]; apL_[k] = xL + g * yL; xL = yL;
                float yR = -g * xR + apR_[k]; apR_[k] = xR + g * yR; xR = yR;
            }
            float wetL = L[i] * 0.5f + xL * 0.5f;
            float wetR = R[i] * 0.5f + xR * 0.5f;
            L[i] = fxLerp(L[i], wetL, amt);
            R[i] = fxLerp(R[i], wetR, amt);
        }
    }
};

// 3 TREM — sine tremolo. LFO rule: FSR = depth, accel X = speed.
class FxRTrem : public Effect {
    float phase_ = 0.f;
    void onEngage(const FxCtx&) override { phase_ = 0.f; }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        float hz = fxLfoHz(c.accel_x, 0.5f, 10.f);
        float depth = 0.3f + 0.65f * c.fsr;
        for (size_t i = 0; i < n; i++) {
            phase_ += hz / SR; if (phase_ >= 1.f) phase_ -= 1.f;
            float g = 1.f - depth * 0.5f * (1.f - cosf(phase_ * kTwoPi));
            L[i] = fxLerp(L[i], L[i] * g, amt);
            R[i] = fxLerp(R[i], R[i] * g, amt);
        }
    }
};

// 4 PAN — hard parabolic autopan. V2 L2565-2571. LFO rule: FSR = depth, accel X
// = speed. Defect fix: V2's x1.4 makeup gain (could clip pre-tanh) is removed.
class FxRPan : public Effect {
    float phase_ = 0.f;
    void onEngage(const FxCtx&) override { phase_ = 0.f; }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        float hz = fxLfoHz(c.accel_x, 0.5f, 8.f);
        float depth = 0.4f + 0.6f * c.fsr;
        for (size_t i = 0; i < n; i++) {
            phase_ += hz / SR; if (phase_ >= 1.f) phase_ -= 1.f;
            float px = phase_ * 2.f - 1.f;
            float ps = 4.f * px * (1.f - fabsf(px));                  // -1..1 parabolic "sine"
            float gL = 1.f - depth * 0.5f * (1.f - ps);
            float gR = 1.f - depth * 0.5f * (1.f + ps);
            L[i] = fxLerp(L[i], L[i] * gL, amt);
            R[i] = fxLerp(R[i], R[i] * gR, amt);
        }
    }
};

// 5 PLFO (PANLFO) — new: slow, smooth equal-power sine pan, 0.1-4 Hz. LFO rule:
// FSR = depth, accel X = speed.
class FxRPanLfo : public Effect {
    float phase_ = 0.f;
    void onEngage(const FxCtx&) override { phase_ = 0.f; }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        float hz = fxLfoHz(c.accel_x, 0.1f, 4.f);
        float depth = 0.3f + 0.7f * c.fsr;
        for (size_t i = 0; i < n; i++) {
            phase_ += hz / SR; if (phase_ >= 1.f) phase_ -= 1.f;
            float s = sinf(phase_ * kTwoPi) * depth;                  // -depth..depth
            float ang = (s * 0.5f + 0.5f) * 1.5707963f;               // 0..pi/2
            float gL = cosf(ang) * 1.4142136f;                        // equal-power, 0 dB centre
            float gR = sinf(ang) * 1.4142136f;
            L[i] = fxLerp(L[i], L[i] * gL, amt);
            R[i] = fxLerp(R[i], R[i] * gR, amt);
        }
    }
};

// 6 VIBRA — delay-line vibrato at 5.5 Hz. V2 L2818-2826. Defect fix: V2
// collapsed L/R to mono; this keeps independent stereo delay lines and reads.
static const uint32_t kVibN = 1024u;                                   // power of 2
static float SDRAM_BSS s_vibL[kVibN];
static float SDRAM_BSS s_vibR[kVibN];
class FxRVibra : public Effect {
    uint16_t w_ = 0;
    float phase_ = 0.f;
    void init() override { memset(s_vibL, 0, sizeof(s_vibL)); memset(s_vibR, 0, sizeof(s_vibR)); w_ = 0; }
    void onEngage(const FxCtx&) override { phase_ = 0.f; }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        for (size_t i = 0; i < n; i++) {
            s_vibL[w_] = L[i]; s_vibR[w_] = R[i];
            phase_ += 5.5f / SR; if (phase_ >= 1.f) phase_ -= 1.f;
            float dms = 12.f + (4.f + c.fsr * 22.f) * (0.5f - 0.5f * cosf(phase_ * kTwoPi));
            float rd = (float)w_ - dms; while (rd < 0.f) rd += (float)kVibN;
            int ri = (int)rd; float fr = rd - ri;
            float aL = s_vibL[ri & (kVibN - 1)], bL = s_vibL[(ri + 1) & (kVibN - 1)];
            float aR = s_vibR[ri & (kVibN - 1)], bR = s_vibR[(ri + 1) & (kVibN - 1)];
            w_ = (w_ + 1u) & (kVibN - 1u);
            float wetL = aL + (bL - aL) * fr, wetR = aR + (bR - aR) * fr;
            L[i] = fxLerp(L[i], wetL, amt);
            R[i] = fxLerp(R[i], wetR, amt);
        }
    }
};

// 7 DIMEN — Dimension-D style dual-tap chorus (two read taps 90 degrees apart
// out of one mono capture, keeps stereo width). V2 L2827-2838.
static const uint32_t kDimN = 1024u;                                   // power of 2
static float SDRAM_BSS s_dimBuf[kDimN];
class FxRDimen : public Effect {
    uint16_t w_ = 0;
    float phase_ = 0.f;
    void init() override { memset(s_dimBuf, 0, sizeof(s_dimBuf)); w_ = 0; }
    void onEngage(const FxCtx&) override { phase_ = 0.f; }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        for (size_t i = 0; i < n; i++) {
            float m = (L[i] + R[i]) * 0.5f;
            s_dimBuf[w_] = m;
            phase_ += 0.6f / SR; if (phase_ >= 1.f) phase_ -= 1.f;
            float l1 = 0.5f - 0.5f * cosf(phase_ * kTwoPi);
            float ph2 = phase_ + 0.25f; if (ph2 >= 1.f) ph2 -= 1.f;
            float l2 = 0.5f - 0.5f * cosf(ph2 * kTwoPi);
            float d1 = 14.f + (2.f + c.fsr * 14.f) * l1;
            float d2 = 14.f + (2.f + c.fsr * 14.f) * l2;
            float r1 = (float)w_ - d1; while (r1 < 0.f) r1 += (float)kDimN;
            float r2 = (float)w_ - d2; while (r2 < 0.f) r2 += (float)kDimN;
            int i1 = (int)r1; float f1 = r1 - i1;
            int i2 = (int)r2; float f2 = r2 - i2;
            float w1 = s_dimBuf[i1 & (kDimN - 1)] + (s_dimBuf[(i1 + 1) & (kDimN - 1)] - s_dimBuf[i1 & (kDimN - 1)]) * f1;
            float w2 = s_dimBuf[i2 & (kDimN - 1)] + (s_dimBuf[(i2 + 1) & (kDimN - 1)] - s_dimBuf[i2 & (kDimN - 1)]) * f2;
            w_ = (w_ + 1u) & (kDimN - 1u);
            float outL = L[i] * 0.6f + w1 * 0.7f;
            float outR = R[i] * 0.6f + w2 * 0.7f;
            L[i] = fxLerp(L[i], outL, amt);
            R[i] = fxLerp(R[i], outR, amt);
        }
    }
};

// 8 WAH — envelope-follower SVF wah, 300->5500 Hz. V2 L2792-2801 ("strong").
class FxRWah : public Effect {
    float waf_ = 0.f, wab_ = 0.f, wafR_ = 0.f, wabR_ = 0.f, wenv_ = 0.f;
    void onEngage(const FxCtx&) override { waf_ = wab_ = wafR_ = wabR_ = wenv_ = 0.f; }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        for (size_t i = 0; i < n; i++) {
            float in = (L[i] + R[i]) * 0.5f, a = fabsf(in);
            wenv_ += (a - wenv_) * ((a > wenv_) ? 0.05f : 0.002f);
            float fc = 300.f + (wenv_ * (2.f + c.fsr * 6.f)) * 3000.f; if (fc > 5500.f) fc = 5500.f;
            float f = 2.f * sinf(3.14159265f * fc / SR), q = 0.30f;
            waf_ += f * (L[i] - waf_ - q * wab_); wab_ += f * waf_;
            wafR_ += f * (R[i] - wafR_ - q * wabR_); wabR_ += f * wafR_;
            float outL = L[i] * 0.3f + wab_ * 1.4f;
            float outR = R[i] * 0.3f + wabR_ * 1.4f;
            L[i] = fxLerp(L[i], outL, amt);
            R[i] = fxLerp(R[i], outR, amt);
        }
    }
};

// 9 SIREN — sine siren 180->1080 Hz driven by ctx.lidar, FSR = wobble + level.
// V2 L2848-2855 ("strong", spec keeps as the theremin).
// SIREN / theremin. Lidar -> pitch, TWO OCTAVES over an ~18 cm hand window (that
// window used to give ~0.75 oct), capped outside it; per-sample portamento so it
// glides instead of stepping; slow vibrato that deepens with the FSR; a sine with a
// touch of 2nd harmonic + a sub octave so it sings instead of buzzing; stereo drift.
class FxRSiren : public Effect {
    float ph_ = 0.f, sub_ = 0.f, vib_ = 0.f, pan_ = 0.f;
    float fCur_ = 0.f;                       // glided frequency (Hz)
    float env_  = 0.f;                       // level ramp so it fades in, never pops
    void onEngage(const FxCtx& c) override {
        ph_ = 0.f; sub_ = 0.f; vib_ = 0.f; pan_ = 0.f; env_ = 0.f;
        fCur_ = target(c.lidar);
    }
    static float target(float lid) {
        // lidar 0..1 (1 = touching). Useful hand window: 0.55..0.85 (~9..27 cm) -> 2 octaves.
        float x = (lid - 0.55f) * (1.f / 0.30f);
        if (x < 0.f) x = 0.f; if (x > 1.f) x = 1.f;
        return 220.f * powf(2.f, x * 2.f);                     // A3 .. A5
    }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        const float ft   = target(c.lidar);
        const float glide = 1.f - expf(-1.f / (0.035f * SR));   // ~35 ms portamento
        const float lvl  = 0.30f + c.fsr * 0.45f;
        for (size_t i = 0; i < n; i++) {
            fCur_ += (ft - fCur_) * glide;
            vib_ += 5.5f / SR; if (vib_ >= 1.f) vib_ -= 1.f;
            float f = fCur_ * (1.f + sinf(vib_ * kTwoPi) * (0.004f + 0.025f * c.fsr));
            ph_  += f / SR;        if (ph_  >= 1.f) ph_  -= 1.f;
            sub_ += 0.5f * f / SR; if (sub_ >= 1.f) sub_ -= 1.f;
            float s1 = sinf(ph_ * kTwoPi);
            float s2 = sinf(2.f * ph_ * kTwoPi);
            float ss = sinf(sub_ * kTwoPi);
            float t  = fxTanh((s1 + 0.25f * s2 + 0.35f * ss) * 1.6f);
            env_ += (1.f - env_) * 0.0008f;
            pan_ += 0.23f / SR; if (pan_ >= 1.f) pan_ -= 1.f;
            float p = 0.5f + 0.35f * sinf(pan_ * kTwoPi);
            float v = t * lvl * env_;
            float outL = L[i] * 0.7f + v * (1.f - p);
            float outR = R[i] * 0.7f + v * p;
            L[i] = fxLerp(L[i], outL, amt);
            R[i] = fxLerp(R[i], outR, amt);
        }
    }
};

// 10 WOW — vinyl wow/flutter + crackle (V2 L2706-2718, amplitude-only) plus a
// real pitch wow from a modulated short delay line (defect fix — V2's WOW was
// amplitude-only, no actual pitch wobble).
static const uint32_t kWowN = 256u;                                    // power of 2
class FxRWow : public Effect {
    float bufL_[kWowN] = {};
    float bufR_[kWowN] = {};
    uint16_t w_ = 0;
    float wphs_ = 0.f, wphf_ = 0.f, wd_ = 0.f;
    uint32_t rng_ = 0x1234ABCDu;
    void onEngage(const FxCtx&) override { wphs_ = wphf_ = wd_ = 0.f; }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        for (size_t i = 0; i < n; i++) {
            bufL_[w_] = L[i]; bufR_[w_] = R[i];
            wphs_ += 0.7f / SR; if (wphs_ >= 1.f) wphs_ -= 1.f;
            wphf_ += 8.f / SR; if (wphf_ >= 1.f) wphf_ -= 1.f;
            float mod = (sinf(wphs_ * kTwoPi) * 0.6f + sinf(wphf_ * kTwoPi) * 0.4f) * c.fsr * 0.4f;
            wd_ += (mod - wd_) * 0.5f;
            float dms = 6.f + mod * 40.f; if (dms < 0.f) dms = 0.f; if (dms > (float)kWowN - 4.f) dms = (float)kWowN - 4.f;
            float rd = (float)w_ - dms; while (rd < 0.f) rd += (float)kWowN;
            int ri = (int)rd; float fr = rd - ri;
            float pL = bufL_[ri & (kWowN - 1)] + (bufL_[(ri + 1) & (kWowN - 1)] - bufL_[ri & (kWowN - 1)]) * fr;
            float pR = bufR_[ri & (kWowN - 1)] + (bufR_[(ri + 1) & (kWowN - 1)] - bufR_[ri & (kWowN - 1)]) * fr;
            w_ = (w_ + 1u) & (kWowN - 1u);
            float crk = lcg01(rng_) * 2.f - 1.f;
            crk = (fabsf(crk) > 0.985f) ? crk * c.fsr * 0.5f : 0.f;
            float outL = pL * (1.f + wd_) + crk;
            float outR = pR * (1.f + wd_) + crk;
            L[i] = fxLerp(L[i], outL, amt);
            R[i] = fxLerp(R[i], outR, amt);
        }
    }
};

// 11 SHMOD — random sample-and-hold amplitude modulation. V2 L3011-3017.
// Trigger rate comes from accel X via fxLfoHz(); FSR = depth.
class FxRShmod : public Effect {
    float shval_ = 0.f, shlp_ = 0.f;
    float phase_ = 0.f;
    uint32_t rng_ = 0x9E3779B9u;
    void onEngage(const FxCtx&) override { shval_ = shlp_ = 0.f; phase_ = 0.f; }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        float hz = fxLfoHz(c.accel_x, 2.f, 60.f);
        float depth = 0.3f + 0.6f * c.fsr;
        for (size_t i = 0; i < n; i++) {
            phase_ += hz / SR;
            if (phase_ >= 1.f) { phase_ -= 1.f; shval_ = lcg01(rng_) * 2.f - 1.f; }
            shlp_ += 0.25f * (shval_ - shlp_);
            float mod = 1.f - depth * 0.5f * (1.f - shlp_);
            L[i] = fxLerp(L[i], L[i] * mod, amt);
            R[i] = fxLerp(R[i], R[i] * mod, amt);
        }
    }
};

// ============================================================================
// tables
// ============================================================================
static FxRChor    s_chor;
static FxRFlang   s_flang;
static FxRPhase   s_phase;
static FxRTrem    s_trem;
static FxRPan     s_pan;
static FxRPanLfo  s_panlfo;
static FxRVibra   s_vibra;
static FxRDimen   s_dimen;
static FxRWah     s_wah;
static FxRSiren   s_siren;
static FxRWow     s_wow;
static FxRShmod   s_shmod;

Effect* const FX_RIGHT_TABLE[FX_PER_DIR] = {
    &s_chor, &s_flang, &s_phase, &s_trem, &s_pan, &s_panlfo,
    &s_vibra, &s_dimen, &s_wah, &s_siren, &s_wow, &s_shmod,
};

const FxInfo FX_RIGHT_INFO[FX_PER_DIR] = {
    { "CHOR",  FXD_RIGHT, false, false },
    { "FLANG", FXD_RIGHT, false, false },
    { "PHASE", FXD_RIGHT, false, true  },
    { "TREM",  FXD_RIGHT, false, true  },
    { "PAN",   FXD_RIGHT, false, true  },
    { "PLFO",  FXD_RIGHT, false, true  },
    { "VIBRA", FXD_RIGHT, false, false },
    { "DIMEN", FXD_RIGHT, false, false },
    { "WAH",   FXD_RIGHT, false, false },
    { "SIREN", FXD_RIGHT, false, false },
    { "WOW",   FXD_RIGHT, false, false },
    { "SHMOD", FXD_RIGHT, false, true  },
};
