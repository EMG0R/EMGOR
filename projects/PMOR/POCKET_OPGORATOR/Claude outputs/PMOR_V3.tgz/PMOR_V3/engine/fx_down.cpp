// fx_down.cpp — FXD_DOWN family: distortion / ring mod (12 pads).
// Also home of the shared stateless distortion set (fxDistSample) used by
// FLCLP here and by the drum/sampler performance-page DOWN throw.
// Ported from PMOR_V2.cpp per research/v2-audit.md §3 (line refs in each class).
#include <string.h>
#include "fx_internal.h"
#include "engine_util.h"
#include "output.h"

static const float kTwoPi = 6.283185307f;

// ============================================================================
// shared distortion set — stateless, drive 1..20 (caller maps FSR -> drive)
// ============================================================================

// DIST_FL needs a soft-knee clipper whose knee position tracks drive; a 32-row
// table (built once, lazily) avoids log10f/powf in the audio-rate call.
static FlClip s_flTable[32];
static bool   s_flTableReady = false;
static void ensureFlTable() {
    if (s_flTableReady) return;
    s_flTableReady = true;
    for (int i = 0; i < 32; i++) {
        float drive = 1.f + (19.f * (float)i) / 31.f;                 // 1..20
        float thresh_db = -4.4f - 20.f * log10f(drive);
        thresh_db = clampf(thresh_db, -40.f, 0.f);
        flclipSet(s_flTable[i], thresh_db, 0.f);
    }
}
static inline int flTableIndex(float drive) {
    int idx = (int)((drive - 1.f) * (31.f / 19.f) + 0.5f);
    if (idx < 0) idx = 0;
    if (idx > 31) idx = 31;
    return idx;
}

float fxDistSample(DistAlgo a, float x, float drive) {
    switch (a) {
        case DIST_TANH_ASYM: {                                        // V2 L3328-3331
            float dc = fxTanh(0.08f * drive) * 0.62f;
            return fxTanh((x + 0.08f) * drive) * 0.62f - dc;
        }
        case DIST_FOLD:                                               // V2 L2642-2645
            return sinf(x * drive * 1.5707963f) * 0.8f;
        case DIST_FUZZ: {                                              // V2 L2965-2970
            float y = x * drive + 0.15f;
            y = (y > 0.f) ? (1.f - fastExp(-y)) : (-1.f + fastExp(y));
            return y * 0.6f;
        }
        case DIST_WARM:                                                // softer-knee tanh
            return fxTanh(x * drive * 0.6f) * 0.9f + 0.1f * x;
        case DIST_FL: {
            ensureFlTable();
            return flclipSample(s_flTable[flTableIndex(drive)], x);
        }
        case DIST_CRUSH: {                                             // bit quantise only
            float bits = clampf(16.f - (drive - 1.f) * (14.f / 19.f), 2.f, 16.f);
            float q = fastPow2(bits);
            return floorf(x * q + 0.5f) / q;
        }
        default: return x;
    }
}

extern const char* const DIST_NAMES[DIST_COUNT] = { "TANH", "FOLD", "FUZZ", "WARM", "FL", "CRUSH" };

// ============================================================================
// effects
// ============================================================================

// 0 DIST — asymmetric tanh with DC bias/compensation. V2 L3328-3331.
class FxDownDist : public Effect {
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        float g = 4.f + c.fsr * 10.f;                                  // 4..14
        for (size_t i = 0; i < n; i++) {
            L[i] = fxLerp(L[i], fxDistSample(DIST_TANH_ASYM, L[i], g), amt);
            R[i] = fxLerp(R[i], fxDistSample(DIST_TANH_ASYM, R[i], g), amt);
        }
    }
};

// 1 FOLD — sine wavefolder. V2 L2642-2645.
class FxDownFold : public Effect {
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        float g = 1.f + c.fsr * 7.f;                                   // 1..8
        for (size_t i = 0; i < n; i++) {
            L[i] = fxLerp(L[i], fxDistSample(DIST_FOLD, L[i], g), amt);
            R[i] = fxLerp(R[i], fxDistSample(DIST_FOLD, R[i], g), amt);
        }
    }
};

// 2 FUZZ — exponential clip with bias. V2 L2965-2970.
class FxDownFuzz : public Effect {
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        float g = 2.f + c.fsr * 18.f;                                  // 2..20
        for (size_t i = 0; i < n; i++) {
            L[i] = fxLerp(L[i], fxDistSample(DIST_FUZZ, L[i], g), amt);
            R[i] = fxLerp(R[i], fxDistSample(DIST_FUZZ, R[i], g), amt);
        }
    }
};

// 3 FLCLP — Fruity-style parabolic-knee clip via the shared FlClip table.
class FxDownFlClip : public Effect {
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        float drive = 1.f + c.fsr * 19.f;                              // 1..20
        for (size_t i = 0; i < n; i++) {
            L[i] = fxLerp(L[i], fxDistSample(DIST_FL, L[i], drive), amt);
            R[i] = fxLerp(R[i], fxDistSample(DIST_FL, R[i], drive), amt);
        }
    }
};

// 4 CRUSH — sample & hold rate reduction + amplitude quantise. V2 L2245-2246 + L3350-3353.
class FxDownCrush : public Effect {
    float heldL_ = 0.f, heldR_ = 0.f;
    uint32_t ctr_ = 0;
    void onEngage(const FxCtx&) override { heldL_ = heldR_ = 0.f; ctr_ = 0; }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        uint32_t period = 4u + (uint32_t)(c.fsr * 20.f);
        float qs = 24.f - c.fsr * 18.f;
        for (size_t i = 0; i < n; i++) {
            if (ctr_ == 0) { heldL_ = L[i]; heldR_ = R[i]; }
            ctr_ = (ctr_ + 1u) % period;
            float wL = (float)(int)(heldL_ * qs) / qs;
            float wR = (float)(int)(heldR_ * qs) / qs;
            L[i] = fxLerp(L[i], wL, amt);
            R[i] = fxLerp(R[i], wR, amt);
        }
    }
};

// 5 DSTRY — sample & hold + power-of-2 bit quantise. V2 L2908-2913.
class FxDownDstry : public Effect {
    float heldL_ = 0.f, heldR_ = 0.f;
    uint32_t ctr_ = 0;
    void onEngage(const FxCtx&) override { heldL_ = heldR_ = 0.f; ctr_ = 0; }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        uint32_t hold = 1u + (uint32_t)(c.fsr * 30.f);
        float q = fastPow2(8.f - c.fsr * 7.f);
        for (size_t i = 0; i < n; i++) {
            if (ctr_ == 0) { heldL_ = L[i]; heldR_ = R[i]; }
            ctr_ = (ctr_ + 1u) % hold;
            float wL = floorf(heldL_ * q) / q;
            float wR = floorf(heldR_ * q) / q;
            L[i] = fxLerp(L[i], wL, amt);
            R[i] = fxLerp(R[i], wR, amt);
        }
    }
};

// 6 RING — ring mod 40Hz..1.5kHz exp, lidar wobbles the carrier ±30%. V2 L3317-3326.
class FxDownRing : public Effect {
    float phase_ = 0.f;
    void onEngage(const FxCtx&) override { phase_ = 0.f; }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        float fc = 40.f * fastExp(c.fsr * 3.624341f);                  // 40 * 37.5^fsr
        float wobHz = 0.07f * SR / (float)BLOCK;                       // keep wobble rate block-stable-ish
        (void)wobHz;
        for (size_t i = 0; i < n; i++) {
            float fcInst = fc * (1.f + 0.3f * c.lidar * sinf(phase_ * 0.07f));
            phase_ += fcInst / SR; if (phase_ >= 1.f) phase_ -= 1.f;
            float carrier = sinf(phase_ * kTwoPi);
            L[i] = fxLerp(L[i], L[i] * carrier, amt);
            R[i] = fxLerp(R[i], R[i] * carrier, amt);
        }
    }
};

// 7 RINGL — fixed 90Hz ring mod.
class FxDownRingL : public Effect {
    float phase_ = 0.f;
    void onEngage(const FxCtx&) override { phase_ = 0.f; }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        float depth = amt * (0.4f + 0.6f * c.fsr);
        for (size_t i = 0; i < n; i++) {
            phase_ += 90.f / SR; if (phase_ >= 1.f) phase_ -= 1.f;
            float carrier = sinf(phase_ * kTwoPi);
            L[i] = fxLerp(L[i], L[i] * carrier, depth);
            R[i] = fxLerp(R[i], R[i] * carrier, depth);
        }
    }
};

// 8 RINGH — fixed 360Hz ring mod.
class FxDownRingH : public Effect {
    float phase_ = 0.f;
    void onEngage(const FxCtx&) override { phase_ = 0.f; }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        float depth = amt * (0.4f + 0.6f * c.fsr);
        for (size_t i = 0; i < n; i++) {
            phase_ += 360.f / SR; if (phase_ >= 1.f) phase_ -= 1.f;
            float carrier = sinf(phase_ * kTwoPi);
            L[i] = fxLerp(L[i], L[i] * carrier, depth);
            R[i] = fxLerp(R[i], R[i] * carrier, depth);
        }
    }
};

// 9 OCT- — flip-flop octave-down (zero-cross divider), fuzz-octave character. V2 L2902-2907.
class FxDownOctDown : public Effect {
    bool prevL_ = false, prevR_ = false;
    float flipL_ = 1.f, flipR_ = 1.f;
    void onEngage(const FxCtx&) override { prevL_ = prevR_ = false; flipL_ = flipR_ = 1.f; }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        (void)c;
        for (size_t i = 0; i < n; i++) {
            bool sL = L[i] > 0.f;
            if (sL != prevL_) { prevL_ = sL; if (sL) flipL_ = -flipL_; }
            bool sR = R[i] > 0.f;
            if (sR != prevR_) { prevR_ = sR; if (sR) flipR_ = -flipR_; }
            float wL = fxTanh(fabsf(L[i]) * flipL_ * 1.3f);
            float wR = fxTanh(fabsf(R[i]) * flipR_ * 1.3f);
            L[i] = fxLerp(L[i], wL, amt);
            R[i] = fxLerp(R[i], wR, amt);
        }
    }
};

// 10 RADIO — bandpass + AM carrier + hiss. V2 L2994-3004.
class FxDownRadio : public Effect {
    float hpL_ = 0.f, lpL_ = 0.f, hpR_ = 0.f, lpR_ = 0.f, carrier_ = 0.f;
    uint32_t seed_ = 0xC0FFEEu;
    void onEngage(const FxCtx&) override { hpL_ = lpL_ = hpR_ = lpR_ = carrier_ = 0.f; }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        const float la = 0.35f, ha = 0.05f;
        float carHz = 60.f + c.fsr * 200.f;
        for (size_t i = 0; i < n; i++) {
            hpL_ += ha * (L[i] - hpL_); float bL = L[i] - hpL_; lpL_ += la * (bL - lpL_);
            hpR_ += ha * (R[i] - hpR_); float bR = R[i] - hpR_; lpR_ += la * (bR - lpR_);
            carrier_ += carHz / SR; if (carrier_ >= 1.f) carrier_ -= 1.f;
            float am = 0.6f + 0.4f * sinf(carrier_ * kTwoPi);
            float hiss = (lcg01(seed_) * 2.f - 1.f) * c.fsr * 0.15f;
            float wL = lpL_ * am * 1.6f + hiss;
            float wR = lpR_ * am * 1.6f + hiss;
            L[i] = fxLerp(L[i], wL, amt);
            R[i] = fxLerp(R[i], wR, amt);
        }
    }
};

// 11 PHONE — telephone bandpass + coarse quantise. V2 L2685-2693.
class FxDownPhone : public Effect {
    float hpL_ = 0.f, lpL_ = 0.f, hpR_ = 0.f, lpR_ = 0.f;
    void onEngage(const FxCtx&) override { hpL_ = lpL_ = hpR_ = lpR_ = 0.f; }
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        float la = 0.30f - c.fsr * 0.12f, ha = 0.04f + c.fsr * 0.04f;
        float q = 8.f - c.fsr * 5.f;
        for (size_t i = 0; i < n; i++) {
            hpL_ += ha * (L[i] - hpL_); float bL = L[i] - hpL_; lpL_ += la * (bL - lpL_);
            hpR_ += ha * (R[i] - hpR_); float bR = R[i] - hpR_; lpR_ += la * (bR - lpR_);
            float wL = (floorf(lpL_ * q) / q) * 1.4f;
            float wR = (floorf(lpR_ * q) / q) * 1.4f;
            L[i] = fxLerp(L[i], wL, amt);
            R[i] = fxLerp(R[i], wR, amt);
        }
    }
};

// ============================================================================
// tables
// ============================================================================
static FxDownDist    s_dist;
static FxDownFold    s_fold;
static FxDownFuzz    s_fuzz;
static FxDownFlClip  s_flclp;
static FxDownCrush   s_crush;
static FxDownDstry   s_dstry;
static FxDownRing    s_ring;
static FxDownRingL   s_ringl;
static FxDownRingH   s_ringh;
static FxDownOctDown s_octd;
static FxDownRadio   s_radio;
static FxDownPhone   s_phone;

Effect* const FX_DOWN_TABLE[FX_PER_DIR] = {
    &s_dist, &s_fold, &s_fuzz, &s_flclp, &s_crush, &s_dstry,
    &s_ring, &s_ringl, &s_ringh, &s_octd, &s_radio, &s_phone,
};

const FxInfo FX_DOWN_INFO[FX_PER_DIR] = {
    { "DIST",  FXD_DOWN, false, false },
    { "FOLD",  FXD_DOWN, false, false },
    { "FUZZ",  FXD_DOWN, false, false },
    { "FLCLP", FXD_DOWN, false, false },
    { "CRUSH", FXD_DOWN, false, false },
    { "DSTRY", FXD_DOWN, false, false },
    { "RING",  FXD_DOWN, false, false },
    { "RINGL", FXD_DOWN, false, false },
    { "RINGH", FXD_DOWN, false, false },
    { "OCT-",  FXD_DOWN, false, false },
    { "RADIO", FXD_DOWN, false, false },
    { "PHONE", FXD_DOWN, false, false },
};
