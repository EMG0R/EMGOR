// synth.cpp — polysynth engine: voice allocation/stealing, generative pan,
// performance macros, amp/filter/pitch envelopes, per-voice Chamberlin SVF,
// mixdown, and the editor's Param pages. Algorithm oscillator code lives in
// synth_algos.cpp (Voice model + character rolls in synth_private.h).
#include "synth_private.h"
#include "sequencer.h"
#include "scale.h"
#include "clock.h"
#include <string.h>

SynthState syn;
Voice      synVoices[SYN_VOICES];

extern const char* const SYN_ALGO_NAMES[ALG_COUNT] = {
    "THIEF", "FM", "WAVE", "PLUCK", "SUPER", "CZ", "FOLD", "ADD"
};

static uint32_t synRng          = 0xC0FFEE17u;
static uint32_t synNoteCounter  = 0;
static uint32_t synSlotCounter  = 0;
static OnePole  synPerfOctSmoo;   // block-rate smoothing of perf_octave, ~120ms

float synAlgoShadow = 0.f;        // ALGO param page's float shadow of syn.algo (PF_ENUM needs a float*)
static void synBuildPages();      // builds the 8x4 static ParamPage sets; forward-declared, defined below

// ---------------------------------------------------------------- helpers

// perf_env_macro (0..1) scales the amp ADSR times: 0 = x0.15 plucky with
// sustain forced toward 0.2, 1 = x6 ambient, 0.5 = the preset as authored.
static Adsr synScaledAmpEnv(const Adsr& base) {
    float m = clampf(syn.perf_env_macro, 0.f, 1.f);
    Adsr out = base;
    float scale, sus;
    if (m <= 0.5f) {
        float t = m * 2.f;
        scale = lerpf(0.15f, 1.f, t);
        sus   = lerpf(0.2f, base.s, t);
    } else {
        float t = (m - 0.5f) * 2.f;
        scale = lerpf(1.f, 6.f, t);
        sus   = base.s;
    }
    out.a = base.a * scale;
    out.d = base.d * scale;
    out.r = base.r * scale;
    out.s = sus;
    return out;
}

// poly==2 -> 0.25/0.75, poly==3 -> 0.15/0.50/0.85 by slot; poly==1 or >=4 ->
// generative width around a centre (>=4 also spreads the centres evenly).
static void synComputePan(Voice& v, int poly, int slotIdx, float width, float widthProb) {
    width = clampf(width, 0.f, 1.f);
    widthProb = clampf(widthProb, 0.f, 1.f);
    if (poly == 2) { v.pan = (slotIdx == 0) ? 0.25f : 0.75f; return; }
    if (poly == 3) { v.pan = (slotIdx == 0) ? 0.15f : ((slotIdx == 1) ? 0.50f : 0.85f); return; }
    float base = 0.5f;
    if (poly >= 4) {
        int denom = poly - 1; if (denom < 1) denom = 1;
        base = 0.5f - width * 0.5f + width * ((float)slotIdx / (float)denom);
    }
    if (lcg01(synRng) < widthProb) {
        float r = (lcg01(synRng) * 2.f - 1.f) * (width * 0.5f);
        v.pan = clampf(base + r, 0.f, 1.f);
    } else {
        v.pan = base;
    }
}

// finds a physical voice slot for a new note, stealing the oldest live note
// (fast ~20ms release, never a hard cut) if the polyphony cap is already met.
static int synAllocVoice(int poly) {
    int activeCount = 0;
    for (int i = 0; i < SYN_VOICES; i++)
        if (synVoices[i].ampEnv.stage != ADSR::IDLE && !synVoices[i].stolen) activeCount++;

    if (activeCount >= poly) {
        int oldest = -1; uint32_t oldestId = 0xFFFFFFFFu;
        for (int i = 0; i < SYN_VOICES; i++) {
            Voice& vv = synVoices[i];
            if (vv.ampEnv.stage != ADSR::IDLE && !vv.stolen && vv.note_id < oldestId) {
                oldestId = vv.note_id; oldest = i;
            }
        }
        if (oldest >= 0) {
            synVoices[oldest].stolen = true;
            float stealR = 1.f - fastExp(-3.f / (0.02f * SR));   // ~20ms release
            synVoices[oldest].ampEnv.r_coef = stealR;
            synVoices[oldest].ampEnv.stage = ADSR::REL;          // already non-idle (see loop above)
            if (synVoices[oldest].algo == ALG_THIEF) { synVoices[oldest].apart[4] = 0.f; synVoices[oldest].apart[5] = stealR; }
        }
    }

    for (int i = 0; i < SYN_VOICES; i++)
        if (synVoices[i].ampEnv.stage == ADSR::IDLE) return i;

    // fallback (shouldn't happen: SYN_VOICES > SYN_MAX_POLY): steal absolute oldest.
    int oldest = 0; uint32_t oldestId = 0xFFFFFFFFu;
    for (int i = 0; i < SYN_VOICES; i++)
        if (synVoices[i].note_id < oldestId) { oldestId = synVoices[i].note_id; oldest = i; }
    return oldest;
}

static void synTriggerNote(int degree, int octave, float vel, uint8_t pad, int32_t gate_samples) {
    if (octave < 0) octave = 0;
    if (octave > SYN_OCTAVES - 1) octave = SYN_OCTAVES - 1;
    float hz = scaleHz(degree, octave);
    uint8_t algo = syn.algo;
    const SynPreset& pr = syn.preset[algo];

    int poly = (int)clampf(seq.lane[ENG_SYNTH].polyphony, 1.f, (float)SYN_MAX_POLY);
    int slot = synAllocVoice(poly);
    Voice& v = synVoices[slot];

    // reset per-voice scratch but keep the SVF state clamp-safe (fresh note = fresh filter).
    v = Voice();
    v.algo = algo;
    v.pad = pad;
    v.note_hz = hz;
    v.note_id = ++synNoteCounter;
    v.gate_samples = gate_samples;
    (void)vel;   // velocity is reserved for a future amp-scale hook; amp uses the preset ADSR peak

    int slotIdx = (int)(synSlotCounter++ % (uint32_t)((poly < 1) ? 1 : poly));
    synComputePan(v, poly, slotIdx, pr.width, pr.width_prob);

    Adsr amp = synScaledAmpEnv(pr.amp);
    v.ampEnv.setTimes(amp.a, amp.d, amp.s, amp.r);
    v.ampEnv.gate(true);
    v.filtEnv.setTimes(pr.filt.a, pr.filt.d, pr.filt.s, pr.filt.r);
    v.filtEnv.gate(true);

    synAlgoNoteOn(v, pr, synRng);   // may set v.pitchGlideEnable (THIEF re-roll)

    // PITCH ENV: start `pitch_amt` semitones away and glide INTO the note over glide_in.
    // pitch_amt == 0 -> no glide at all (the default).
    float amtMul = fastPow2(clampf(pr.pitch_amt, -24.f, 24.f) * (1.f / 12.f));
    if (pr.glide_in > 1e-4f && v.pitchGlideEnable && fabsf(pr.pitch_amt) > 0.01f) {
        v.pitch_mul = amtMul; v.pitch_target = 1.f;
        v.pitch_rate = fabsf(1.f - amtMul) / (pr.glide_in * SR);
    } else {
        v.pitch_mul = 1.f; v.pitch_target = 1.f; v.pitch_rate = 0.f;
    }
}

// ---------------------------------------------------------------- lifecycle
void synthInit() {
    memset(&syn, 0, sizeof(syn));
    syn.volume = 1.f;
    syn.perf_env_macro = 0.5f;
    syn.perf_cutoff = 1.f;
    syn.master_prob = 0.5f;
    syn.algo = ALG_THIEF;

    for (int i = 0; i < SYN_VOICES; i++) synVoices[i] = Voice();
    memset(synKpBuf, 0, sizeof(synKpBuf));   // SDRAM is not zeroed at reset
    synBuildWavetables();
    synPerfOctSmoo.setMs(120.f, BLOCK_HZ);
    synPerfOctSmoo.set(0.f);

    // default presets — tuned so every algorithm sounds good immediately.
    SynPreset& thief = syn.preset[ALG_THIEF];
    thief.p[0] = 0.5f; thief.p[1] = 0.15f; thief.p[2] = 0.15f; thief.p[3] = 0.25f;
    thief.amp  = {0.010f, 0.60f, 0.70f, 0.90f};
    thief.cutoff = 2200.f; thief.resonance = 0.25f;
    thief.filt = {0.010f, 0.40f, 0.50f, 0.60f}; thief.filt_amt = 0.35f;
    thief.glide_in = 0.f; thief.glide_out = 0.f; thief.pitch_amt = 0.f;
    thief.width = 0.5f; thief.width_prob = 0.30f;

    SynPreset& fm = syn.preset[ALG_FM];
    fm.p[0] = 2.f; fm.p[1] = 0.5f; fm.p[2] = 0.25f; fm.p[3] = 0.15f;
    fm.amp = {0.005f, 0.30f, 0.40f, 0.50f};
    fm.cutoff = 4500.f; fm.resonance = 0.20f;
    fm.filt = {0.005f, 0.25f, 0.30f, 0.40f}; fm.filt_amt = 0.20f;
    fm.glide_in = 0.f; fm.glide_out = 0.f; fm.pitch_amt = 0.f;
    fm.width = 0.4f; fm.width_prob = 0.20f;

    SynPreset& wave = syn.preset[ALG_WAVE];
    wave.p[0] = 3.f; wave.p[1] = 0.3f; wave.p[2] = 0.3f; wave.p[3] = 0.4f;
    wave.amp = {0.020f, 0.50f, 0.60f, 0.80f};
    wave.cutoff = 3200.f; wave.resonance = 0.30f;
    wave.filt = {0.020f, 0.40f, 0.50f, 0.60f}; wave.filt_amt = 0.30f;
    wave.glide_in = 0.f; wave.glide_out = 0.f; wave.pitch_amt = 0.f;
    wave.width = 0.5f; wave.width_prob = 0.30f;

    SynPreset& pluck = syn.preset[ALG_PLUCK];
    pluck.p[0] = 0.4f; pluck.p[1] = 0.7f; pluck.p[2] = 0.3f; pluck.p[3] = 0.5f;
    pluck.amp = {0.001f, 0.30f, 0.0f, 0.20f};
    pluck.cutoff = 6500.f; pluck.resonance = 0.10f;
    pluck.filt = {0.001f, 0.20f, 0.0f, 0.15f}; pluck.filt_amt = 0.10f;
    pluck.glide_in = 0.f; pluck.glide_out = 0.f; pluck.pitch_amt = 0.f;
    pluck.width = 0.5f; pluck.width_prob = 0.40f;

    SynPreset& super = syn.preset[ALG_SUPER];
    super.p[0] = 0.5f; super.p[1] = 0.5f; super.p[2] = 0.6f; super.p[3] = 0.2f;
    super.amp = {0.010f, 0.40f, 0.80f, 0.60f};
    super.cutoff = 5000.f; super.resonance = 0.20f;
    super.filt = {0.010f, 0.30f, 0.60f, 0.40f}; super.filt_amt = 0.15f;
    super.glide_in = 0.f; super.glide_out = 0.f; super.pitch_amt = 0.f;
    super.width = 0.7f; super.width_prob = 0.50f;

    SynPreset& cz = syn.preset[ALG_CZ];
    cz.p[0] = 0.4f; cz.p[1] = 0.3f; cz.p[2] = 0.3f; cz.p[3] = 0.3f;
    cz.amp = {0.005f, 0.35f, 0.50f, 0.40f};
    cz.cutoff = 8000.f; cz.resonance = 0.15f;
    cz.filt = {0.005f, 0.30f, 0.40f, 0.30f}; cz.filt_amt = 0.20f;
    cz.glide_in = 0.f; cz.glide_out = 0.f; cz.pitch_amt = 0.f;
    cz.width = 0.4f; cz.width_prob = 0.25f;

    SynPreset& fold = syn.preset[ALG_FOLD];
    fold.p[0] = 0.4f; fold.p[1] = 0.5f; fold.p[2] = 0.3f; fold.p[3] = 0.5f;
    fold.amp = {0.020f, 0.50f, 0.70f, 0.70f};
    fold.cutoff = 7000.f; fold.resonance = 0.10f;
    fold.filt = {0.020f, 0.40f, 0.60f, 0.50f}; fold.filt_amt = 0.15f;
    fold.glide_in = 0.f; fold.glide_out = 0.f; fold.pitch_amt = 0.f;
    fold.width = 0.5f; fold.width_prob = 0.30f;

    SynPreset& add = syn.preset[ALG_ADD];
    add.p[0] = 0.f; add.p[1] = 0.5f; add.p[2] = 0.4f; add.p[3] = 0.1f;
    add.amp = {0.030f, 0.60f, 0.70f, 1.0f};
    add.cutoff = 9500.f; add.resonance = 0.05f;
    add.filt = {0.030f, 0.50f, 0.60f, 0.80f}; add.filt_amt = 0.10f;
    add.glide_in = 0.f; add.glide_out = 0.f; add.pitch_amt = 0.f;
    add.width = 0.6f; add.width_prob = 0.35f;

    synBuildPages();
}

// ---------------------------------------------------------------- CONTROL plane
void synthNoteOn(uint8_t pad, float vel) {
    int degree, octave;
    scalePadToNote(pad, degree, octave);
    synTriggerNote(degree, octave, vel, pad, -1);
}

void synthNoteOff(uint8_t pad) {
    for (int i = 0; i < SYN_VOICES; i++) {
        Voice& v = synVoices[i];
        if (v.pad == pad && v.gate_samples < 0 && v.ampEnv.stage != ADSR::IDLE && !v.stolen) {
            v.ampEnv.release();
            if (v.algo == ALG_THIEF) v.apart[4] = 0.f;                      // V2: envTarget = 0
            const SynPreset& pr = syn.preset[v.algo];
            if (pr.glide_out > 1e-4f && fabsf(pr.pitch_amt) > 0.01f) {   // glide OUT of the note to +-amt
                float amtMul = fastPow2(clampf(pr.pitch_amt, -24.f, 24.f) * (1.f / 12.f));
                v.pitch_target = amtMul;
                v.pitch_rate = fabsf(1.f - amtMul) / (pr.glide_out * SR);
            }
        }
    }
}

void synthAllOff() {
    float stealR = 1.f - fastExp(-3.f / (0.02f * SR));
    for (int i = 0; i < SYN_VOICES; i++) {
        Voice& v = synVoices[i];
        if (v.ampEnv.stage != ADSR::IDLE) {
            v.ampEnv.r_coef = stealR;
            v.ampEnv.stage = ADSR::REL;
            if (v.algo == ALG_THIEF) { v.apart[4] = 0.f; v.apart[5] = stealR; }
        }
        v.gate_samples = -1;
    }
}

// ---------------------------------------------------------------- AUDIO plane
void synthFireStep(uint16_t mask, uint32_t gstep) {
    (void)gstep;
    if (!mask) return;
    int offset = seqPickOctaveOffset(seq.lane[ENG_SYNTH]);
    int32_t gate = (int32_t)(clk.step_samples * 0.9f);
    if (gate < 1) gate = 1;
    for (int pad = 0; pad < N_PADS; pad++) {
        if (!((mask >> pad) & 1u)) continue;
        int degree, octave;
        scalePadToNote((uint8_t)pad, degree, octave);
        octave += offset;
        if (octave < 0) octave = 0;
        if (octave > SYN_OCTAVES - 1) octave = SYN_OCTAVES - 1;
        synTriggerNote(degree, octave, 0.8f, 0xFF, gate);
    }
}

void synthProcess(float* outL, float* outR, size_t n) {
    // ALGO param page's float shadow -> syn.algo (see synAlgoSelectPage()).
    // Two writers exist: the ALGO Param (synAlgoShadow, via the editor) and patchLoad
    // (syn.algo directly). Whichever CHANGED since last block wins; nothing is reverted.
    {
        static uint8_t lastAlgo = 0xFF; static float lastShadow = -1.f;
        int sh = (int)(synAlgoShadow + 0.5f);
        if (sh < 0) sh = 0; if (sh >= ALG_COUNT) sh = ALG_COUNT - 1;
        if ((float)sh != lastShadow && lastShadow >= 0.f) syn.algo = (uint8_t)sh;   // editor moved it
        else if (syn.algo != lastAlgo) synAlgoShadow = (float)syn.algo;             // patch/other set it
        if (syn.algo >= ALG_COUNT) syn.algo = 0;
        synAlgoShadow = (float)syn.algo;
        lastAlgo = syn.algo; lastShadow = synAlgoShadow;
    }

    float octGlobalMul = fastPow2(synPerfOctSmoo.process(syn.perf_octave));
    float volume = clampf(syn.volume, 0.f, ENGINE_VOL_MAX);
    bool perfActive = syn.perf_active;
    float perfCutHz = lerpf(200.f, 12000.f, clampf(syn.perf_cutoff, 0.f, 1.f));

    static float thiefL[BLOCK], thiefR[BLOCK];
    bool thiefAny = false;
    memset(thiefL, 0, n * sizeof(float)); memset(thiefR, 0, n * sizeof(float));

    for (int vi = 0; vi < SYN_VOICES; vi++) {
        Voice& v = synVoices[vi];
        if (v.ampEnv.stage == ADSR::IDLE) continue;

        const SynPreset& pr = syn.preset[v.algo];

        // block-rate filter coefficient: keytracked cutoff + filter envelope, capped for SVF stability.
        float filtLevel = v.filtEnv.processBlock((uint32_t)n);
        float baseCut = perfActive ? perfCutHz : pr.cutoff;
        float cutHz = baseCut + pr.filt_amt * filtLevel * (12000.f - 40.f);
        cutHz = clampf(cutHz, 40.f, 12000.f);
        float keytrack = sqrtf(v.note_hz * (1.f / 220.f));
        float fcHz = cutHz * keytrack;
        float f = 2.f * sinf(3.14159265f * clampf(fcHz, 20.f, 0.45f * SR) / SR);
        if (f > 0.9f)   f = 0.9f;
        if (f < 0.001f) f = 0.001f;
        v.svf_f = f;
        v.svf_q = 2.0f * (1.02f - clampf(pr.resonance, 0.f, 1.f));

        if (v.algo == ALG_THIEF) {
            // ===== V2 voice loop, verbatim (L2286-2428): one-pole AR env, drift, per-note VCF =====
            float m = clampf(syn.perf_env_macro, 0.f, 1.f);                 // plucky <-> ambient macro
            float tscale = (m <= 0.5f) ? lerpf(0.15f, 1.f, m * 2.f) : lerpf(1.f, 6.f, (m - 0.5f) * 2.f);
            float atk = v.apart[2] / tscale, rel = v.apart[5] / tscale;
            if (atk > 0.5f) atk = 0.5f;
            for (size_t i = 0; i < n; i++) {
                if (v.gate_samples > 0) {
                    v.gate_samples--;
                    if (v.gate_samples == 0) { v.apart[4] = 0.f; v.gate_samples = -1; }
                }
                float& env = v.apart[3];
                float eCoef = (v.apart[4] > env) ? atk : rel;
                env += (v.apart[4] - env) * eCoef;
                if (env < 0.0004f && v.apart[4] == 0.f) { v.ampEnv.stage = ADSR::IDLE; break; }
                float hz = v.note_hz * v.pitch_mul * octGlobalMul;
                float raw = synAlgoRender(vi, v, pr, hz / SR, env, synRng);
                raw = flushBad(raw);
                // per-note VCF pluck — states HARD-CLAMPED so ringing cannot grow
                v.aux[2] += (v.aux[3] - v.aux[2]) * v.aux[4];
                v.svf_lp += v.aux[2] * v.svf_bp;
                float vhp = raw - v.svf_lp - v.aux[5] * v.svf_bp;
                v.svf_bp += v.aux[2] * vhp;
                v.svf_lp = clampf(flushBad(v.svf_lp), -6.f, 6.f);
                v.svf_bp = clampf(flushBad(v.svf_bp), -6.f, 6.f);
                float sig = v.svf_lp * (0.05f * env);
                thiefL[i] += sig * (1.f - v.pan);
                thiefR[i] += sig * v.pan;
            }
            thiefAny = true;
            continue;
        }

        for (size_t i = 0; i < n; i++) {
            if (v.ampEnv.stage == ADSR::IDLE) break;

            if (v.gate_samples > 0) {
                v.gate_samples--;
                if (v.gate_samples == 0) { v.ampEnv.release(); v.gate_samples = -1; }
            }

            float envA = v.ampEnv.process();

            if (v.pitch_mul != v.pitch_target) {
                if (v.pitch_mul < v.pitch_target) {
                    v.pitch_mul += v.pitch_rate;
                    if (v.pitch_mul > v.pitch_target) v.pitch_mul = v.pitch_target;
                } else {
                    v.pitch_mul -= v.pitch_rate;
                    if (v.pitch_mul < v.pitch_target) v.pitch_mul = v.pitch_target;
                }
            }
            float hz = v.note_hz * v.pitch_mul * octGlobalMul;
            float phaseInc = hz / SR;

            float raw = synAlgoRender(vi, v, pr, phaseInc, envA, synRng);
            raw = flushBad(raw);

            v.svf_lp += v.svf_f * v.svf_bp;
            float hp = raw - v.svf_lp - v.svf_q * v.svf_bp;
            v.svf_bp += v.svf_f * hp;
            v.svf_lp = clampf(flushBad(v.svf_lp), -6.f, 6.f);
            v.svf_bp = clampf(flushBad(v.svf_bp), -6.f, 6.f);

            float sig = flushBad(v.svf_lp * envA * volume * 0.05f);
            outL[i] += sig * (1.f - v.pan);
            outR[i] += sig * v.pan;
        }
    }
    if (thiefAny) {
        // V2 synth bus: master SVF (open) -> saturation drive tanh(x*2.0) -> mix at 0.8
        for (size_t i = 0; i < n; i++) {
            float dl = thiefL[i] * 2.0f, dr = thiefR[i] * 2.0f;
            dl = (dl > 3.f) ? 1.f : (dl < -3.f) ? -1.f : dl * (27.f + dl * dl) / (27.f + 9.f * dl * dl);
            dr = (dr > 3.f) ? 1.f : (dr < -3.f) ? -1.f : dr * (27.f + dr * dr) / (27.f + 9.f * dr * dr);
            outL[i] += dl * 0.8f * volume;
            outR[i] += dr * 0.8f * volume;
        }
    }
}

// ---------------------------------------------------------------- editor pages
static const char* THIEF_NAMES[4] = { "CHARACTR", "GLIDEPCT", "SWELLPCT", "DRIFT" };
static const char* FM_NAMES[4]    = { "RATIO", "INDEX", "IDXDECAY", "FEEDBK" };
static const char* WAVE_NAMES[4]  = { "TABLE", "MORPH", "DETUNE", "ENVMORPH" };
static const char* PLUCK_NAMES[4] = { "DAMP", "BRIGHT", "PICKPOS", "DECAY" };
static const char* SUPER_NAMES[4] = { "DETUNE", "SPREAD", "MIX", "SUB" };
static const char* CZ_NAMES[4]    = { "DISTORT", "RESO", "ENVDIST", "SHAPE" };
static const char* FOLD_NAMES[4]  = { "FOLD", "SYM", "ENVFOLD", "DRIVE" };
static const char* ADD_NAMES[4]   = { "TILT", "ODDEVEN", "DECAYHI", "DRIFT" };

static Param     s_algoParams[ALG_COUNT][4];
static ParamPage s_algoPages[ALG_COUNT];

static Param     s_envParams[ALG_COUNT][4];
static ParamPage s_envPages[ALG_COUNT];
static Param     s_filtParams[ALG_COUNT][7];
static ParamPage s_filtPages[ALG_COUNT];
static Param     s_pitchParams[ALG_COUNT][3];
static ParamPage s_pitchPages[ALG_COUNT];
static Param     s_widthParams[ALG_COUNT][2];
static ParamPage s_widthPages[ALG_COUNT];

static Param     s_algoSelParam;
static ParamPage s_algoSelPage;
static Param     s_mixParam;
static ParamPage s_mixPage;

static bool s_pagesBuilt = false;

static void synBuildPages() {
    if (s_pagesBuilt) return;
    s_pagesBuilt = true;

    const char* const* names4[ALG_COUNT] = {
        THIEF_NAMES, FM_NAMES, WAVE_NAMES, PLUCK_NAMES, SUPER_NAMES, CZ_NAMES, FOLD_NAMES, ADD_NAMES
    };

    for (int a = 0; a < ALG_COUNT; a++) {
        SynPreset& pr = syn.preset[a];
        for (int k = 0; k < 4; k++) {
            float mn = 0.f, mx = 1.f; uint8_t flags = PF_PERCENT;
            if (a == ALG_FM && k == 0) { mn = 0.1f; mx = 16.f; flags = PF_NONE; }
            if (a == ALG_FM && k == 2) { mn = 0.f; mx = 4.f; flags = PF_NONE; }
            if (a == ALG_WAVE && k == 0) { mn = 0.f; mx = (float)(WT_N - 1); flags = PF_NONE; }
            if (a == ALG_ADD && k == 0) { mn = -1.f; mx = 1.f; flags = PF_BIPOLAR; }
            s_algoParams[a][k] = { names4[a][k], &pr.p[k], mn, mx, (mx - mn) * 0.01f, flags, nullptr };
        }
        s_algoPages[a] = { "ALGO", s_algoParams[a], 4 };

        s_envParams[a][0] = { "ATTACK",  &pr.amp.a, 0.001f, 4.f, 0.01f, PF_PAIR_X, nullptr };
        s_envParams[a][1] = { "DECAY",   &pr.amp.d, 0.005f, 6.f, 0.01f, PF_NONE,   nullptr };
        s_envParams[a][2] = { "SUSTAIN", &pr.amp.s, 0.f,    1.f, 0.01f, PF_PAIR_X | PF_PERCENT, nullptr };
        s_envParams[a][3] = { "RELEASE", &pr.amp.r, 0.005f, 6.f, 0.01f, PF_NONE,   nullptr };
        s_envPages[a] = { "ENV", s_envParams[a], 4 };

        s_filtParams[a][0] = { "CUTOFF",   &pr.cutoff,    40.f, 12000.f, 10.f, PF_PAIR_X, nullptr };
        s_filtParams[a][1] = { "RESO",     &pr.resonance, 0.f,  1.f,     0.01f, PF_PERCENT, nullptr };
        s_filtParams[a][2] = { "FATTACK",  &pr.filt.a,    0.001f, 4.f,   0.01f, PF_PAIR_X, nullptr };
        s_filtParams[a][3] = { "FDECAY",   &pr.filt.d,    0.005f, 6.f,   0.01f, PF_NONE,   nullptr };
        s_filtParams[a][4] = { "FSUSTAIN", &pr.filt.s,    0.f,    1.f,   0.01f, PF_PAIR_X | PF_PERCENT, nullptr };
        s_filtParams[a][5] = { "FRELEASE", &pr.filt.r,    0.005f, 6.f,   0.01f, PF_NONE,   nullptr };
        s_filtParams[a][6] = { "FAMOUNT",  &pr.filt_amt,  -1.f,   1.f,   0.01f, PF_BIPOLAR, nullptr };
        s_filtPages[a] = { "FILTER", s_filtParams[a], 7 };

        s_pitchParams[a][0] = { "SEMIS",    &pr.pitch_amt, -24.f, 24.f, 1.f, (uint8_t)(PF_PAIR_X | PF_QUANT | PF_BIPOLAR), nullptr };
        s_pitchParams[a][1] = { "GLIDEIN",  &pr.glide_in,  0.f, 2.f, 0.01f, PF_NONE,   nullptr };
        s_pitchParams[a][2] = { "GLIDEOUT", &pr.glide_out, 0.f, 2.f, 0.01f, PF_NONE,   nullptr };
        s_pitchPages[a] = { "PITCH", s_pitchParams[a], 3 };

        s_widthParams[a][0] = { "WIDTH",    &pr.width,      0.f, 1.f, 0.01f, PF_PAIR_X | PF_PERCENT, nullptr };
        s_widthParams[a][1] = { "WIDTHPRB", &pr.width_prob, 0.f, 1.f, 0.01f, PF_PERCENT, nullptr };
        s_widthPages[a] = { "WIDTH", s_widthParams[a], 2 };
    }

    synAlgoShadow = (float)syn.algo;
    s_algoSelParam = { "ALGO", &synAlgoShadow, 0.f, (float)(ALG_COUNT - 1), 1.f, PF_QUANT | PF_ENUM, SYN_ALGO_NAMES };
    s_algoSelPage  = { "ALGO", &s_algoSelParam, 1 };

    s_mixParam = { "VOLUME", &syn.volume, 0.f, ENGINE_VOL_MAX, 0.01f, PF_PERCENT, nullptr };
    s_mixPage  = { "MIX", &s_mixParam, 1 };
}

const ParamPage* synAlgoParamPage(uint8_t algo) {
    synBuildPages();
    if (algo >= ALG_COUNT) algo = 0;
    return &s_algoPages[algo];
}
const ParamPage* synEnvPage()    { synBuildPages(); return &s_envPages[syn.algo]; }
const ParamPage* synFilterPage() { synBuildPages(); return &s_filtPages[syn.algo]; }
const ParamPage* synPitchPage()  { synBuildPages(); return &s_pitchPages[syn.algo]; }
const ParamPage* synWidthPage()  { synBuildPages(); return &s_widthPages[syn.algo]; }
const ParamPage* synAlgoSelectPage() { synBuildPages(); return &s_algoSelPage; }
const ParamPage* synMixPage()        { synBuildPages(); return &s_mixPage; }
