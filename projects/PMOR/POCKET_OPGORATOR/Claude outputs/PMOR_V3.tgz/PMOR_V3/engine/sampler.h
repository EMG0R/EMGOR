// sampler.h — 16 slots × 2 s mono in SDRAM. Record starts ON PRESS, stops on release, with fades.
#pragma once
#include <stdint.h>
#include "../config.h"
#include "param.h"

struct SmpSlotCfg {                 // patch-serialised
    float pitch;                    // -1..1  → ±1 octave
    float formant;                  // -1..1
    float cutoff;                   // 0..1 (1 = open, default)
    bool  reverse;
};

struct SamplerState {
    SmpSlotCfg slot[SMP_SLOTS];
    uint32_t   len[SMP_SLOTS];      // samples recorded (0 = empty)
    float      volume;              // 0..1.25
    float      width, width_prob;   // as synth
    float      polyphony;           // voices, same 2/3 pan rule as synth
    // transient state (not serialised)
    int8_t     rec_slot;            // -1 = idle
    volatile uint32_t rec_pos;
    bool       audio_dirty;         // needs SD save
};
extern SamplerState smp;
extern float SDRAM_BSS smp_buf[SMP_SLOTS][SMP_LEN];

void samplerInit();
// CONTROL plane
bool samplerRecordStart(uint8_t slot);       // false if slot occupied (must delete first)
void samplerRecordStop();
void samplerDelete(uint8_t slot);
void samplerPlay(uint8_t slot, float vel);   // manual
// AUDIO plane
void samplerFireStep(uint16_t mask);
void samplerProcess(const float* inL, float* outL, float* outR, size_t n);
// editor
const ParamPage* samplerSlotPage(uint8_t slot);   // pitch × formant pair, cutoff, reverse
const ParamPage* samplerMixPage();
