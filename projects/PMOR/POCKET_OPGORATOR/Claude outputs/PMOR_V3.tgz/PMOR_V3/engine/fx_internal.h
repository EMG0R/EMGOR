// fx_internal.h — contract between fx.cpp (host) and the family files (fx_home/up/right/down/left.cpp).
// Each effect is a small object: engage/release with anti-click fade handled by the HOST,
// process() called only while the effect's fade envelope > 0.
#pragma once
#include <stdint.h>
#include <stddef.h>
#include <math.h>
#include "../config.h"
#include "fx.h"
#include "clock.h"

struct FxCtx {                       // per-block inputs, filled by fx.cpp
    float    fsr;                    // 0..1
    float    lidar;                  // 0..1
    float    accel_x;                // -1..1 (LFO speed for lfo-type effects)
    float    step_phase;             // 0..1 inside the 16th
    float    step_samples;           // samples per 16th
    uint32_t gstep;
    uint32_t sample_now;             // absolute sample counter
    float    varispeed;              // shadow clock
    // capture ring of the dry mix (2 s stereo), written by fx.cpp BEFORE effects run
    const float* ringL; const float* ringR; uint32_t ring_w; uint32_t ring_n;   // ring_n = 96000
    uint32_t step_ring_w;            // ring_w at the last 16th boundary
};

struct Effect {
    virtual void init() {}                          // zero SDRAM buffers etc. (boot)
    virtual void onEngage(const FxCtx&) {}          // pad pressed (state reset lives here, NOT in statics)
    virtual void onRelease(const FxCtx&) {}
    // process in place; `amt` = fade envelope 0..1 × (FSR if the effect wants it). Effects mix
    // wet/dry themselves using amt so release tails behave per effect.
    virtual void process(float* L, float* R, size_t n, const FxCtx& c, float amt) = 0;
    virtual ~Effect() {}
};

// Family files export a table of FX_PER_DIR (12) or FX_HOME (16) effects + matching FxInfo rows.
extern Effect* const FX_HOME_TABLE[FX_HOME];
extern Effect* const FX_UP_TABLE[FX_PER_DIR];
extern Effect* const FX_RIGHT_TABLE[FX_PER_DIR];
extern Effect* const FX_DOWN_TABLE[FX_PER_DIR];
extern Effect* const FX_LEFT_TABLE[FX_PER_DIR];
extern const FxInfo FX_HOME_INFO[FX_HOME];
extern const FxInfo FX_UP_INFO[FX_PER_DIR];
extern const FxInfo FX_RIGHT_INFO[FX_PER_DIR];
extern const FxInfo FX_DOWN_INFO[FX_PER_DIR];
extern const FxInfo FX_LEFT_INFO[FX_PER_DIR];

// ---- shared helpers (header-only, cheap)
static inline float fxLerp(float a, float b, float t) { return a + (b - a) * t; }
static inline float fxTanh(float z) {                     // rational tanh, clamped
    if (z > 3.f) return 1.f;
    if (z < -3.f) return -1.f;
    float z2 = z * z; return z * (27.f + z2) / (27.f + 9.f * z2);
}
static inline float fxRingRead(const float* ring, uint32_t n, uint32_t w, float back) {  // linear-interp read `back` samples behind w
    float p = (float)w - back; while (p < 0) p += n;
    uint32_t i = (uint32_t)p; float f = p - i; uint32_t j = i + 1; if (j >= n) j -= n;
    return ring[i] + (ring[j] - ring[i]) * f;
}
// one-pole coefficient for a time constant in ms
static inline float fxCoefMs(float ms) { return 1.f - expf(-1.f / (0.001f * ms * SR)); }
// LFO speed rule: accel_x (-1..1) → Hz in [lo, hi] exponentially, centre = geometric mean
static inline float fxLfoHz(float accel_x, float lo, float hi) { float t = 0.5f + 0.5f * accel_x; return lo * powf(hi / lo, t); }
// Distortion set shared by DOWN family and the drum/sampler perf DOWN throw (implemented in fx_down.cpp)
float fxDistSample(DistAlgo a, float x, float drive);
// 5 ms crossfade between the old and new fx.dist_algo outputs of fxDistSample, so switching
// algorithms never clicks. Shared single instance (fx.cpp) — call for both channels; the
// switch timing is shared, fxDistSample itself is stateless per call. (fx.cpp)
float fxDistXfade(float x, float drive);
