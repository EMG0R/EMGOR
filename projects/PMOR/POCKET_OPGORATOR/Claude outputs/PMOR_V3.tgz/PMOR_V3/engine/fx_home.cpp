// fx_home.cpp — the 16 HOME effects (strongest/most dramatic nearest the centre pads
// 5,6,9,10). ST4/ST8/ST16/ST32/BZZ and HALF/DBL/STOP are flag-setters: their process() is
// empty, they just flip flags in fx_host.h and the HOST (fx.cpp) owns the actual DSP/timing.
// The rest are real per-sample effects. All family = FXD_HOME; names ≤5 chars.
#include <string.h>
#include "fx_internal.h"
#include "fx_host.h"
#include "engine_util.h"

// ============================================================ ST4 / ST8 / ST16 / ST32
// Grid-locked retrigger rate select (mutually exclusive; last engaged wins via fx_host_stut).
struct StutEffect : Effect {
    StutRate rate;
    explicit StutEffect(StutRate r) : rate(r) {}
    void onEngage(const FxCtx&) override { fxHostSetRate(rate); }
    void onRelease(const FxCtx&) override { fxHostClearRate(rate); }
    void process(float*, float*, size_t, const FxCtx&, float) override {}
};
static StutEffect fx_st4(STUT_4), fx_st8(STUT_8), fx_st16(STUT_16), fx_st32(STUT_32);

// ============================================================ BZZ
// Generative oscillating roll: fx.cpp picks a new subdivision each 16th (FSR-biased).
struct BzzEffect : Effect {
    void onEngage(const FxCtx&) override { fxHostBzzOn(); }
    void onRelease(const FxCtx&) override { fxHostBzzOff(); }
    void process(float*, float*, size_t, const FxCtx&, float) override {}
};
static BzzEffect fx_bzz;

// ============================================================ HALF / DBL / STOP
// Shadow-clock varispeed request; fx.cpp arbitrates fx.varispeed_req from these flags.
struct HalfEffect : Effect {
    void onEngage(const FxCtx&) override { fx_host_vs.half = true; }
    void onRelease(const FxCtx&) override { fx_host_vs.half = false; }
    void process(float*, float*, size_t, const FxCtx&, float) override {}
};
struct DblEffect : Effect {
    void onEngage(const FxCtx&) override { fx_host_vs.dbl = true; }
    void onRelease(const FxCtx&) override { fx_host_vs.dbl = false; }
    void process(float*, float*, size_t, const FxCtx&, float) override {}
};
struct StopEffect : Effect {
    void onEngage(const FxCtx&) override { fx_host_vs.stop = true; }
    void onRelease(const FxCtx&) override { fx_host_vs.stop = false; }
    void process(float*, float*, size_t, const FxCtx&, float) override {}
};
static HalfEffect fx_half;
static DblEffect  fx_dbl;
static StopEffect fx_stop;

// ============================================================ REV
// Reverse the last "beat" (4 sixteenths) out of the capture ring, edges faded, no pitch
// change. (PMOR_V2.cpp L2526-2539)
struct RevEffect : Effect {
    float    pos    = 0.f;
    uint32_t anchor = 0;
    void onEngage(const FxCtx& c) override { pos = 0.f; anchor = c.step_ring_w; }
    void onRelease(const FxCtx&) override {}
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        float le = c.step_samples * 4.f;
        if (le < 64.f) le = 64.f;
        float cap = (float)c.ring_n - 64.f;
        if (le > cap) le = cap;
        for (size_t i = 0; i < n; i++) {
            pos += 1.f;
            while (pos >= le) pos -= le;
            float g = 1.f;
            if (pos < 480.f) g = pos * (1.f / 480.f);
            else if (le - pos < 480.f) g = (le - pos) * (1.f / 480.f);
            float back = 1.f + pos;   // reads progressively further into the past as pos grows
            float sL = fxRingRead(c.ringL, c.ring_n, anchor, back) * g;
            float sR = fxRingRead(c.ringR, c.ring_n, anchor, back) * g;
            L[i] += (sL - L[i]) * amt;
            R[i] += (sR - R[i]) * amt;
        }
    }
};
static RevEffect fx_rev;

// ============================================================ DUB
// Mono dub echo. FSR = feedback (runaway), lidar = time. (PMOR_V2.cpp L2590-2602)
#define DUB_N 40000u
static float SDRAM_BSS dub_buf[DUB_N];
struct DubEffect : Effect {
    uint32_t w = 0;
    float    t = 9000.f;
    void init() override { memset(dub_buf, 0, sizeof(dub_buf)); w = 0; t = 9000.f; }
    void onEngage(const FxCtx&) override {}
    void onRelease(const FxCtx&) override {}
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        for (size_t i = 0; i < n; i++) {
            float tt = 3840.f + c.lidar * (float)(DUB_N - 5000u);
            t += (tt - t) * 0.0004f;
            uint32_t dl = (uint32_t)t; if (dl > DUB_N - 2u) dl = DUB_N - 2u;
            uint32_t rp = w + DUB_N - dl; if (rp >= DUB_N) rp -= DUB_N;
            float e   = dub_buf[rp];
            float fb  = 0.45f + c.fsr * 0.6f;
            float in  = (L[i] + R[i]) * 0.5f;
            float wr  = fxTanh((in + e * fb) * 0.8f) * 1.25f;
            dub_buf[w] = flushDenorm(wr);
            w++; if (w >= DUB_N) w = 0;
            L[i] += e * 0.9f * amt;
            R[i] += e * 0.9f * amt;
        }
    }
};
static DubEffect fx_dub;

// ============================================================ RING
// Ring modulator with a lidar-driven pitch wobble. (PMOR_V2.cpp L3317-3326)
struct RingEffect : Effect {
    float phase = 0.f;
    void onEngage(const FxCtx&) override { phase = 0.f; }
    void onRelease(const FxCtx&) override {}
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        for (size_t i = 0; i < n; i++) {
            float fc = 40.f * fastPow2(5.229f * c.fsr) * (1.f + 0.3f * c.lidar * sinf(phase * 0.07f));
            phase += fc * (1.f / SR); if (phase >= 1.f) phase -= 1.f;
            float cc = sinf(phase * 6.2831853f);
            float wL = L[i] * cc, wR = R[i] * cc;
            float m  = c.fsr * 0.9f * amt;
            L[i] += (wL - L[i]) * m;
            R[i] += (wR - R[i]) * m;
        }
    }
};
static RingEffect fx_ring;

// ============================================================ GRAIN
// Granular freeze/scrub from the capture ring. FSR = grain size, lidar = scrub position.
// (PMOR_V2.cpp L2694-2704)
struct GrainEffect : Effect {
    uint32_t gpos = 0, glen = 4800u;
    void onEngage(const FxCtx&) override { gpos = 0; }
    void onRelease(const FxCtx&) override {}
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        for (size_t i = 0; i < n; i++) {
            glen = (uint32_t)(5760.f - c.fsr * 5400.f); if (glen < 240u) glen = 240u;
            uint32_t base = (uint32_t)(c.lidar * (float)(c.ring_n > glen + 2u ? c.ring_n - glen - 2u : 1u));
            gpos++; if (gpos >= glen) gpos = 0;
            uint32_t rp = base + gpos; if (rp >= c.ring_n) rp -= c.ring_n;
            float w  = 0.5f - 0.5f * cosf(6.2831853f * (float)gpos / (float)glen);
            float nL = c.ringL[rp] * w + L[i] * (1.f - w) * 0.3f;
            float nR = c.ringR[rp] * w + R[i] * (1.f - w) * 0.3f;
            L[i] += (nL - L[i]) * amt;
            R[i] += (nR - R[i]) * amt;
        }
    }
};
static GrainEffect fx_grain;

// ============================================================ FILT
// Resonant lowpass swept by fx.filter_pos (0..1), which nav writes from the joystick L/R
// while this pad is held. Release leaves the position where it was.
struct FiltEffect : Effect {
    float lp = 0.f, bp = 0.f, lpR = 0.f, bpR = 0.f;
    void onEngage(const FxCtx&) override {}
    void onRelease(const FxCtx&) override {}
    void process(float* L, float* R, size_t n, const FxCtx&, float amt) override {
        float pos = clampf(fx.filter_pos, 0.f, 1.f);
        float fc  = 200.f * fastPow2(pos * 4.129f);   // ~200 Hz .. ~3.5 kHz
        float f   = 2.f * sinf(3.14159265f * fc / SR);
        const float q = 0.3f;
        for (size_t i = 0; i < n; i++) {
            lp += f * bp;  float hp  = L[i] - lp  - q * bp;  bp  += f * hp;
            lpR += f * bpR; float hpR = R[i] - lpR - q * bpR; bpR += f * hpR;
            lp = clampf(lp, -4.f, 4.f);   bp = clampf(bp, -4.f, 4.f);
            lpR = clampf(lpR, -4.f, 4.f); bpR = clampf(bpR, -4.f, 4.f);
            L[i] += (bp - L[i]) * amt;
            R[i] += (bpR - R[i]) * amt;
        }
    }
};
static FiltEffect fx_filt;

// ============================================================ PUMP
// Sidechain-style ducking pulse, re-triggered every bar (4 sixteenths). FSR = duck depth.
// (PMOR_V2.cpp L2878-2885)
struct PumpEffect : Effect {
    float env = 1.f, phase = 0.f;
    void onEngage(const FxCtx&) override { env = 1.f; phase = 0.f; }
    void onRelease(const FxCtx&) override {}
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        float beat = c.step_samples * 4.f; if (beat < 480.f) beat = 480.f;
        float invBeat = 1.f / beat;
        for (size_t i = 0; i < n; i++) {
            phase += 1.f; if (phase >= beat) phase -= beat;
            float t    = phase * invBeat;
            float duck = 1.f - (0.3f + c.fsr * 0.65f) * fastExp(-t * 6.f);
            env += (duck - env) * 0.05f;
            L[i] += (L[i] * env - L[i]) * amt;
            R[i] += (R[i] * env - R[i]) * amt;
        }
    }
};
static PumpEffect fx_pump;

// ============================================================ MUTE
// Clean full drop; the host's own FX_FADE_MS engage/release ramp (amt) is the ramp.
struct MuteEffect : Effect {
    void onEngage(const FxCtx&) override {}
    void onRelease(const FxCtx&) override {}
    void process(float* L, float* R, size_t n, const FxCtx&, float amt) override {
        float g = 1.f - amt;
        for (size_t i = 0; i < n; i++) { L[i] *= g; R[i] *= g; }
    }
};
static MuteEffect fx_mute;

// ============================================================ WASH
// Long-tail wash: feedback delay smear, FSR controls smear time + regen. Stands in for a
// synth-side voice-release stretch (out of scope here).
#define WASH_N 48000u
static float SDRAM_BSS wash_buf[WASH_N];
struct WashEffect : Effect {
    uint32_t w = 0;
    void init() override { memset(wash_buf, 0, sizeof(wash_buf)); w = 0; }
    void onEngage(const FxCtx&) override {}
    void onRelease(const FxCtx&) override {}
    void process(float* L, float* R, size_t n, const FxCtx& c, float amt) override {
        float dl = 12000.f + c.fsr * 30000.f;   // ~250 ms .. ~875 ms smear
        float fb = 0.55f + c.fsr * 0.35f;
        for (size_t i = 0; i < n; i++) {
            float rd = fxRingRead(wash_buf, WASH_N, w, dl);
            float in = (L[i] + R[i]) * 0.5f;
            wash_buf[w] = flushDenorm(fxTanh((in + rd * fb) * 0.7f));
            w++; if (w >= WASH_N) w = 0;
            L[i] += (rd - L[i]) * amt * 0.9f;
            R[i] += (rd - R[i]) * amt * 0.9f;
        }
    }
};
static WashEffect fx_wash;

// ============================================================ tables
// Layout (row-major 4x4): most dramatic (STOP, HALF, DBL, REV) sit on the centre pads 5,6,9,10.
//   0:ST4   1:ST8   2:ST16  3:ST32
//   4:BZZ   5:STOP  6:HALF  7:DUB
//   8:GRAIN 9:DBL  10:REV  11:RING
//  12:FILT 13:PUMP 14:MUTE 15:WASH
Effect* const FX_HOME_TABLE[FX_HOME] = {
    &fx_st4,  &fx_st8,  &fx_st16, &fx_st32,
    &fx_bzz,  &fx_stop, &fx_half, &fx_dub,
    &fx_grain,&fx_dbl,  &fx_rev,  &fx_ring,
    &fx_filt, &fx_pump, &fx_mute, &fx_wash,
};

const FxInfo FX_HOME_INFO[FX_HOME] = {
    { "ST4",   FXD_HOME, true,  false },
    { "ST8",   FXD_HOME, true,  false },
    { "ST16",  FXD_HOME, true,  false },
    { "ST32",  FXD_HOME, true,  false },
    { "BZZ",   FXD_HOME, true,  false },
    { "STOP",  FXD_HOME, true,  false },
    { "HALF",  FXD_HOME, true,  false },
    { "DUB",   FXD_HOME, false, false },
    { "GRAIN", FXD_HOME, false, false },
    { "DBL",   FXD_HOME, true,  false },
    { "REV",   FXD_HOME, true,  false },
    { "RING",  FXD_HOME, false, false },
    { "FILT",  FXD_HOME, false, false },
    { "PUMP",  FXD_HOME, true,  false },
    { "MUTE",  FXD_HOME, false, false },
    { "WASH",  FXD_HOME, false, false },
};
