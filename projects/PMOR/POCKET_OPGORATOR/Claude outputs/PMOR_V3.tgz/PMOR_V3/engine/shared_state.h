// shared_state.h — the ONLY cross-plane globals. Each field says which plane writes it.
//   CONTROL plane = main loop (may block: I2C, OLED, SD).
//   AUDIO plane   = AudioCallback + everything it calls (never blocks, never I2C).
// Rule: control writes, audio reads (or the reverse) — never both write the same field.
#pragma once
#include <stdint.h>
#include "../config.h"

struct SharedState {
    // ---- sensors (CONTROL writes, AUDIO reads)
    volatile float fsr;          // 0..1 scaled (FsrScale), median-filtered
    volatile float lidar;        // 0..1 (0 = far / none, 1 = touching), smoothed
    volatile float accel_x;      // g, -1..1 typical tilt
    volatile float accel_y;
    volatile float accel_z;
    volatile bool  trellis_ok;

    // ---- joystick (AUDIO plane polls ADC at 750 Hz and writes; CONTROL reads)
    volatile float joy_x;        // -1..1, deadzoned, centre-calibrated
    volatile float joy_y;
    volatile bool  joy_sw;       // raw level, debounced by nav
    volatile bool  joy_calibrated;
    volatile uint16_t joy_raw_x, joy_raw_y;   // for DASH

    // ---- pads (CONTROL writes on trellis events, AUDIO reads)
    volatile uint16_t pads_held;     // bitmask of physically held pads

    // ---- metering (AUDIO writes, CONTROL reads)
    volatile float out_amp;      // post-clipper peak follower 0..1, for screensaver/particles/meter
    volatile float cpu_load;     // 0..1, last block

    // ---- transport (AUDIO writes, CONTROL reads)
    volatile uint32_t gstep;     // global 16th index within the longest loop
    volatile uint32_t bar;       // current bar
    volatile float    bpm;       // effective (unquantized when tapped)
};

extern SharedState g;
