// patch.h — 64 patches on SD (4 pages × 16), each a file PATCHnn.PMR (+ PATCHnn.AUD audio sidecar).
// QSPI holds only a tiny "boot" record (last patch, globals). Autosave debounced.
#pragma once
#include <stdint.h>
#include "../config.h"

struct Globals {                         // not per-patch
    float   key_semis;                   // continuous
    uint8_t scale_mode;
    float   input_gain;
    float   trellis_brightness;          // 0..1
    uint8_t clock_mode;                  // PO SY0..SY5
    uint8_t last_patch;                  // boots here
    float   master_fader;
    float   oled_contrast;               // 1..32, default 1 (see hw/oled.cpp)
    float   swing;                       // 0..1
};
extern Globals glob;

struct PatchMeta { bool exists; };

void  patchInit();                        // mounts (via hw/sd), loads globals from QSPI, loads last patch
bool  patchLoad(uint8_t slot);            // sound only — nav page unchanged
bool  patchNew(uint8_t slot);             // fresh (boot-default) patch in an empty slot, saved at once, becomes current
bool  patchSave(uint8_t slot);            // full write (blocking, control plane) — prefer markDirty
void  patchDelete(uint8_t slot);
bool  patchExists(uint8_t slot);
uint8_t patchCurrent();
// autosave
void  patchMarkDirty();                   // any edit → save AUTOSAVE_DEBOUNCE_MS after the last one
void  patchTick(uint32_t now_ms);         // run the debounce + chunked audio save (never stalls UI > 1 sector)
bool  patchSaving();                      // for the star (busy spinner)
bool  patchDirty();
void  globalsSave();                      // QSPI
void  patchFactoryReset();

// DASH diagnostics: saves that succeeded / failed this session, how the boot-slot load went
// (0 none, 1 ok, 2 unreadable, 3 wrong size/magic, 4 CRC), bytes read on a size mismatch.
struct PatchDiag { uint16_t saves_ok, saves_fail; uint8_t boot_load; uint16_t load_size; };
const PatchDiag& patchDiag();                // store/patch.cpp addition: delete all 64 patches + reset globals
