// patch.cpp — 64 patches on SD (store/patch.h). QSPI holds only Globals
// (magic + version, like v2-audit.md §8 L1254's PersistentStorage<SessionBank>).
// Files: PATCHnn.PMR (sound-only snapshot, atomic via store/files.h) and
// PATCHnn.AUD (int16 PCM sidecar for non-empty sampler slots, same layout
// as v2's 'PAUD': [magic][ver][uint32 lens[16]][pcm...][magic] — audit
// §8 L1292-1393). PMR is written synchronously (small); AUD is written in
// <=4KB chunks driven from patchTick so a multi-second sampler save never
// stalls the UI (audit's audSaveTick/audBeginSave pattern, L1309-1352).
//
// Degrades completely without an SD card: patchInit() still loads Globals
// from QSPI and applies them; every patch op becomes a silent no-op
// (patchLoad/patchSave return false, patchSaving() stays false) — nothing
// here can block or crash while the user's card is missing or unmountable.
#include "patch.h"
#include "files.h"
#include "fatfs.h"
#include "../config.h"
#include "../hw/hw.h"
#include "../engine/synth.h"
#include "../engine/drums.h"
#include "../engine/sampler.h"
#include "../engine/sequencer.h"
#include "../engine/fx.h"
#include "../engine/output.h"
#include "../engine/scale.h"
#include "../engine/clock.h"
extern "C" {
#include "../usb/clock_engine.h"
}
#include "../ui/render.h"    // g_trellis_brightness
#include "daisy_seed.h"
#include <string.h>
#include <stdio.h>

using namespace daisy;

Globals glob;

// ============================================================ CRC32 (control plane only)
static uint32_t crc32Buf(const void* data, size_t n) {
    const uint8_t* p = (const uint8_t*)data;
    uint32_t crc = 0xFFFFFFFFu;
    for (size_t i = 0; i < n; i++) {
        crc ^= p[i];
        for (int b = 0; b < 8; b++)
            crc = (crc & 1u) ? (crc >> 1) ^ 0xEDB88320u : (crc >> 1);
    }
    return ~crc;
}

// ============================================================ Globals (QSPI)
#define GLOB_MAGIC   0x474C4F42u   // 'GLOB'
#define GLOB_VERSION 1u

struct GlobalsRecord {
    uint32_t magic;
    uint32_t version;
    Globals  g;
    bool operator==(const GlobalsRecord& o) const { return memcmp(this, &o, sizeof(GlobalsRecord)) == 0; }
    bool operator!=(const GlobalsRecord& o) const { return !(*this == o); }
};
static PersistentStorage<GlobalsRecord> gstore(hw.qspi);
// QSPI offset for the globals record: the last 64 KB of the 8 MB chip, far above the
// bootloader's reserved first 256 KB and the app image at 0x90040000.
#define GLOB_QSPI_OFFSET 0x7F0000u

static Globals defaultGlobals() {
    Globals d{};
    d.key_semis          = 0.f;
    d.scale_mode         = 0;
    d.input_gain         = 1.f;
    d.trellis_brightness = 0.45f;
    d.clock_mode         = 0;
    d.last_patch         = 0;
    d.master_fader       = 1.f;
    d.oled_contrast      = 1.f;
    d.swing              = 0.f;
    return d;
}

void globalsSave() {
    GlobalsRecord& r = gstore.GetSettings();
    r.magic   = GLOB_MAGIC;
    r.version = GLOB_VERSION;
    r.g       = glob;
    gstore.Save();
}

static void globalsApply() {
    scale.key_semis = glob.key_semis;
    scale.mode      = glob.scale_mode;
    scaleRebuild();
    outp.fader      = glob.master_fader;
    outp.input_gain = glob.input_gain;
    g_trellis_brightness = glob.trellis_brightness;
    oledSetContrast((uint8_t)(glob.oled_contrast + 0.5f));
    clock_engine_set_sync_mode((sync_mode_t)glob.clock_mode);
    clk.swing       = glob.swing;
}

// GLOBAL settings transcend patches: fader, input gain, brightness, contrast, key/scale, swing.
// Any live change is mirrored into glob and written to QSPI after a 3 s quiet period.
static uint32_t g_glob_save_at = 0;
static bool     g_glob_dirty   = false;
static void globalsSyncTick(uint32_t now_ms) {
    bool ch = false;
    if (glob.master_fader != outp.fader)               { glob.master_fader = outp.fader; ch = true; }
    if (glob.input_gain   != outp.input_gain)          { glob.input_gain = outp.input_gain; ch = true; }
    if (glob.trellis_brightness != g_trellis_brightness){ glob.trellis_brightness = g_trellis_brightness; ch = true; }
    if (glob.key_semis    != scale.key_semis)          { glob.key_semis = scale.key_semis; ch = true; }
    if (glob.scale_mode   != scale.mode)               { glob.scale_mode = scale.mode; ch = true; }
    if (glob.swing        != clk.swing)                { glob.swing = clk.swing; ch = true; }
    if (ch) { g_glob_dirty = true; g_glob_save_at = now_ms + 3000; }
    if (g_glob_dirty && now_ms >= g_glob_save_at) { g_glob_dirty = false; globalsSave(); }
}

// ============================================================ Patch (SD, PATCHnn.PMR / .AUD)
struct Patch {
    uint32_t magic, version;
    // syn
    uint8_t    syn_algo;
    SynPreset  syn_preset[ALG_COUNT];
    float      syn_volume;
    // drums
    DrumPadCfg drum_pad[N_PADS];
    float      drum_group_vol[DG_COUNT];
    float      drum_volume;
    // smp
    SmpSlotCfg smp_slot[SMP_SLOTS];
    uint32_t   smp_len[SMP_SLOTS];
    float      smp_volume, smp_width, smp_width_prob, smp_polyphony;
    // seq (all three lane sets, verbatim)
    LaneSet    seq_lane[ENG_COUNT];
    // fx
    uint64_t   fx_auto_mask[MAXSTEPS];
    uint8_t    fx_auto_fsr[MAXSTEPS];
    uint8_t    fx_dist_algo;
    uint8_t    fx_auto_enabled;
    // output
    float      outp_fader;
    uint32_t   crc32;          // over everything above
};

#define AUD_MAGIC 0x44554150u   // 'PAUD' — same sidecar layout as v2

// v3 files live in their own folder with their own names so nothing ever collides with
// the v2 PATCHnn.* files on the same card.
#define PMOR3_DIR "PMOR3"
static bool s_use_dir = true;   // false = the folder could not be created: files go in the root as V3Pnn.*
static void patchName(char* o, uint8_t slot) {
    unsigned n = (unsigned)(slot & (PATCH_SLOTS - 1));
    if (s_use_dir) sprintf(o, PMOR3_DIR "/P%02u.PMR", n); else sprintf(o, "V3P%02u.PMR", n);
}
static void audName(char* o, uint8_t slot) {
    unsigned n = (unsigned)(slot & (PATCH_SLOTS - 1));
    if (s_use_dir) sprintf(o, PMOR3_DIR "/P%02u.AUD", n); else sprintf(o, "V3P%02u.AUD", n);
}

// diagnostics for the DASH page
PatchDiag patch_diag = { 0, 0, 0, 0 };
static Patch s_default;          // the boot defaults (before any patch loads) = a "new" patch

static uint32_t patchLiveCrc();
static uint32_t s_last_saved_crc = 0, s_last_seen_crc = 0, s_next_scan = 0;
static void patchSnapshot(Patch& p) {
    memset(&p, 0, sizeof(p));
    p.magic   = PATCH_MAGIC;
    p.version = 2;   // v2: SynPreset gained pitch_amt

    p.syn_algo = syn.algo;
    memcpy(p.syn_preset, syn.preset, sizeof(p.syn_preset));
    p.syn_volume = syn.volume;

    memcpy(p.drum_pad, drums.pad, sizeof(p.drum_pad));
    memcpy(p.drum_group_vol, drums.group_vol, sizeof(p.drum_group_vol));
    p.drum_volume = drums.volume;

    memcpy(p.smp_slot, smp.slot, sizeof(p.smp_slot));
    memcpy(p.smp_len, smp.len, sizeof(p.smp_len));
    p.smp_volume      = smp.volume;
    p.smp_width       = smp.width;
    p.smp_width_prob  = smp.width_prob;
    p.smp_polyphony   = smp.polyphony;

    memcpy(p.seq_lane, seq.lane, sizeof(p.seq_lane));

    memcpy(p.fx_auto_mask, (const void*)fx.auto_mask, sizeof(p.fx_auto_mask));
    memcpy(p.fx_auto_fsr, (const void*)fx.auto_fsr, sizeof(p.fx_auto_fsr));
    p.fx_dist_algo    = fx.dist_algo;
    p.fx_auto_enabled = fx.auto_enabled ? 1 : 0;

    p.outp_fader = 0.f;   // master fader is GLOBAL (glob.master_fader), never per patch

    p.crc32 = crc32Buf(&p, sizeof(p) - sizeof(p.crc32));
}

static void patchApply(const Patch& p) {
    syn.algo = p.syn_algo;
    memcpy(syn.preset, p.syn_preset, sizeof(syn.preset));
    syn.volume = p.syn_volume;

    memcpy(drums.pad, p.drum_pad, sizeof(drums.pad));
    memcpy(drums.group_vol, p.drum_group_vol, sizeof(drums.group_vol));
    drums.volume = p.drum_volume;

    memcpy(smp.slot, p.smp_slot, sizeof(smp.slot));
    memcpy(smp.len, p.smp_len, sizeof(smp.len));
    smp.volume     = p.smp_volume;
    smp.width      = p.smp_width;
    smp.width_prob = p.smp_width_prob;
    smp.polyphony  = p.smp_polyphony;

    memcpy(seq.lane, p.seq_lane, sizeof(seq.lane));

    memcpy((void*)fx.auto_mask, p.fx_auto_mask, sizeof(p.fx_auto_mask));
    memcpy((void*)fx.auto_fsr, p.fx_auto_fsr, sizeof(p.fx_auto_fsr));
    fx.dist_algo    = p.fx_dist_algo;
    fx.auto_enabled = p.fx_auto_enabled != 0;

    // outp.fader deliberately NOT applied: master volume transcends patches
}

// ---- existence bitmap, scanned once at boot -------------------------------
static uint64_t g_exists_mask = 0;

static void scanExists() {
    g_exists_mask = 0;
    if (!sdOk()) return;
    for (int s = 0; s < PATCH_SLOTS; s++) {
        char nm[16]; patchName(nm, (uint8_t)s);
        FILINFO fi;
        if (f_stat(nm, &fi) == FR_OK) g_exists_mask |= (1ull << s);
    }
}

bool patchExists(uint8_t slot) {
    if (slot >= PATCH_SLOTS) return false;
    return (g_exists_mask & (1ull << slot)) != 0;
}

// ---- current slot / dirty / saving state -----------------------------------
static uint8_t  g_cur_slot = 0;
static bool     g_dirty    = false;
static uint32_t g_save_at  = 0;

uint8_t patchCurrent() { return g_cur_slot; }
bool    patchDirty()   { return g_dirty; }

// ---- chunked AUD (sampler audio) save, driven from patchTick --------------
static ChunkedWriter aud_writer;
static bool          aud_saving  = false;
static int           aud_slot_ix = 0;   // 0..SMP_SLOTS-1, which sampler slot we're writing
static uint32_t      aud_pos     = 0;   // samples written of the current slot
static int16_t       aud_buf[1024];     // 1024 * int16 = 2KB <= the 4KB-per-tick budget

bool patchSaving() { return aud_saving; }

static bool audBeginSave(uint8_t slot) {
    char nm[16]; audName(nm, slot);
    if (!aud_writer.begin(nm)) return false;
    uint32_t hdr[2] = { AUD_MAGIC, 1u };
    if (!aud_writer.tick(hdr, sizeof(hdr))) { aud_writer.finish(); return false; }
    uint32_t lens[SMP_SLOTS];
    for (int i = 0; i < SMP_SLOTS; i++) lens[i] = smp.len[i];
    if (!aud_writer.tick(lens, sizeof(lens))) { aud_writer.finish(); return false; }
    aud_slot_ix = 0; aud_pos = 0;
    aud_saving  = true;
    return true;
}

static void audSaveTick() {   // one <=2KB chunk — call once per patchTick pass
    if (!aud_saving) return;
    while (aud_slot_ix < SMP_SLOTS && (smp.len[aud_slot_ix] == 0 || aud_pos >= smp.len[aud_slot_ix])) {
        aud_slot_ix++; aud_pos = 0;
    }
    if (aud_slot_ix >= SMP_SLOTS) {            // done — trailing magic marks it complete
        uint32_t tail = AUD_MAGIC;
        aud_writer.tick(&tail, sizeof(tail));
        aud_saving = false;
        aud_writer.finish();
        smp.audio_dirty = false;
        return;
    }
    uint32_t n = smp.len[aud_slot_ix] - aud_pos;
    if (n > 1024) n = 1024;
    for (uint32_t i = 0; i < n; i++) {
        float v = smp_buf[aud_slot_ix][aud_pos + i];
        if (v >  1.f) v =  1.f;
        if (v < -1.f) v = -1.f;
        aud_buf[i] = (int16_t)(v * 32767.f);
    }
    if (!aud_writer.tick(aud_buf, n * 2)) {   // a mid-save failure just stops — .TMP is
        aud_saving = false;                   // discarded on finish(), live .AUD untouched
        aud_writer.finish();
        return;
    }
    aud_pos += n;
}

// ---- AUD load (user-initiated: patchLoad, chunked read is fine to block) --
static bool audLoadFile(const char* nm) {
    FIL f; UINT br;
    if (f_open(&f, nm, FA_READ) != FR_OK) return false;
    uint32_t hdr[2];
    if (f_read(&f, hdr, sizeof(hdr), &br) != FR_OK || br != sizeof(hdr) || hdr[0] != AUD_MAGIC) {
        f_close(&f); return false;
    }
    uint32_t lens[SMP_SLOTS];
    if (f_read(&f, lens, sizeof(lens), &br) != FR_OK || br != sizeof(lens)) { f_close(&f); return false; }
    int16_t buf[1024];
    for (int s = 0; s < SMP_SLOTS; s++) {
        uint32_t n = lens[s];
        if (n == 0) { smp.len[s] = 0; continue; }
        if (n > SMP_LEN) n = SMP_LEN;
        for (uint32_t off = 0; off < n; ) {
            uint32_t c = n - off; if (c > 1024) c = 1024;
            if (f_read(&f, buf, c * 2, &br) != FR_OK || br != c * 2) {
                f_close(&f); smp.len[s] = off; return true;   // partial: keep what loaded
            }
            for (uint32_t i = 0; i < c; i++) smp_buf[s][off + i] = (float)buf[i] / 32767.f;
            off += c;
        }
        smp.len[s] = n;
    }
    f_close(&f);
    return true;
}

static void audLoad(uint8_t slot) {
    for (int i = 0; i < SMP_SLOTS; i++) smp.len[i] = 0;
    if (!sdOk()) return;
    char nm[16]; audName(nm, slot);
    if (audLoadFile(nm)) return;
    char bk[24]; snprintf(bk, sizeof bk, "%s.BAK", nm);
    audLoadFile(bk);   // fall back to the atomic backup
}

// ============================================================ public API
void patchInit() {
    // Globals from QSPI first — GLOBALS must be usable even with a dead/missing card.
    Globals def = defaultGlobals();
    GlobalsRecord defrec{ GLOB_MAGIC, GLOB_VERSION, def };
    gstore.Init(defrec, GLOB_QSPI_OFFSET);
    GlobalsRecord& r = gstore.GetSettings();
    if (r.magic != GLOB_MAGIC) {
        r.magic = GLOB_MAGIC; r.version = GLOB_VERSION; r.g = def;
        gstore.Save();
    }
    glob = r.g;
    globalsApply();

    patchSnapshot(s_default);   // engines are at their init defaults here: keep them as "new patch"

    if (sdOk()) {
        FRESULT mr = f_mkdir(PMOR3_DIR);
        if (mr != FR_OK && mr != FR_EXIST) { fileDiagNote('m', (uint8_t)mr); s_use_dir = false; }
    }
    scanExists();
    g_cur_slot = glob.last_patch < PATCH_SLOTS ? glob.last_patch : 0;
    patch_diag.boot_load = 0;                       // 0 = no file for the boot slot
    if (patchExists(g_cur_slot)) patch_diag.boot_load = patchLoad(g_cur_slot) ? 1 : patch_diag.boot_load;
}

const PatchDiag& patchDiag() { return patch_diag; }

// Fresh patch in `slot` (v2 sessionNew): flush what we were editing, apply the boot
// defaults, drop the sampler audio, make `slot` current and write it right away.
bool patchNew(uint8_t slot) {
    if (slot >= PATCH_SLOTS || !sdOk()) return false;
    if (aud_saving) { aud_saving = false; aud_writer.finish(); }
    if (g_dirty) patchSave(g_cur_slot);
    patchApply(s_default);
    for (int i = 0; i < SMP_SLOTS; i++) smp.len[i] = 0;
    smp.audio_dirty = false;
    clockSetLoopLen(seqLongestLoop());
    g_cur_slot = slot;
    bool ok = patchSave(slot);
    g_dirty = false;
    s_last_saved_crc = s_last_seen_crc = patchLiveCrc();
    if (glob.last_patch != slot) { glob.last_patch = slot; globalsSave(); }
    return ok;
}

bool patchLoad(uint8_t slot) {
    if (slot >= PATCH_SLOTS || !sdOk()) return false;
    if (aud_saving) { aud_saving = false; aud_writer.finish(); }   // never race a load against a save
    if (g_dirty && slot != g_cur_slot) patchSave(g_cur_slot);      // never lose edits still inside the debounce

    char nm[16]; patchName(nm, slot);
    static Patch p;   // ~5 KB: keep off the stack
    int n = fileRead(nm, &p, sizeof(p));
    if (n != (int)sizeof(p) || p.magic != PATCH_MAGIC) {
        // fall back to the atomic backup
        char bk[24]; snprintf(bk, sizeof bk, "%s.BAK", nm);
        int n2 = fileRead(bk, &p, sizeof(p));
        if (n2 != (int)sizeof(p) || p.magic != PATCH_MAGIC) {
            patch_diag.boot_load = (n < 0) ? 2 : 3;    // 2 = unreadable, 3 = wrong size/magic (old build)
            patch_diag.load_size = (n < 0) ? 0 : (uint16_t)n;
            return false;
        }
    }
    if (crc32Buf(&p, sizeof(p) - sizeof(p.crc32)) != p.crc32) { patch_diag.boot_load = 4; return false; }

    patchApply(p);                       // sound only — nav page untouched
    clockSetLoopLen(seqLongestLoop());
    audLoad(slot);                        // sampler audio, chunked read (user-initiated, ok to block)

    g_cur_slot = slot;
    g_dirty    = false;
    s_last_saved_crc = s_last_seen_crc = patchLiveCrc();
    if (glob.last_patch != slot) { glob.last_patch = slot; globalsSave(); }
    return true;
}

bool patchSave(uint8_t slot) {
    if (slot >= PATCH_SLOTS || !sdOk()) return false;
    static Patch p;   // ~5 KB: keep off the stack
    patchSnapshot(p);
    char nm[16]; patchName(nm, slot);
    bool ok = fileWriteAtomic(nm, &p, sizeof(p));
    if (ok) {
        g_exists_mask |= (1ull << slot);
        if (slot == g_cur_slot) g_dirty = false;
        patch_diag.saves_ok++;
    } else {
        patch_diag.saves_fail++;
    }
    return ok;
}

void patchDelete(uint8_t slot) {
    if (slot >= PATCH_SLOTS || !sdOk()) return;
    if (aud_saving) { aud_saving = false; aud_writer.finish(); }
    char nm[16]; patchName(nm, slot);
    char bk[24]; snprintf(bk, sizeof bk, "%s.BAK", nm);
    f_unlink(nm); f_unlink(bk);
    char an[16]; audName(an, slot);
    char ab[24]; snprintf(ab, sizeof ab, "%s.BAK", an);
    f_unlink(an); f_unlink(ab);
    g_exists_mask &= ~(1ull << slot);
}

void patchMarkDirty() {
    g_dirty   = true;
    g_save_at = System::GetNow() + AUTOSAVE_DEBOUNCE_MS;
}

// Central change detection: instead of trusting every code path to call patchMarkDirty(),
// the whole patch is snapshotted and CRC'd 4x a second. ANY change (sound swipe, sequence
// hit, gesture, bars/steps, volumes, automation...) arms the 2 s debounce; each further
// change restarts it; then it is written. Sampler audio has its own dirty flag.
static Patch    s_scan;                // static, not stack (several KB)
static uint32_t patchLiveCrc() { patchSnapshot(s_scan); return s_scan.crc32; }

void patchTick(uint32_t now_ms) {
    globalsSyncTick(now_ms);
    if (aud_saving) { audSaveTick(); return; }   // finish an in-flight audio save before anything else

    if (now_ms >= s_next_scan) {
        s_next_scan = now_ms + 250;
        uint32_t c = patchLiveCrc();
        if (c != s_last_seen_crc) { s_last_seen_crc = c; if (c != s_last_saved_crc) patchMarkDirty(); }
        if (smp.audio_dirty && !g_dirty) patchMarkDirty();
    }

    if (g_dirty && now_ms >= g_save_at) {
        if (patchSave(g_cur_slot)) s_last_saved_crc = s_last_seen_crc = patchLiveCrc();   // fast: PMR only
        else g_save_at = now_ms + 5000;                                                     // no card: retry later, never spin
        if (smp.audio_dirty) audBeginSave(g_cur_slot);   // AUD chunks now drive from here
    }
}

void patchFactoryReset() {
    if (sdOk()) {
        if (aud_saving) { aud_saving = false; aud_writer.finish(); }
        for (int s = 0; s < PATCH_SLOTS; s++) patchDelete((uint8_t)s);
    }
    glob = defaultGlobals();
    globalsSave();
    globalsApply();
}
